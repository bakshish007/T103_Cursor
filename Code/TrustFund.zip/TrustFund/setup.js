#!/usr/bin/env node

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

console.log('🚀 Transparent Donation System Setup');
console.log('=====================================\n');

// Check Node.js version
function checkNodeVersion() {
  const nodeVersion = process.version;
  const majorVersion = parseInt(nodeVersion.slice(1).split('.')[0]);
  
  if (majorVersion < 16) {
    console.error('❌ Node.js version 16 or higher is required');
    console.error(`   Current version: ${nodeVersion}`);
    process.exit(1);
  }
  
  console.log(`✅ Node.js version: ${nodeVersion}`);
}

// Check if npm is available
function checkNpm() {
  try {
    const npmVersion = execSync('npm --version', { encoding: 'utf8' }).trim();
    console.log(`✅ npm version: ${npmVersion}`);
  } catch (error) {
    console.error('❌ npm is not available');
    process.exit(1);
  }
}

// Create environment files
function createEnvFiles() {
  console.log('\n📝 Creating environment files...');
  
  // Backend .env
  const backendEnvPath = path.join(__dirname, 'backend', '.env');
  const backendEnvExample = path.join(__dirname, 'backend', 'env.example');
  
  if (!fs.existsSync(backendEnvPath) && fs.existsSync(backendEnvExample)) {
    fs.copyFileSync(backendEnvExample, backendEnvPath);
    console.log('✅ Created backend/.env from template');
  } else if (fs.existsSync(backendEnvPath)) {
    console.log('ℹ️  backend/.env already exists');
  }
  
  // Frontend .env
  const frontendEnvPath = path.join(__dirname, 'frontend', '.env');
  const frontendEnvExample = path.join(__dirname, 'frontend', 'env.example');
  
  if (!fs.existsSync(frontendEnvPath) && fs.existsSync(frontendEnvExample)) {
    fs.copyFileSync(frontendEnvExample, frontendEnvPath);
    console.log('✅ Created frontend/.env from template');
  } else if (fs.existsSync(frontendEnvPath)) {
    console.log('ℹ️  frontend/.env already exists');
  }
}

// Create necessary directories
function createDirectories() {
  console.log('\n📁 Creating necessary directories...');
  
  const directories = [
    'backend/uploads',
    'backend/cache',
    'backend/artifacts'
  ];
  
  directories.forEach(dir => {
    const dirPath = path.join(__dirname, dir);
    if (!fs.existsSync(dirPath)) {
      fs.mkdirSync(dirPath, { recursive: true });
      console.log(`✅ Created directory: ${dir}`);
    } else {
      console.log(`ℹ️  Directory already exists: ${dir}`);
    }
  });
}

// Install dependencies
function installDependencies() {
  console.log('\n📦 Installing dependencies...');
  
  try {
    // Root dependencies
    console.log('Installing root dependencies...');
    execSync('npm install', { stdio: 'inherit', cwd: __dirname });
    
    // Backend dependencies
    console.log('Installing backend dependencies...');
    execSync('npm install', { stdio: 'inherit', cwd: path.join(__dirname, 'backend') });
    
    // Frontend dependencies
    console.log('Installing frontend dependencies...');
    execSync('npm install', { stdio: 'inherit', cwd: path.join(__dirname, 'frontend') });
    
    console.log('✅ All dependencies installed successfully');
  } catch (error) {
    console.error('❌ Error installing dependencies:', error.message);
    process.exit(1);
  }
}

// Display next steps
function displayNextSteps() {
  console.log('\n🎉 Setup completed successfully!');
  console.log('\n📋 Next steps:');
  console.log('1. Configure your environment files:');
  console.log('   - Edit backend/.env with your MongoDB URI and blockchain settings');
  console.log('   - Edit frontend/.env if needed');
  console.log('');
  console.log('2. Set up your database:');
  console.log('   - Create a MongoDB Atlas cluster');
  console.log('   - Update MONGODB_URI in backend/.env');
  console.log('   - Run: cd backend && node scripts/seed.js (optional - creates demo data)');
  console.log('');
  console.log('3. Configure blockchain (optional for demo):');
  console.log('   - Get Polygon testnet RPC URL from Alchemy or Infura');
  console.log('   - Add your private key for contract deployment');
  console.log('   - Update POLYGON_RPC_URL and PRIVATE_KEY in backend/.env');
  console.log('   - Deploy contracts: cd backend && npx hardhat run scripts/deploy.js --network mumbai');
  console.log('');
  console.log('4. Start the application:');
  console.log('   npm run dev');
  console.log('');
  console.log('🔗 Demo accounts (if you ran the seed script):');
  console.log('   NGO: ngo@demo.com / password123');
  console.log('   Donor: donor@demo.com / password123');
  console.log('');
  console.log('📚 For more information, check the README.md file');
  console.log('🐛 If you encounter any issues, check the troubleshooting section in README.md');
}

// Main setup function
function main() {
  try {
    checkNodeVersion();
    checkNpm();
    createEnvFiles();
    createDirectories();
    installDependencies();
    displayNextSteps();
  } catch (error) {
    console.error('❌ Setup failed:', error.message);
    process.exit(1);
  }
}

// Run setup
main();
