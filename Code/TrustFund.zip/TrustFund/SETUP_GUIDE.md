# 🚀 Complete Setup Guide - Transparent Donation System

This guide provides step-by-step instructions to set up and run the entire Transparent Donation System project.

## 📋 Prerequisites

Before starting, ensure you have the following installed:

### Required Software
- **Node.js** (v16 or higher) - [Download here](https://nodejs.org/)
- **npm** (comes with Node.js)
- **Git** - [Download here](https://git-scm.com/)

### Optional (for full blockchain features)
- **MongoDB Atlas account** - [Sign up here](https://www.mongodb.com/atlas)
- **Polygon testnet wallet** with test MATIC
- **NFT.Storage API key** - [Get here](https://nft.storage/)

## 🛠️ Step-by-Step Setup

### Step 1: Clone the Repository

```bash
# Clone the repository
git clone <your-repository-url>
cd donation

# Verify you're in the correct directory
ls -la
```

You should see the following structure:
```
donation/
├── backend/
├── frontend/
├── package.json
├── README.md
└── other files...
```

### Step 2: Automated Setup (Recommended)

Run the automated setup script:

```bash
# Run the setup script
npm run setup
```

This script will:
- ✅ Check Node.js and npm versions
- ✅ Create environment files from templates
- ✅ Create necessary directories
- ✅ Install all dependencies
- ✅ Display next steps

### Step 3: Manual Setup (Alternative)

If you prefer manual setup or the automated script fails:

#### 3.1 Install Dependencies

```bash
# Install root dependencies
npm install

# Install backend dependencies
cd backend
npm install

# Install frontend dependencies
cd ../frontend
npm install

# Return to root directory
cd ..
```

#### 3.2 Create Environment Files

```bash
# Create backend environment file
cp backend/env.example backend/.env

# Create frontend environment file
cp frontend/env.example frontend/.env
```

#### 3.3 Create Directories

```bash
# Create uploads directory
mkdir -p backend/uploads
```

### Step 4: Configure Environment Variables

#### 4.1 Backend Configuration (`backend/.env`)

Edit the `backend/.env` file with your configuration:

```env
# Server Configuration
PORT=5000
NODE_ENV=development

# Database Configuration
MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/donation-system

# Authentication
JWT_SECRET=your-super-secret-jwt-key-here-make-it-long-and-random

# Blockchain Configuration (Optional for demo)
POLYGON_RPC_URL=https://polygon-mumbai.g.alchemy.com/v2/your-api-key
PRIVATE_KEY=your-private-key-for-deploying-contracts

# IPFS Storage (Optional for demo)
NFT_STORAGE_API_KEY=your-nft-storage-api-key
```

**Required for basic functionality:**
- `MONGODB_URI` - MongoDB connection string
- `JWT_SECRET` - Any long random string

**Optional for blockchain features:**
- `POLYGON_RPC_URL` - Polygon testnet RPC URL
- `PRIVATE_KEY` - Wallet private key for contract deployment
- `NFT_STORAGE_API_KEY` - IPFS storage API key

#### 4.2 Frontend Configuration (`frontend/.env`)

Edit the `frontend/.env` file:

```env
REACT_APP_API_URL=http://localhost:5000/api
```

### Step 5: Database Setup

#### 5.1 MongoDB Atlas Setup (Recommended)

1. Go to [MongoDB Atlas](https://www.mongodb.com/atlas)
2. Create a free account
3. Create a new cluster
4. Create a database user
5. Get your connection string
6. Update `MONGODB_URI` in `backend/.env`

#### 5.2 Local MongoDB (Alternative)

If you have MongoDB installed locally:

```env
MONGODB_URI=mongodb://localhost:27017/donation-system
```

### Step 6: Load Demo Data (Optional)

Load sample data for testing:

```bash
# Load demo data
npm run seed
```

This creates:
- Demo NGO and Donor accounts
- Sample campaigns with milestones
- Sample donations
- Complete user profiles

### Step 7: Start the Application

#### 7.1 Development Mode (Recommended)

Start both backend and frontend servers:

```bash
# Start both servers concurrently
npm run dev
```

This will start:
- Backend server on http://localhost:5000
- Frontend server on http://localhost:3000

#### 7.2 Individual Servers

Start servers separately:

```bash
# Terminal 1 - Backend
npm run server

# Terminal 2 - Frontend
npm run client
```

### Step 8: Access the Application

1. **Open your browser** and go to: http://localhost:3000
2. **Use demo accounts** to test:
   - **NGO**: `ngo@demo.com` / `password123`
   - **Donor**: `donor@demo.com` / `password123`

## 🔧 Advanced Setup (Optional)

### Blockchain Integration Setup

#### 8.1 Get Polygon Testnet MATIC

1. Go to [Polygon Faucet](https://faucet.polygon.technology/)
2. Enter your wallet address
3. Request test MATIC tokens

#### 8.2 Deploy Smart Contracts

```bash
# Navigate to backend
cd backend

# Deploy contracts to Mumbai testnet
npm run deploy:contracts
```

#### 8.3 Configure IPFS Storage

1. Go to [NFT.Storage](https://nft.storage/)
2. Create an account
3. Generate an API key
4. Add to `backend/.env`:

```env
NFT_STORAGE_API_KEY=your-api-key-here
```

## 🧪 Testing the Setup

### Quick Test Checklist

1. **✅ Application Starts**
   - Backend server runs on port 5000
   - Frontend server runs on port 3000
   - No error messages in console

2. **✅ Database Connection**
   - Check backend logs for "MongoDB connected successfully"
   - No database connection errors

3. **✅ Demo Login**
   - Can login with demo accounts
   - Dashboard loads correctly
   - No authentication errors

4. **✅ Basic Features**
   - Can browse campaigns
   - Can create donations
   - Can view transparency dashboard

### Test Commands

```bash
# Test backend API
curl http://localhost:5000/api/health

# Test frontend
# Open http://localhost:3000 in browser

# Test database connection
npm run seed
```

## 🐛 Troubleshooting

### Common Issues and Solutions

#### Issue 1: Port Already in Use
```bash
# Error: Port 5000 or 3000 already in use
# Solution: Kill processes using these ports

# Windows
netstat -ano | findstr :5000
taskkill /PID <PID> /F

# macOS/Linux
lsof -ti:5000 | xargs kill -9
```

#### Issue 2: MongoDB Connection Failed
```bash
# Check your MongoDB URI format
MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/donation-system

# Ensure:
# - Username and password are correct
# - Cluster is running
# - Network access is configured
```

#### Issue 3: Dependencies Installation Failed
```bash
# Clear npm cache
npm cache clean --force

# Delete node_modules and reinstall
rm -rf node_modules package-lock.json
npm install
```

#### Issue 4: Environment Variables Not Loading
```bash
# Ensure .env files are in correct locations:
# - backend/.env
# - frontend/.env

# Check file permissions
ls -la backend/.env
ls -la frontend/.env
```

#### Issue 5: Frontend Build Errors
```bash
# Clear React cache
cd frontend
rm -rf node_modules package-lock.json
npm install

# Check for syntax errors in components
npm start
```

## 📱 Available Scripts

### Root Level Scripts
```bash
npm run setup          # Automated setup
npm run dev            # Start both servers
npm run server         # Start backend only
npm run client         # Start frontend only
npm run seed           # Load demo data
npm run build          # Build for production
npm run deploy         # Run deployment script
```

### Backend Scripts
```bash
cd backend
npm run dev            # Start development server
npm run start          # Start production server
npm run seed           # Load demo data
npm run deploy:contracts # Deploy smart contracts
npm run compile        # Compile smart contracts
```

### Frontend Scripts
```bash
cd frontend
npm start              # Start development server
npm run build          # Build for production
npm test               # Run tests
```

## 🚀 Production Deployment

### Build for Production

```bash
# Build frontend
npm run build

# Start production server
npm start
```

### Environment Variables for Production

Update environment variables for production:

```env
# backend/.env
NODE_ENV=production
MONGODB_URI=your-production-mongodb-uri
JWT_SECRET=your-production-jwt-secret
```

## 📞 Support

### Getting Help

1. **Check Logs**: Look at console output for error messages
2. **Verify Setup**: Ensure all prerequisites are installed
3. **Test Components**: Try individual components separately
4. **Check Documentation**: Review README.md and TESTING.md

### Common Commands for Debugging

```bash
# Check Node.js version
node --version

# Check npm version
npm --version

# Check if ports are available
netstat -an | grep :5000
netstat -an | grep :3000

# Check environment variables
echo $NODE_ENV

# Check file permissions
ls -la backend/.env
```

## ✅ Success Criteria

Your setup is successful when:

- ✅ All dependencies install without errors
- ✅ Backend server starts on port 5000
- ✅ Frontend server starts on port 3000
- ✅ Can access http://localhost:3000
- ✅ Can login with demo accounts
- ✅ Can browse campaigns and make donations
- ✅ No console errors in browser or terminal

## 🎉 You're Ready!

Once you've completed these steps, you have a fully functional Transparent Donation System ready for:

- 🎮 **Demo and Testing**
- 🚀 **Further Development**
- 📱 **Hackathon Presentations**
- 🌐 **Production Deployment**

---

**Need help?** Check the README.md, TESTING.md, or create an issue in the repository.
