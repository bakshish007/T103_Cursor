# 🏦 NGO Bank Account Setup Guide

This guide explains how NGOs can set up their own bank account details for receiving donations directly to their accounts.

## 🎯 **Overview**

The Transparent Donation System now supports **NGO-specific bank accounts**, allowing each NGO to:
- Set up their own UPI ID for QR code payments
- Configure their bank account details for manual transfers
- Receive donations directly to their accounts
- Maintain transparency with their own payment details

## 🔧 **How It Works**

### **Payment Flow**
1. **NGO sets up bank details** in their profile
2. **Donor creates donation** for NGO's campaign
3. **System generates QR code** with NGO's UPI ID
4. **Donor scans QR code** → Payment goes to NGO's account
5. **NGO receives funds** directly in their bank account

### **Fallback System**
- If NGO hasn't set up bank details → Uses system default
- If NGO has partial details → Uses available details
- Always prioritizes NGO-specific details over system defaults

## 📱 **Setting Up Bank Account Details**

### **Step 1: Login as NGO**
```
Email: ngo@demo.com
Password: password123
```

### **Step 2: Go to Profile Settings**
1. Click on your profile/avatar
2. Select "Profile Settings"
3. You'll see new sections for bank details

### **Step 3: Fill Bank Account Details**

#### **Bank Account Information**
```
Account Number: 1234567890
IFSC Code: SBIN0001234
Bank Name: State Bank of India
Branch: Mumbai Main Branch
Account Holder Name: Your Organization Name
```

#### **UPI Details**
```
UPI ID (VPA): yourname@paytm
Merchant Name: Your Organization Name
```

### **Step 4: Save Changes**
- Click "Save Changes" to update your profile
- Bank details are now active for your campaigns

## 🏦 **Bank Account Fields Explained**

### **Account Number**
- Your bank account number
- Should match your bank records exactly
- No spaces or special characters

### **IFSC Code**
- 11-character code identifying your bank branch
- Format: `XXXX0XXXXXX`
- Example: `SBIN0001234`
- System validates format automatically

### **Bank Name**
- Full name of your bank
- Example: "State Bank of India", "HDFC Bank"
- Used for display purposes

### **Branch**
- Your bank branch name
- Example: "Mumbai Main Branch", "Delhi Central"
- Helps donors identify the correct branch

### **Account Holder Name**
- Name as it appears in bank records
- Should match your organization's legal name
- Used for verification purposes

## 💳 **UPI Configuration**

### **UPI ID (VPA)**
- Your unique UPI identifier
- Format: `username@provider`
- Examples:
  - `yourname@paytm`
  - `yourname@phonepe`
  - `yourname@googlepay`
  - `yourname@ybl` (Yes Bank)
  - `yourname@okaxis` (Axis Bank)

### **Merchant Name**
- Display name for UPI payments
- Usually your organization name
- Shows up in donor's UPI app

## 🔒 **Security & Verification**

### **Data Protection**
- Bank details are encrypted in database
- Only accessible to authorized users
- Never shared with third parties

### **Verification Process**
- Bank details marked as "verified" after setup
- System validates IFSC code format
- UPI ID format is validated
- Manual verification can be added later

## 📊 **Testing Your Setup**

### **Test Payment Flow**
1. **Create a test campaign** (if you don't have one)
2. **Login as donor**: `donor@demo.com` / `password123`
3. **Donate to your campaign**
4. **Check QR code** → Should show your UPI ID
5. **Verify payment details** → Should show your bank details

### **API Testing**
```bash
# Get payment config for your campaign
curl "http://localhost:5000/api/donations/payment-config?campaignId=YOUR_CAMPAIGN_ID"

# Response should include your bank details
{
  "success": true,
  "config": {
    "upi": {
      "vpa": "helpindia@paytm",
      "merchantName": "Help India Foundation"
    },
    "bank": {
      "accountNumber": "1234567890",
      "ifscCode": "SBIN0001234",
      "bankName": "State Bank of India",
      "branch": "Mumbai Main Branch",
      "accountHolderName": "Help India Foundation"
    }
  },
  "ngoInfo": {
    "organizationName": "Help India Foundation",
    "hasBankDetails": true,
    "hasUPIDetails": true
  }
}
```

## 🚀 **Production Setup**

### **Real Bank Account**
1. **Use your actual bank account details**
2. **Set up real UPI ID** with your bank
3. **Test with small amounts** first
4. **Verify all details** are correct

### **UPI Setup**
1. **Contact your bank** to set up UPI
2. **Choose a memorable UPI ID**
3. **Link to your bank account**
4. **Test with small transactions**

## 🔄 **Managing Multiple Accounts**

### **Single Account (Recommended)**
- Use one bank account for all campaigns
- Easier to manage and track
- Better for transparency

### **Multiple Accounts**
- Can set up different accounts for different campaigns
- Update profile before creating new campaigns
- Maintain clear records

## 📋 **Best Practices**

### **Bank Account Setup**
- ✅ Use official bank account
- ✅ Keep account details updated
- ✅ Verify all information
- ✅ Test with small amounts first

### **UPI Configuration**
- ✅ Choose memorable UPI ID
- ✅ Use organization name as merchant name
- ✅ Test UPI payments
- ✅ Keep UPI ID active

### **Security**
- ✅ Never share bank details publicly
- ✅ Use secure internet connection
- ✅ Log out after sessions
- ✅ Monitor transaction logs

## 🛠️ **Troubleshooting**

### **Common Issues**

1. **QR Code not showing NGO details**
   - Check if bank details are saved
   - Verify campaign belongs to correct NGO
   - Restart application

2. **Payment not going to NGO account**
   - Verify UPI ID is correct
   - Check bank account is active
   - Contact bank for UPI issues

3. **Bank details not saving**
   - Check all required fields are filled
   - Verify IFSC code format
   - Try refreshing the page

### **Debug Commands**
```bash
# Check NGO user details
curl -H "Authorization: Bearer YOUR_TOKEN" http://localhost:5000/api/auth/me

# Test payment config
curl "http://localhost:5000/api/donations/payment-config?campaignId=CAMPAIGN_ID"

# Verify bank details format
node -e "const ps = require('./services/payment'); console.log(ps.validateIFSC('SBIN0001234'))"
```

## 📞 **Support**

### **Technical Issues**
- Check server logs
- Verify database connection
- Test API endpoints

### **Banking Issues**
- Contact your bank
- Verify account status
- Check UPI setup

### **System Issues**
- Check environment variables
- Verify user permissions
- Test with demo accounts

## 🔮 **Future Enhancements**

- **Bank account verification** via API
- **Multiple bank accounts** per NGO
- **Payment analytics** dashboard
- **Automated reconciliation**
- **International payment** support

---

**Note**: This system uses simulated payments for demonstration. For production use, integrate with real payment gateways and implement proper verification processes.
