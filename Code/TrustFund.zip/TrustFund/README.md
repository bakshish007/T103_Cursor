# TrustFund - Transparent Donation Platform with Blockchain & UPI Simulation

A full-stack web application for transparent charity donations in India, built with React, Node.js, MongoDB, and blockchain technology.

## 🚀 Features

### Core Functionality
- **Role-based Access**: Separate panels for NGOs, Donors, and Public users
- **Campaign Management**: NGOs can create and manage fundraising campaigns
- **Transparent Donations**: UPI simulation with blockchain recording
- **Impact NFTs**: Donors receive NFT rewards for their contributions
- **Proof of Impact**: Milestone tracking with IPFS-stored proofs
- **Transparency Dashboard**: Public view of all campaigns and their progress

### Technology Stack
- **Frontend**: React 18, TailwindCSS, React Router
- **Backend**: Node.js, Express.js, MongoDB
- **Blockchain**: Polygon Testnet, Ethers.js, Hardhat
- **Storage**: IPFS via NFT.Storage
- **Authentication**: JWT-based auth system

## 📋 Prerequisites

- Node.js (v16 or higher)
- MongoDB Atlas account (or local MongoDB)
- Polygon testnet wallet with test MATIC
- NFT.Storage API key (optional, for IPFS)

## 🛠️ Installation

### 1. Clone the Repository
```bash
git clone <repository-url>
cd donation
```

### 2. Install Dependencies
```bash
# Install root dependencies
npm install

# Install backend dependencies
cd backend
npm install

# Install frontend dependencies
cd ../frontend
npm install
```

### 3. Environment Setup

#### Backend Environment
Create `backend/.env` file:
```env
PORT=5000
MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/donation-system
JWT_SECRET=your-super-secret-jwt-key-here
POLYGON_RPC_URL=https://polygon-mumbai.g.alchemy.com/v2/your-api-key
PRIVATE_KEY=your-private-key-for-deploying-contracts
NFT_STORAGE_API_KEY=your-nft-storage-api-key
NODE_ENV=development
```

#### Frontend Environment
Create `frontend/.env` file:
```env
REACT_APP_API_URL=http://localhost:5000/api
```

### 4. Smart Contract Deployment

```bash
cd backend

# Install Hardhat dependencies
npm install --save-dev hardhat @nomicfoundation/hardhat-toolbox

# Deploy contracts to Polygon Mumbai testnet
npx hardhat run scripts/deploy.js --network mumbai
```

### 5. Database Setup
- Create a MongoDB Atlas cluster
- Update the `MONGODB_URI` in your `.env` file
- The application will automatically create the necessary collections

## 🚀 Running the Application

### Development Mode
```bash
# From the root directory
npm run dev
```

This will start both the backend (port 5000) and frontend (port 3000) concurrently.

### Individual Services
```bash
# Backend only
npm run server

# Frontend only
npm run client
```

## 📱 Usage

### Demo Accounts
The application includes demo accounts for testing:

**NGO Account:**
- Email: `ngo@demo.com`
- Password: `password123`

**Donor Account:**
- Email: `donor@demo.com`
- Password: `password123`

### User Flows

#### For NGOs:
1. Register/Login as NGO
2. Create campaigns with milestones
3. Upload proof of impact with geo-location
4. Track campaign progress and donations

#### For Donors:
1. Register/Login as Donor
2. Browse active campaigns
3. Donate via UPI simulation
4. Receive Impact NFTs
5. Track donation history and impact

#### For Public Users:
1. Browse campaigns without login
2. View transparency dashboard
3. See proof of impact on map
4. Verify blockchain transactions

## 🔧 API Endpoints

### Authentication
- `POST /api/auth/register` - User registration
- `POST /api/auth/login` - User login
- `GET /api/auth/me` - Get current user
- `PUT /api/auth/profile` - Update profile

### Campaigns
- `GET /api/campaigns` - Get all campaigns
- `POST /api/campaigns` - Create campaign (NGO only)
- `GET /api/campaigns/:id` - Get campaign details
- `PUT /api/campaigns/:id` - Update campaign

### Donations
- `POST /api/donations` - Create donation
- `POST /api/donations/:id/confirm-payment` - Confirm payment
- `GET /api/donations/my-donations` - Get user's donations

### Blockchain
- `GET /api/blockchain/transaction/:txHash` - Get transaction status
- `GET /api/blockchain/nfts/:address` - Get user's NFTs

## 🏗️ Project Structure

```
donation/
├── backend/
│   ├── contracts/          # Smart contracts
│   ├── models/            # MongoDB models
│   ├── routes/            # API routes
│   ├── services/          # Business logic
│   ├── middleware/        # Express middleware
│   └── scripts/           # Deployment scripts
├── frontend/
│   ├── src/
│   │   ├── components/    # React components
│   │   ├── pages/         # Page components
│   │   ├── contexts/      # React contexts
│   │   ├── services/      # API services
│   │   └── utils/         # Utility functions
│   └── public/            # Static assets
└── README.md
```

## 🔐 Security Features

- JWT-based authentication
- Password hashing with bcrypt
- Rate limiting on API endpoints
- Input validation and sanitization
- CORS configuration
- Helmet.js security headers

## 🌐 Blockchain Integration

### Smart Contracts
- **CampaignContract**: Records campaigns, donations, and proofs
- **ImpactNFT**: Mints NFT rewards for donors

### Networks
- **Mumbai Testnet**: For development and testing
- **Amoy Testnet**: Alternative testnet option

### Features
- Campaign creation logging
- Donation recording
- Proof of impact verification
- NFT minting for donors
- Transaction verification

## 📊 Transparency Features

- **Transparency Score**: Calculated based on proof uploads
- **Blockchain Verification**: All transactions recorded on-chain
- **IPFS Storage**: Decentralized proof storage
- **Geo-location Tracking**: Proof locations on map
- **Milestone Tracking**: Progress monitoring

## 🚀 Deployment

### Backend Deployment
1. Set up MongoDB Atlas
2. Deploy smart contracts to Polygon mainnet
3. Configure environment variables
4. Deploy to your preferred hosting service

### Frontend Deployment
1. Build the React application
2. Deploy to Vercel, Netlify, or similar
3. Update API URLs for production

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License.

## 🆘 Support

For support and questions:
- Create an issue in the repository
- Check the documentation
- Review the demo accounts for testing

## 🔮 Future Enhancements

- Real UPI integration
- Multi-language support
- Mobile app development
- Advanced analytics dashboard
- Social media integration
- Recurring donation options

---

**Note**: This is a demonstration project for hackathon purposes. For production use, additional security measures and real payment integration would be required.
