# 💳 Payment System Configuration Guide

This guide explains how to configure and manage the payment system for the Transparent Donation System, including UPI QR codes, bank account details, and payment gateways.

## 🏦 **Current Payment System Overview**

The system currently supports:
- **UPI QR Code Payments** (Primary method)
- **Bank Account Details** (Manual transfers)
- **Simulated Payment Confirmation** (For testing)

## 🔧 **Configuration Methods**

### **Method 1: Environment Variables (Recommended)**

Update your `backend/.env` file with the following payment configuration:

```env
# Payment Configuration
UPI_VPA=your-upi-id@paytm
MERCHANT_NAME=Your Organization Name
MERCHANT_CODE=YOURCODE
BANK_ACCOUNT_NUMBER=1234567890
BANK_IFSC_CODE=SBIN0001234
BANK_NAME=State Bank of India
BANK_BRANCH=Mumbai Main Branch
ACCOUNT_HOLDER_NAME=Your Organization Name

# Optional: Payment Gateway Integration
RAZORPAY_KEY_ID=your-razorpay-key
RAZORPAY_KEY_SECRET=your-razorpay-secret
PAYU_MERCHANT_KEY=your-payu-key
PAYU_MERCHANT_SALT=your-payu-salt
```

### **Method 2: Direct Code Modification**

Edit `backend/services/payment.js` to change default values:

```javascript
this.config = {
  upi: {
    vpa: 'your-upi-id@paytm', // Change this
    merchantName: 'Your Organization Name', // Change this
    // ... other settings
  },
  bank: {
    accountNumber: '1234567890', // Change this
    ifscCode: 'SBIN0001234', // Change this
    // ... other settings
  }
};
```

## 📱 **UPI Configuration**

### **Setting Up UPI ID**

1. **Choose a UPI ID format:**
   ```
   yourname@paytm
   yourname@phonepe
   yourname@googlepay
   yourname@ybl (Yes Bank)
   yourname@okaxis (Axis Bank)
   ```

2. **Update environment variable:**
   ```env
   UPI_VPA=yourname@paytm
   ```

3. **Test UPI ID format:**
   ```bash
   # The system validates UPI format automatically
   # Format: username@provider
   ```

### **UPI QR Code Generation**

The system automatically generates UPI QR codes with:
- **VPA**: Your UPI ID
- **Merchant Name**: Your organization name
- **Amount**: Donation amount
- **Transaction Note**: Campaign title
- **Transaction ID**: Unique donation ID

## 🏦 **Bank Account Configuration**

### **Required Bank Details**

```env
BANK_ACCOUNT_NUMBER=1234567890
BANK_IFSC_CODE=SBIN0001234
BANK_NAME=State Bank of India
BANK_BRANCH=Mumbai Main Branch
ACCOUNT_HOLDER_NAME=Your Organization Name
```

### **IFSC Code Format**
- **Format**: `XXXX0XXXXXX`
- **Example**: `SBIN0001234`
- **Validation**: System validates IFSC format automatically

## 🔄 **Payment Flow**

### **Current Flow (Simulated)**

1. **Donor creates donation** → QR code generated
2. **Donor scans QR code** → UPI app opens
3. **Donor confirms payment** → Status updated to "completed"
4. **Blockchain logging** → Transaction recorded
5. **NFT minting** → Impact NFT created

### **Real Payment Integration**

To integrate with real payment gateways:

1. **Razorpay Integration:**
   ```env
   RAZORPAY_KEY_ID=rzp_test_xxxxx
   RAZORPAY_KEY_SECRET=your-secret-key
   ```

2. **PayU Integration:**
   ```env
   PAYU_MERCHANT_KEY=your-merchant-key
   PAYU_MERCHANT_SALT=your-merchant-salt
   ```

## 🛠️ **API Endpoints**

### **Get Payment Configuration**
```http
GET /api/donations/payment-config
```

**Response:**
```json
{
  "success": true,
  "config": {
    "upi": {
      "vpa": "donation@paytm",
      "merchantName": "Transparent Donation System"
    },
    "bank": {
      "accountNumber": "1234567890",
      "ifscCode": "SBIN0001234",
      "bankName": "State Bank of India",
      "branch": "Mumbai Main Branch",
      "accountHolderName": "Transparent Donation System"
    },
    "supportedMethods": ["upi", "netbanking", "card", "wallet"]
  }
}
```

## 🔒 **Security Considerations**

### **Environment Variables**
- ✅ Store sensitive data in `.env` files
- ✅ Never commit `.env` files to version control
- ✅ Use different configurations for development/production

### **UPI Security**
- ✅ Validate UPI VPA format
- ✅ Use official UPI providers
- ✅ Monitor transaction logs

### **Bank Account Security**
- ✅ Validate IFSC codes
- ✅ Use secure banking channels
- ✅ Implement transaction limits

## 📊 **Testing Payment System**

### **Test UPI Payments**

1. **Create test donation:**
   ```bash
   curl -X POST http://localhost:5000/api/donations \
     -H "Content-Type: application/json" \
     -H "Authorization: Bearer YOUR_TOKEN" \
     -d '{
       "campaignId": "CAMPAIGN_ID",
       "amount": 100,
       "donorMessage": "Test donation"
     }'
   ```

2. **Confirm payment:**
   ```bash
   curl -X POST http://localhost:5000/api/donations/DONATION_ID/confirm-payment \
     -H "Authorization: Bearer YOUR_TOKEN"
   ```

### **Test Bank Details**

1. **Get payment config:**
   ```bash
   curl http://localhost:5000/api/donations/payment-config
   ```

2. **Verify bank details are correct**

## 🚀 **Production Setup**

### **Step 1: Configure Environment**
```env
# Production Payment Configuration
UPI_VPA=your-production-upi@paytm
MERCHANT_NAME=Your Production Organization
BANK_ACCOUNT_NUMBER=your-production-account
BANK_IFSC_CODE=your-production-ifsc
```

### **Step 2: Test Configuration**
```bash
# Test payment configuration
curl http://your-domain.com/api/donations/payment-config
```

### **Step 3: Monitor Transactions**
- Check transaction logs
- Monitor blockchain confirmations
- Verify NFT minting

## 🔧 **Troubleshooting**

### **Common Issues**

1. **QR Code not generating:**
   - Check UPI_VPA format
   - Verify environment variables
   - Check server logs

2. **Payment not confirming:**
   - Verify donation ID
   - Check user permissions
   - Monitor blockchain service

3. **Bank details not showing:**
   - Check environment variables
   - Verify API endpoint
   - Check server configuration

### **Debug Commands**

```bash
# Check environment variables
node -e "console.log(process.env.UPI_VPA)"

# Test payment service
node -e "const ps = require('./services/payment'); console.log(ps.getPaymentConfig())"

# Validate UPI format
node -e "const ps = require('./services/payment'); console.log(ps.validateUPIVPA('test@paytm'))"
```

## 📞 **Support**

For payment-related issues:
1. Check server logs
2. Verify environment configuration
3. Test API endpoints
4. Contact payment provider support

## 🔄 **Future Enhancements**

- **Real-time payment verification**
- **Multiple payment gateways**
- **International payment support**
- **Payment analytics dashboard**
- **Automated reconciliation**

---

**Note**: This is a simulated payment system for demonstration purposes. For production use, integrate with real payment gateways and implement proper security measures.
