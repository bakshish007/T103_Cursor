import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './contexts/AuthContext';
import Navbar from './components/Layout/Navbar';
import Footer from './components/Layout/Footer';
import LoadingSpinner from './components/UI/LoadingSpinner';

// Public pages
import Home from './pages/Home';
import Campaigns from './pages/Campaigns';
import CampaignDetail from './pages/CampaignDetail';
import TransparencyDashboard from './pages/TransparencyDashboard';
import Login from './pages/Auth/Login';
import Register from './pages/Auth/Register';

// Protected pages
import Dashboard from './pages/Dashboard';
import CreateCampaign from './pages/NGO/CreateCampaign';
import MyCampaigns from './pages/NGO/MyCampaigns';
import CampaignManagement from './pages/NGO/CampaignManagement';
import Donate from './pages/Donor/Donate';
import MyDonations from './pages/Donor/MyDonations';
import MyNFTs from './pages/Donor/MyNFTs';
import Profile from './pages/Profile';

// Protected Route component
const ProtectedRoute = ({ children, allowedRoles = [] }) => {
  const { user, loading } = useAuth();

  if (loading) {
    return <LoadingSpinner />;
  }

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  if (allowedRoles.length > 0 && !allowedRoles.includes(user.role)) {
    return <Navigate to="/dashboard" replace />;
  }

  return children;
};

function App() {
  const { loading } = useAuth();

  if (loading) {
    return <LoadingSpinner />;
  }

  return (
    <Router>
      <div className="min-h-screen bg-gray-50 flex flex-col">
        <Navbar />
        <main className="flex-1">
          <Routes>
            {/* Public routes */}
            <Route path="/" element={<Home />} />
            <Route path="/campaigns" element={<Campaigns />} />
            <Route path="/campaigns/:id" element={<CampaignDetail />} />
            <Route path="/transparency" element={<TransparencyDashboard />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />

            {/* Protected routes */}
            <Route 
              path="/dashboard" 
              element={
                <ProtectedRoute>
                  <Dashboard />
                </ProtectedRoute>
              } 
            />
            
            {/* NGO routes */}
            <Route 
              path="/ngo/create-campaign" 
              element={
                <ProtectedRoute allowedRoles={['ngo']}>
                  <CreateCampaign />
                </ProtectedRoute>
              } 
            />
            <Route 
              path="/ngo/campaigns" 
              element={
                <ProtectedRoute allowedRoles={['ngo']}>
                  <MyCampaigns />
                </ProtectedRoute>
              } 
            />
            <Route 
              path="/ngo/campaigns/:id/manage" 
              element={
                <ProtectedRoute allowedRoles={['ngo']}>
                  <CampaignManagement />
                </ProtectedRoute>
              } 
            />

            {/* Donor routes */}
            <Route 
              path="/donate/:campaignId" 
              element={
                <ProtectedRoute allowedRoles={['donor']}>
                  <Donate />
                </ProtectedRoute>
              } 
            />
            <Route 
              path="/donor/donations" 
              element={
                <ProtectedRoute allowedRoles={['donor']}>
                  <MyDonations />
                </ProtectedRoute>
              } 
            />
            <Route 
              path="/donor/nfts" 
              element={
                <ProtectedRoute allowedRoles={['donor']}>
                  <MyNFTs />
                </ProtectedRoute>
              } 
            />

            {/* Profile */}
            <Route 
              path="/profile" 
              element={
                <ProtectedRoute>
                  <Profile />
                </ProtectedRoute>
              } 
            />

            {/* Catch all route */}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  );
}

export default App;
