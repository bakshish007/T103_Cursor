import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor
api.interceptors.response.use(
  (response) => {
    return response;
  },
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// Auth API
export const authAPI = {
  login: (email, password) => api.post('/auth/login', { email, password }),
  register: (userData) => api.post('/auth/register', userData),
  getProfile: () => api.get('/auth/me'),
  updateProfile: (profileData) => api.put('/auth/profile', profileData),
  changePassword: (currentPassword, newPassword) => 
    api.put('/auth/change-password', { currentPassword, newPassword }),
};

// Campaign API
export const campaignAPI = {
  getCampaigns: (params) => api.get('/campaigns', { params }),
  getCampaign: (id) => api.get(`/campaigns/${id}`),
  createCampaign: (formData) => api.post('/campaigns', formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
  }),
  updateCampaign: (id, data) => api.put(`/campaigns/${id}`, data),
  updateCampaignStatus: (id, status) => api.patch(`/campaigns/${id}/status`, { status }),
  getMyCampaigns: (params) => api.get('/campaigns/ngo/my-campaigns', { params }),
  getCampaignStats: (id) => api.get(`/campaigns/${id}/stats`),
};

// Donation API
export const donationAPI = {
  createDonation: (donationData) => api.post('/donations', donationData),
  confirmPayment: (id) => api.post(`/donations/${id}/confirm-payment`),
  getMyDonations: (params) => api.get('/donations/my-donations', { params }),
  getDonation: (id) => api.get(`/donations/${id}`),
  getCampaignDonations: (campaignId, params) => 
    api.get(`/donations/campaign/${campaignId}`, { params }),
  getReceipt: (id) => api.get(`/donations/${id}/receipt`),
};

// Milestone API
export const milestoneAPI = {
  uploadProof: (campaignId, formData) => 
    api.post(`/milestones/${campaignId}/proof`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    }),
  getProofs: (campaignId) => api.get(`/milestones/${campaignId}/proofs`),
  updateMilestone: (campaignId, milestoneId, data) => 
    api.put(`/milestones/${campaignId}/${milestoneId}`, data),
  completeMilestone: (campaignId, milestoneId) => 
    api.patch(`/milestones/${campaignId}/${milestoneId}/complete`),
  getAllProofs: (params) => api.get('/milestones/proofs/all', { params }),
};

// Blockchain API
export const blockchainAPI = {
  getTransactionStatus: (txHash) => api.get(`/blockchain/transaction/${txHash}`),
  getCampaignData: (campaignId) => api.get(`/blockchain/campaign/${campaignId}`),
  getDonationData: (donationId) => api.get(`/blockchain/donation/${donationId}`),
  getDonorNFTs: (donorAddress) => api.get(`/blockchain/nfts/${donorAddress}`),
  getBlockchainStats: () => api.get('/blockchain/stats'),
  verifyData: (type, id, expectedData) => 
    api.post('/blockchain/verify', { type, id, expectedData }),
};

// Upload API
export const uploadAPI = {
  uploadSingle: (file) => {
    const formData = new FormData();
    formData.append('file', file);
    return api.post('/upload/single', formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    });
  },
  uploadMultiple: (files) => {
    const formData = new FormData();
    files.forEach(file => formData.append('files', file));
    return api.post('/upload/multiple', formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    });
  },
  uploadProfileImage: (file) => {
    const formData = new FormData();
    formData.append('profileImage', file);
    return api.post('/upload/profile', formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    });
  },
  getFileInfo: (filename) => api.get(`/upload/info/${filename}`),
  deleteFile: (filename) => api.delete(`/upload/${filename}`),
};

export default api;
