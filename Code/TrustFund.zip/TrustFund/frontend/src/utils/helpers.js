// Utility helper functions

/**
 * Format currency amount
 * @param {number} amount - Amount to format
 * @param {string} currency - Currency code (default: INR)
 * @returns {string} Formatted currency string
 */
export const formatCurrency = (amount, currency = 'INR') => {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: currency,
    maximumFractionDigits: 0
  }).format(amount);
};

/**
 * Calculate progress percentage
 * @param {number} raised - Amount raised
 * @param {number} target - Target amount
 * @returns {number} Progress percentage (0-100)
 */
export const getProgressPercentage = (raised, target) => {
  if (!target || target === 0) return 0;
  return Math.min(Math.round((raised / target) * 100), 100);
};

/**
 * Get days remaining until end date
 * @param {string|Date} endDate - End date
 * @returns {number} Days remaining
 */
export const getDaysRemaining = (endDate) => {
  const now = new Date();
  const end = new Date(endDate);
  const diffTime = end - now;
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  return diffDays > 0 ? diffDays : 0;
};

/**
 * Get impact level based on donation amount
 * @param {number} amount - Donation amount
 * @returns {object} Impact level object
 */
export const getImpactLevel = (amount) => {
  if (amount >= 10000) return { level: 'High Impact', color: 'bg-red-100 text-red-800' };
  if (amount >= 5000) return { level: 'Medium Impact', color: 'bg-yellow-100 text-yellow-800' };
  if (amount >= 1000) return { level: 'Standard Impact', color: 'bg-blue-100 text-blue-800' };
  return { level: 'Small Impact', color: 'bg-green-100 text-green-800' };
};

/**
 * Get status color class
 * @param {string} status - Status string
 * @returns {string} CSS class for status
 */
export const getStatusColor = (status) => {
  const statusColors = {
    active: 'bg-green-100 text-green-800',
    completed: 'bg-blue-100 text-blue-800',
    cancelled: 'bg-red-100 text-red-800',
    paused: 'bg-yellow-100 text-yellow-800',
    pending: 'bg-yellow-100 text-yellow-800',
    failed: 'bg-red-100 text-red-800',
    refunded: 'bg-gray-100 text-gray-800'
  };
  return statusColors[status] || 'bg-gray-100 text-gray-800';
};

/**
 * Get category color class
 * @param {string} category - Category string
 * @returns {string} CSS class for category
 */
export const getCategoryColor = (category) => {
  const categoryColors = {
    education: 'bg-blue-100 text-blue-800',
    healthcare: 'bg-red-100 text-red-800',
    environment: 'bg-green-100 text-green-800',
    poverty: 'bg-yellow-100 text-yellow-800',
    'disaster-relief': 'bg-orange-100 text-orange-800',
    'women-empowerment': 'bg-pink-100 text-pink-800',
    'child-welfare': 'bg-purple-100 text-purple-800'
  };
  return categoryColors[category] || 'bg-gray-100 text-gray-800';
};

/**
 * Truncate text to specified length
 * @param {string} text - Text to truncate
 * @param {number} maxLength - Maximum length
 * @returns {string} Truncated text
 */
export const truncateText = (text, maxLength = 100) => {
  if (!text) return '';
  if (text.length <= maxLength) return text;
  return text.substring(0, maxLength) + '...';
};

/**
 * Format date to readable string
 * @param {string|Date} date - Date to format
 * @param {object} options - Intl.DateTimeFormat options
 * @returns {string} Formatted date string
 */
export const formatDate = (date, options = {}) => {
  const defaultOptions = {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  };
  return new Date(date).toLocaleDateString('en-IN', { ...defaultOptions, ...options });
};

/**
 * Format date and time
 * @param {string|Date} date - Date to format
 * @returns {string} Formatted date and time string
 */
export const formatDateTime = (date) => {
  return new Date(date).toLocaleString('en-IN', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
};

/**
 * Generate random ID
 * @param {number} length - Length of ID
 * @returns {string} Random ID
 */
export const generateId = (length = 8) => {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
};

/**
 * Validate email format
 * @param {string} email - Email to validate
 * @returns {boolean} Is valid email
 */
export const isValidEmail = (email) => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

/**
 * Validate phone number (Indian format)
 * @param {string} phone - Phone number to validate
 * @returns {boolean} Is valid phone number
 */
export const isValidPhone = (phone) => {
  const phoneRegex = /^[6-9]\d{9}$/;
  return phoneRegex.test(phone.replace(/\D/g, ''));
};

/**
 * Get file extension from filename
 * @param {string} filename - Filename
 * @returns {string} File extension
 */
export const getFileExtension = (filename) => {
  return filename.split('.').pop().toLowerCase();
};

/**
 * Check if file is image
 * @param {string} filename - Filename
 * @returns {boolean} Is image file
 */
export const isImageFile = (filename) => {
  const imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
  return imageExtensions.includes(getFileExtension(filename));
};

/**
 * Check if file is video
 * @param {string} filename - Filename
 * @returns {boolean} Is video file
 */
export const isVideoFile = (filename) => {
  const videoExtensions = ['mp4', 'mov', 'avi'];
  return videoExtensions.includes(getFileExtension(filename));
};

/**
 * Get blockchain explorer URL
 * @param {string} txHash - Transaction hash
 * @param {string} network - Network name
 * @returns {string} Explorer URL
 */
export const getBlockchainExplorerUrl = (txHash, network = 'mumbai') => {
  const baseUrls = {
    mumbai: 'https://mumbai.polygonscan.com',
    amoy: 'https://amoy.polygonscan.com',
    mainnet: 'https://polygonscan.com'
  };
  return `${baseUrls[network]}/tx/${txHash}`;
};

/**
 * Debounce function
 * @param {Function} func - Function to debounce
 * @param {number} wait - Wait time in ms
 * @returns {Function} Debounced function
 */
export const debounce = (func, wait) => {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
};

/**
 * Copy text to clipboard
 * @param {string} text - Text to copy
 * @returns {Promise<boolean>} Success status
 */
export const copyToClipboard = async (text) => {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch (err) {
    console.error('Failed to copy text: ', err);
    return false;
  }
};
