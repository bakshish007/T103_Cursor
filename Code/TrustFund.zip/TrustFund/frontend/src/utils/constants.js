// Application constants
export const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

export const USER_ROLES = {
  NGO: 'ngo',
  DONOR: 'donor'
};

export const CAMPAIGN_CATEGORIES = [
  { value: 'education', label: 'Education' },
  { value: 'healthcare', label: 'Healthcare' },
  { value: 'environment', label: 'Environment' },
  { value: 'poverty', label: 'Poverty Relief' },
  { value: 'disaster-relief', label: 'Disaster Relief' },
  { value: 'women-empowerment', label: 'Women Empowerment' },
  { value: 'child-welfare', label: 'Child Welfare' },
  { value: 'other', label: 'Other' }
];

export const CAMPAIGN_STATUS = {
  ACTIVE: 'active',
  COMPLETED: 'completed',
  CANCELLED: 'cancelled',
  PAUSED: 'paused'
};

export const DONATION_STATUS = {
  PENDING: 'pending',
  COMPLETED: 'completed',
  FAILED: 'failed',
  REFUNDED: 'refunded'
};

export const PAYMENT_METHODS = {
  UPI: 'upi',
  CARD: 'card',
  NETBANKING: 'netbanking',
  WALLET: 'wallet'
};

export const BLOCKCHAIN_NETWORKS = {
  MUMBAI: 'mumbai',
  AMOY: 'amoy',
  MAINNET: 'mainnet'
};

export const POLYGON_SCAN_URLS = {
  mumbai: 'https://mumbai.polygonscan.com',
  amoy: 'https://amoy.polygonscan.com',
  mainnet: 'https://polygonscan.com'
};

export const IMPACT_LEVELS = {
  HIGH: { min: 10000, label: 'High Impact', color: 'bg-red-100 text-red-800' },
  MEDIUM: { min: 5000, label: 'Medium Impact', color: 'bg-yellow-100 text-yellow-800' },
  STANDARD: { min: 1000, label: 'Standard Impact', color: 'bg-blue-100 text-blue-800' },
  SMALL: { min: 0, label: 'Small Impact', color: 'bg-green-100 text-green-800' }
};

export const FILE_TYPES = {
  IMAGE: ['jpg', 'jpeg', 'png', 'gif', 'webp'],
  VIDEO: ['mp4', 'mov', 'avi'],
  DOCUMENT: ['pdf', 'doc', 'docx', 'txt']
};

export const MAX_FILE_SIZE = 50 * 1024 * 1024; // 50MB

export const DEMO_ACCOUNTS = {
  NGO: {
    email: 'ngo@demo.com',
    password: 'password123'
  },
  DONOR: {
    email: 'donor@demo.com',
    password: 'password123'
  }
};
