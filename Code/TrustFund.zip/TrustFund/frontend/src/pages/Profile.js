import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { uploadAPI } from '../services/api';
import { 
  UserCircleIcon, 
  CameraIcon,
  PencilIcon,
  CheckIcon,
  XMarkIcon
} from '@heroicons/react/24/outline';
import LoadingSpinner from '../components/UI/LoadingSpinner';
import toast from 'react-hot-toast';

const Profile = () => {
  const { user, updateProfile, changePassword } = useAuth();
  const [activeTab, setActiveTab] = useState('profile');
  const [loading, setLoading] = useState(false);
  const [editing, setEditing] = useState(false);
  
  const [profileData, setProfileData] = useState({
    name: '',
    phone: '',
    address: {
      street: '',
      city: '',
      state: '',
      pincode: '',
      country: 'India'
    },
    organizationName: '',
    organizationType: '',
    profileImage: '',
    bankAccount: {
      accountNumber: '',
      ifscCode: '',
      bankName: '',
      branch: '',
      accountHolderName: ''
    },
    upiDetails: {
      vpa: '',
      merchantName: ''
    }
  });

  const [passwordData, setPasswordData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });

  useEffect(() => {
    if (user) {
      setProfileData({
        name: user.name || '',
        phone: user.phone || '',
        address: user.address || {
          street: '',
          city: '',
          state: '',
          pincode: '',
          country: 'India'
        },
        organizationName: user.organizationName || '',
        organizationType: user.organizationType || '',
        profileImage: user.profileImage || '',
        bankAccount: user.bankAccount || {
          accountNumber: '',
          ifscCode: '',
          bankName: '',
          branch: '',
          accountHolderName: ''
        },
        upiDetails: user.upiDetails || {
          vpa: '',
          merchantName: ''
        }
      });
    }
  }, [user]);

  const handleProfileChange = (e) => {
    const { name, value } = e.target;
    
    if (name.startsWith('address.')) {
      const addressField = name.split('.')[1];
      setProfileData(prev => ({
        ...prev,
        address: {
          ...prev.address,
          [addressField]: value
        }
      }));
    } else if (name.startsWith('bankAccount.')) {
      const bankField = name.split('.')[1];
      setProfileData(prev => ({
        ...prev,
        bankAccount: {
          ...prev.bankAccount,
          [bankField]: value
        }
      }));
    } else if (name.startsWith('upiDetails.')) {
      const upiField = name.split('.')[1];
      setProfileData(prev => ({
        ...prev,
        upiDetails: {
          ...prev.upiDetails,
          [upiField]: value
        }
      }));
    } else {
      setProfileData(prev => ({
        ...prev,
        [name]: value
      }));
    }
  };

  const handlePasswordChange = (e) => {
    setPasswordData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  const handleImageUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    try {
      setLoading(true);
      const response = await uploadAPI.uploadProfileImage(file);
      setProfileData(prev => ({
        ...prev,
        profileImage: response.data.imageUrl
      }));
      toast.success('Profile image updated successfully');
    } catch (error) {
      console.error('Error uploading image:', error);
      toast.error('Failed to upload image');
    } finally {
      setLoading(false);
    }
  };

  const handleProfileSubmit = async (e) => {
    e.preventDefault();
    try {
      setLoading(true);
      await updateProfile(profileData);
      setEditing(false);
    } catch (error) {
      console.error('Error updating profile:', error);
    } finally {
      setLoading(false);
    }
  };

  const handlePasswordSubmit = async (e) => {
    e.preventDefault();
    
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      toast.error('New passwords do not match');
      return;
    }

    if (passwordData.newPassword.length < 6) {
      toast.error('Password must be at least 6 characters long');
      return;
    }

    try {
      setLoading(true);
      await changePassword(passwordData.currentPassword, passwordData.newPassword);
      setPasswordData({
        currentPassword: '',
        newPassword: '',
        confirmPassword: ''
      });
    } catch (error) {
      console.error('Error changing password:', error);
    } finally {
      setLoading(false);
    }
  };

  const tabs = [
    { id: 'profile', name: 'Profile Information' },
    { id: 'password', name: 'Change Password' }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">
            Profile Settings
          </h1>
          <p className="text-gray-600">
            Manage your account information and preferences
          </p>
        </div>

        {/* Tabs */}
        <div className="mb-8">
          <div className="border-b border-gray-200">
            <nav className="-mb-px flex space-x-8">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`py-2 px-1 border-b-2 font-medium text-sm ${
                    activeTab === tab.id
                      ? 'border-primary-500 text-primary-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  {tab.name}
                </button>
              ))}
            </nav>
          </div>
        </div>

        {/* Profile Tab */}
        {activeTab === 'profile' && (
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-gray-900">
                Profile Information
              </h2>
              {!editing ? (
                <button
                  onClick={() => setEditing(true)}
                  className="btn-outline"
                >
                  <PencilIcon className="h-4 w-4 inline mr-2" />
                  Edit Profile
                </button>
              ) : (
                <div className="flex space-x-2">
                  <button
                    onClick={() => setEditing(false)}
                    className="btn-outline"
                  >
                    <XMarkIcon className="h-4 w-4 inline mr-2" />
                    Cancel
                  </button>
                </div>
              )}
            </div>

            <form onSubmit={handleProfileSubmit}>
              {/* Profile Image */}
              <div className="flex items-center mb-6">
                <div className="relative">
                  <img
                  src={profileData.profileImage || 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?auto=format&fit=crop&w=100&h=100&q=60'}
                    alt="Profile"
                    className="w-20 h-20 rounded-full object-cover"
                  />
                  {editing && (
                    <label className="absolute bottom-0 right-0 bg-primary-600 text-white rounded-full p-1 cursor-pointer hover:bg-primary-700">
                      <CameraIcon className="h-4 w-4" />
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleImageUpload}
                        className="hidden"
                      />
                    </label>
                  )}
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-semibold text-gray-900">
                    {user?.name}
                  </h3>
                  <p className="text-sm text-gray-600">
                    {user?.role === 'ngo' ? 'NGO Account' : 'Donor Account'}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="label">Full Name</label>
                  <input
                    type="text"
                    name="name"
                    value={profileData.name}
                    onChange={handleProfileChange}
                    disabled={!editing}
                    className="input-field"
                  />
                </div>

                <div>
                  <label className="label">Phone Number</label>
                  <input
                    type="tel"
                    name="phone"
                    value={profileData.phone}
                    onChange={handleProfileChange}
                    disabled={!editing}
                    className="input-field"
                  />
                </div>

                {user?.role === 'ngo' && (
                  <>
                    <div>
                      <label className="label">Organization Name</label>
                      <input
                        type="text"
                        name="organizationName"
                        value={profileData.organizationName}
                        onChange={handleProfileChange}
                        disabled={!editing}
                        className="input-field"
                      />
                    </div>

                    <div>
                      <label className="label">Organization Type</label>
                      <select
                        name="organizationType"
                        value={profileData.organizationType}
                        onChange={handleProfileChange}
                        disabled={!editing}
                        className="input-field"
                      >
                        <option value="">Select type</option>
                        <option value="trust">Trust</option>
                        <option value="society">Society</option>
                        <option value="section-8">Section 8 Company</option>
                        <option value="foundation">Foundation</option>
                        <option value="other">Other</option>
                      </select>
                    </div>
                  </>
                )}

                {/* Bank Account Details Section for NGOs */}
                {user?.role === 'ngo' && (
                  <>
                    <div className="col-span-1 md:col-span-2">
                      <h3 className="text-lg font-semibold text-gray-900 mb-4 border-b pb-2">
                        Bank Account Details
                      </h3>
                    </div>

                    <div>
                      <label className="label">Account Number</label>
                      <input
                        type="text"
                        name="bankAccount.accountNumber"
                        value={profileData.bankAccount.accountNumber}
                        onChange={handleProfileChange}
                        disabled={!editing}
                        className="input-field"
                        placeholder="Enter bank account number"
                      />
                    </div>

                    <div>
                      <label className="label">IFSC Code</label>
                      <input
                        type="text"
                        name="bankAccount.ifscCode"
                        value={profileData.bankAccount.ifscCode}
                        onChange={handleProfileChange}
                        disabled={!editing}
                        className="input-field"
                        placeholder="e.g., SBIN0001234"
                        style={{ textTransform: 'uppercase' }}
                      />
                    </div>

                    <div>
                      <label className="label">Bank Name</label>
                      <input
                        type="text"
                        name="bankAccount.bankName"
                        value={profileData.bankAccount.bankName}
                        onChange={handleProfileChange}
                        disabled={!editing}
                        className="input-field"
                        placeholder="e.g., State Bank of India"
                      />
                    </div>

                    <div>
                      <label className="label">Branch</label>
                      <input
                        type="text"
                        name="bankAccount.branch"
                        value={profileData.bankAccount.branch}
                        onChange={handleProfileChange}
                        disabled={!editing}
                        className="input-field"
                        placeholder="e.g., Mumbai Main Branch"
                      />
                    </div>

                    <div>
                      <label className="label">Account Holder Name</label>
                      <input
                        type="text"
                        name="bankAccount.accountHolderName"
                        value={profileData.bankAccount.accountHolderName}
                        onChange={handleProfileChange}
                        disabled={!editing}
                        className="input-field"
                        placeholder="Name as per bank records"
                      />
                    </div>

                    <div className="col-span-1 md:col-span-2">
                      <h3 className="text-lg font-semibold text-gray-900 mb-4 border-b pb-2 mt-6">
                        UPI Details
                      </h3>
                    </div>

                    <div>
                      <label className="label">UPI ID (VPA)</label>
                      <input
                        type="text"
                        name="upiDetails.vpa"
                        value={profileData.upiDetails.vpa}
                        onChange={handleProfileChange}
                        disabled={!editing}
                        className="input-field"
                        placeholder="e.g., yourname@paytm"
                      />
                    </div>

                    <div>
                      <label className="label">Merchant Name</label>
                      <input
                        type="text"
                        name="upiDetails.merchantName"
                        value={profileData.upiDetails.merchantName}
                        onChange={handleProfileChange}
                        disabled={!editing}
                        className="input-field"
                        placeholder="Display name for UPI payments"
                      />
                    </div>
                  </>
                )}

                <div>
                  <label className="label">Street Address</label>
                  <input
                    type="text"
                    name="address.street"
                    value={profileData.address.street}
                    onChange={handleProfileChange}
                    disabled={!editing}
                    className="input-field"
                  />
                </div>

                <div>
                  <label className="label">City</label>
                  <input
                    type="text"
                    name="address.city"
                    value={profileData.address.city}
                    onChange={handleProfileChange}
                    disabled={!editing}
                    className="input-field"
                  />
                </div>

                <div>
                  <label className="label">State</label>
                  <input
                    type="text"
                    name="address.state"
                    value={profileData.address.state}
                    onChange={handleProfileChange}
                    disabled={!editing}
                    className="input-field"
                  />
                </div>

                <div>
                  <label className="label">Pincode</label>
                  <input
                    type="text"
                    name="address.pincode"
                    value={profileData.address.pincode}
                    onChange={handleProfileChange}
                    disabled={!editing}
                    className="input-field"
                  />
                </div>
              </div>

              {editing && (
                <div className="mt-6">
                  <button
                    type="submit"
                    disabled={loading}
                    className="btn-primary"
                  >
                    {loading ? (
                      <LoadingSpinner size="sm" />
                    ) : (
                      <>
                        <CheckIcon className="h-4 w-4 inline mr-2" />
                        Save Changes
                      </>
                    )}
                  </button>
                </div>
              )}
            </form>
          </div>
        )}

        {/* Password Tab */}
        {activeTab === 'password' && (
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-6">
              Change Password
            </h2>

            <form onSubmit={handlePasswordSubmit}>
              <div className="space-y-4">
                <div>
                  <label className="label">Current Password</label>
                  <input
                    type="password"
                    name="currentPassword"
                    value={passwordData.currentPassword}
                    onChange={handlePasswordChange}
                    required
                    className="input-field"
                  />
                </div>

                <div>
                  <label className="label">New Password</label>
                  <input
                    type="password"
                    name="newPassword"
                    value={passwordData.newPassword}
                    onChange={handlePasswordChange}
                    required
                    minLength="6"
                    className="input-field"
                  />
                </div>

                <div>
                  <label className="label">Confirm New Password</label>
                  <input
                    type="password"
                    name="confirmPassword"
                    value={passwordData.confirmPassword}
                    onChange={handlePasswordChange}
                    required
                    minLength="6"
                    className="input-field"
                  />
                </div>
              </div>

              <div className="mt-6">
                <button
                  type="submit"
                  disabled={loading}
                  className="btn-primary"
                >
                  {loading ? (
                    <LoadingSpinner size="sm" />
                  ) : (
                    'Change Password'
                  )}
                </button>
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};

export default Profile;
