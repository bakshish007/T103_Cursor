import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { campaignAPI } from '../../services/api';
import { 
  PlusIcon, 
  EyeIcon,
  PencilIcon,
  ChartBarIcon,
  CurrencyDollarIcon,
  CalendarIcon,
  UsersIcon
} from '@heroicons/react/24/outline';
import LoadingSpinner from '../../components/UI/LoadingSpinner';
import toast from 'react-hot-toast';

const MyCampaigns = () => {
  const [campaigns, setCampaigns] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    status: '',
    page: 1,
    limit: 10
  });
  const [pagination, setPagination] = useState({
    total: 0,
    totalPages: 0,
    currentPage: 1
  });

  useEffect(() => {
    fetchCampaigns();
  }, [filters]);

  const fetchCampaigns = async () => {
    try {
      setLoading(true);
      const response = await campaignAPI.getMyCampaigns(filters);
      setCampaigns(response.data.campaigns);
      setPagination({
        total: response.data.total,
        totalPages: response.data.totalPages,
        currentPage: response.data.currentPage
      });
    } catch (error) {
      console.error('Error fetching campaigns:', error);
      toast.error('Failed to load campaigns');
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(amount);
  };

  const getProgressPercentage = (raised, target) => {
    return Math.min(Math.round((raised / target) * 100), 100);
  };

  const getDaysRemaining = (endDate) => {
    const now = new Date();
    const end = new Date(endDate);
    const diffTime = end - now;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays > 0 ? diffDays : 0;
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-800';
      case 'completed':
        return 'bg-blue-100 text-blue-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      case 'paused':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <LoadingSpinner size="xl" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-4">
              My Campaigns
            </h1>
            <p className="text-gray-600">
              Manage your fundraising campaigns
            </p>
          </div>
          <Link to="/ngo/create-campaign" className="btn-primary">
            <PlusIcon className="h-5 w-5 inline mr-2" />
            Create Campaign
          </Link>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-8">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <label className="label">Filter by Status</label>
              <select
                className="input-field"
                value={filters.status}
                onChange={(e) => setFilters(prev => ({ ...prev, status: e.target.value, page: 1 }))}
              >
                <option value="">All Status</option>
                <option value="active">Active</option>
                <option value="completed">Completed</option>
                <option value="cancelled">Cancelled</option>
                <option value="paused">Paused</option>
              </select>
            </div>
            <div className="flex items-end">
              <button
                onClick={() => setFilters({ status: '', page: 1, limit: 10 })}
                className="btn-outline"
              >
                Clear Filters
              </button>
            </div>
          </div>
        </div>

        {/* Campaigns List */}
        {campaigns.length === 0 ? (
          <div className="text-center py-12">
            <ChartBarIcon className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              No campaigns found
            </h3>
            <p className="text-gray-600 mb-4">
              Create your first campaign to start fundraising.
            </p>
            <Link to="/ngo/create-campaign" className="btn-primary">
              Create Campaign
            </Link>
          </div>
        ) : (
          <div className="space-y-6">
            {campaigns.map((campaign) => (
              <div key={campaign._id} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center mb-2">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(campaign.status)}`}>
                        {campaign.status}
                      </span>
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">
                      {campaign.title}
                    </h3>
                    <p className="text-gray-600 line-clamp-2 mb-3">
                      {campaign.description}
                    </p>
                  </div>
                  <div className="ml-4">
                    <img
                      src={campaign.coverImage || 'https://images.unsplash.com/photo-1515165562835-c3b8c2e0f87f?auto=format&fit=crop&w=200&h=200&q=60'}
                      alt={campaign.title}
                      className="w-20 h-20 object-cover rounded-lg"
                    />
                  </div>
                </div>

                {/* Campaign Stats */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                  <div className="text-center">
                    <div className="text-lg font-bold text-primary-600">
                      {formatCurrency(campaign.raisedAmount)}
                    </div>
                    <div className="text-xs text-gray-600">Raised</div>
                  </div>
                  <div className="text-center">
                    <div className="text-lg font-bold text-secondary-600">
                      {formatCurrency(campaign.targetAmount)}
                    </div>
                    <div className="text-xs text-gray-600">Target</div>
                  </div>
                  <div className="text-center">
                    <div className="text-lg font-bold text-green-600">
                      {getProgressPercentage(campaign.raisedAmount, campaign.targetAmount)}%
                    </div>
                    <div className="text-xs text-gray-600">Progress</div>
                  </div>
                  <div className="text-center">
                    <div className="text-lg font-bold text-orange-600">
                      {getDaysRemaining(campaign.endDate)}
                    </div>
                    <div className="text-xs text-gray-600">Days Left</div>
                  </div>
                </div>

                {/* Progress Bar */}
                <div className="mb-4">
                  <div className="progress-bar">
                    <div 
                      className="progress-fill"
                      style={{ width: `${getProgressPercentage(campaign.raisedAmount, campaign.targetAmount)}%` }}
                    ></div>
                  </div>
                </div>

                {/* Campaign Details */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4 text-sm text-gray-600">
                  <div className="flex items-center">
                    <CalendarIcon className="h-4 w-4 mr-2" />
                    <span>Created: {new Date(campaign.createdAt).toLocaleDateString()}</span>
                  </div>
                  <div className="flex items-center">
                    <CalendarIcon className="h-4 w-4 mr-2" />
                    <span>Ends: {new Date(campaign.endDate).toLocaleDateString()}</span>
                  </div>
                  <div className="flex items-center">
                    <ChartBarIcon className="h-4 w-4 mr-2" />
                    <span>Milestones: {campaign.milestones?.length || 0}</span>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex flex-wrap gap-2 pt-4 border-t border-gray-200">
                  <Link
                    to={`/campaigns/${campaign._id}`}
                    className="btn-outline"
                  >
                    <EyeIcon className="h-4 w-4 inline mr-2" />
                    View Public
                  </Link>
                  <Link
                    to={`/ngo/campaigns/${campaign._id}/manage`}
                    className="btn-outline"
                  >
                    <PencilIcon className="h-4 w-4 inline mr-2" />
                    Manage
                  </Link>
                  <Link
                    to={`/ngo/campaigns/${campaign._id}/donations`}
                    className="btn-outline"
                  >
                    <UsersIcon className="h-4 w-4 inline mr-2" />
                    Donations
                  </Link>
                  <Link
                    to={`/ngo/campaigns/${campaign._id}/proofs`}
                    className="btn-outline"
                  >
                    <ChartBarIcon className="h-4 w-4 inline mr-2" />
                    Upload Proofs
                  </Link>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Pagination */}
        {pagination.totalPages > 1 && (
          <div className="mt-8 flex justify-center">
            <nav className="flex items-center space-x-2">
              <button
                onClick={() => setFilters(prev => ({ ...prev, page: prev.page - 1 }))}
                disabled={pagination.currentPage === 1}
                className="px-3 py-2 text-sm font-medium text-gray-500 bg-white border border-gray-300 rounded-md hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Previous
              </button>
              
              {Array.from({ length: pagination.totalPages }, (_, i) => i + 1).map((page) => (
                <button
                  key={page}
                  onClick={() => setFilters(prev => ({ ...prev, page }))}
                  className={`px-3 py-2 text-sm font-medium rounded-md ${
                    page === pagination.currentPage
                      ? 'bg-primary-600 text-white'
                      : 'text-gray-500 bg-white border border-gray-300 hover:bg-gray-50'
                  }`}
                >
                  {page}
                </button>
              ))}
              
              <button
                onClick={() => setFilters(prev => ({ ...prev, page: prev.page + 1 }))}
                disabled={pagination.currentPage === pagination.totalPages}
                className="px-3 py-2 text-sm font-medium text-gray-500 bg-white border border-gray-300 rounded-md hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Next
              </button>
            </nav>
          </div>
        )}
      </div>
    </div>
  );
};

export default MyCampaigns;
