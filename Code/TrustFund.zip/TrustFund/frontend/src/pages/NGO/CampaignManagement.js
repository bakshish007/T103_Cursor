import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { campaignAPI, milestoneAPI } from '../../services/api';
import { 
  ArrowLeftIcon,
  PencilIcon,
  PhotoIcon,
  MapPinIcon,
  CalendarIcon,
  CurrencyDollarIcon,
  ChartBarIcon,
  PlusIcon
} from '@heroicons/react/24/outline';
import LoadingSpinner from '../../components/UI/LoadingSpinner';
import toast from 'react-hot-toast';

const CampaignManagement = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [campaign, setCampaign] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');
  const [uploadingProof, setUploadingProof] = useState(false);

  useEffect(() => {
    fetchCampaign();
  }, [id]);

  const fetchCampaign = async () => {
    try {
      setLoading(true);
      const response = await campaignAPI.getCampaign(id);
      setCampaign(response.data);
    } catch (error) {
      console.error('Error fetching campaign:', error);
      toast.error('Failed to load campaign details');
      navigate('/ngo/campaigns');
    } finally {
      setLoading(false);
    }
  };

  const handleStatusChange = async (newStatus) => {
    try {
      await campaignAPI.updateCampaignStatus(id, newStatus);
      setCampaign(prev => ({ ...prev, status: newStatus }));
      toast.success('Campaign status updated successfully');
    } catch (error) {
      console.error('Error updating status:', error);
      toast.error('Failed to update campaign status');
    }
  };

  const handleProofUpload = async (milestoneId, formData) => {
    try {
      setUploadingProof(true);
      await milestoneAPI.uploadProof(id, formData);
      toast.success('Proof uploaded successfully');
      fetchCampaign(); // Refresh campaign data
    } catch (error) {
      console.error('Error uploading proof:', error);
      toast.error('Failed to upload proof');
    } finally {
      setUploadingProof(false);
    }
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(amount);
  };

  const getProgressPercentage = (raised, target) => {
    return Math.min(Math.round((raised / target) * 100), 100);
  };

  const getDaysRemaining = (endDate) => {
    const now = new Date();
    const end = new Date(endDate);
    const diffTime = end - now;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays > 0 ? diffDays : 0;
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-800';
      case 'completed':
        return 'bg-blue-100 text-blue-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      case 'paused':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <LoadingSpinner size="xl" />
      </div>
    );
  }

  if (!campaign) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Campaign Not Found</h2>
          <button onClick={() => navigate('/ngo/campaigns')} className="btn-primary">
            Back to Campaigns
          </button>
        </div>
      </div>
    );
  }

  const tabs = [
    { id: 'overview', name: 'Overview' },
    { id: 'milestones', name: 'Milestones' },
    { id: 'settings', name: 'Settings' }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <button
            onClick={() => navigate('/ngo/campaigns')}
            className="flex items-center text-gray-600 hover:text-gray-900 mb-4"
          >
            <ArrowLeftIcon className="h-5 w-5 mr-2" />
            Back to Campaigns
          </button>
          
          <div className="flex items-start justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">
                {campaign.title}
              </h1>
              <div className="flex items-center space-x-4">
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(campaign.status)}`}>
                  {campaign.status}
                </span>
                <span className="text-sm text-gray-600">
                  Created {new Date(campaign.createdAt).toLocaleDateString()}
                </span>
              </div>
            </div>
            <div className="flex space-x-2">
              <button className="btn-outline">
                <PencilIcon className="h-4 w-4 inline mr-2" />
                Edit Campaign
              </button>
            </div>
          </div>
        </div>

        {/* Campaign Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="card text-center">
            <div className="text-2xl font-bold text-primary-600 mb-1">
              {formatCurrency(campaign.raisedAmount)}
            </div>
            <div className="text-sm text-gray-600">Raised</div>
          </div>
          <div className="card text-center">
            <div className="text-2xl font-bold text-secondary-600 mb-1">
              {formatCurrency(campaign.targetAmount)}
            </div>
            <div className="text-sm text-gray-600">Target</div>
          </div>
          <div className="card text-center">
            <div className="text-2xl font-bold text-green-600 mb-1">
              {getProgressPercentage(campaign.raisedAmount, campaign.targetAmount)}%
            </div>
            <div className="text-sm text-gray-600">Progress</div>
          </div>
          <div className="card text-center">
            <div className="text-2xl font-bold text-orange-600 mb-1">
              {getDaysRemaining(campaign.endDate)}
            </div>
            <div className="text-sm text-gray-600">Days Left</div>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="card mb-8">
          <div className="progress-bar">
            <div 
              className="progress-fill"
              style={{ width: `${getProgressPercentage(campaign.raisedAmount, campaign.targetAmount)}%` }}
            ></div>
          </div>
          <div className="flex justify-between text-sm text-gray-600 mt-2">
            <span>{formatCurrency(campaign.raisedAmount)} raised</span>
            <span>of {formatCurrency(campaign.targetAmount)}</span>
          </div>
        </div>

        {/* Tabs */}
        <div className="mb-8">
          <div className="border-b border-gray-200">
            <nav className="-mb-px flex space-x-8">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`py-2 px-1 border-b-2 font-medium text-sm ${
                    activeTab === tab.id
                      ? 'border-primary-500 text-primary-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  {tab.name}
                </button>
              ))}
            </nav>
          </div>
        </div>

        {/* Tab Content */}
        {activeTab === 'overview' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Campaign Details */}
            <div className="card">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Campaign Details</h2>
              <div className="space-y-4">
                <div>
                  <img
                    src={campaign.coverImage || 'https://images.unsplash.com/photo-1509099836639-18ba1795216d?auto=format&fit=crop&w=800&h=400&q=60'}
                    alt={campaign.title}
                    className="w-full h-48 object-cover rounded-lg mb-4"
                  />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2">Description</h3>
                  <p className="text-gray-600">{campaign.description}</p>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h4 className="font-medium text-gray-900">Category</h4>
                    <p className="text-gray-600 capitalize">{campaign.category}</p>
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900">End Date</h4>
                    <p className="text-gray-600">{new Date(campaign.endDate).toLocaleDateString()}</p>
                  </div>
                </div>
                {campaign.location?.city && (
                  <div>
                    <h4 className="font-medium text-gray-900">Location</h4>
                    <p className="text-gray-600">
                      {campaign.location.city}, {campaign.location.state}, {campaign.location.country}
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* Recent Activity */}
            <div className="card">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Recent Activity</h2>
              <div className="space-y-4">
                <div className="text-center py-8">
                  <ChartBarIcon className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600">No recent activity</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'milestones' && (
          <div className="card">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-gray-900">Campaign Milestones</h2>
              <button className="btn-outline">
                <PlusIcon className="h-4 w-4 inline mr-2" />
                Add Milestone
              </button>
            </div>

            {campaign.milestones && campaign.milestones.length > 0 ? (
              <div className="space-y-6">
                {campaign.milestones.map((milestone, index) => (
                  <div key={milestone._id} className="border border-gray-200 rounded-lg p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h3 className="text-lg font-semibold text-gray-900 mb-2">
                          {milestone.title}
                        </h3>
                        <p className="text-gray-600 mb-2">{milestone.description}</p>
                        <div className="text-sm text-gray-500">
                          Target: {formatCurrency(milestone.targetAmount)}
                        </div>
                      </div>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        milestone.isCompleted 
                          ? 'bg-green-100 text-green-800' 
                          : 'bg-yellow-100 text-yellow-800'
                      }`}>
                        {milestone.isCompleted ? 'Completed' : 'Pending'}
                      </span>
                    </div>

                    {/* Proof Upload */}
                    {!milestone.isCompleted && (
                      <div className="border-t border-gray-200 pt-4">
                        <h4 className="font-medium text-gray-900 mb-2">Upload Proof</h4>
                        <div className="flex items-center space-x-4">
                          <input
                            type="file"
                            multiple
                            accept="image/*,video/*,.pdf"
                            className="hidden"
                            id={`proof-${milestone._id}`}
                            onChange={(e) => {
                              const formData = new FormData();
                              formData.append('milestoneId', milestone._id);
                              formData.append('description', 'Proof of milestone completion');
                              Array.from(e.target.files).forEach(file => {
                                formData.append('proofFiles', file);
                              });
                              handleProofUpload(milestone._id, formData);
                            }}
                          />
                          <label
                            htmlFor={`proof-${milestone._id}`}
                            className="btn-outline cursor-pointer"
                          >
                            <PhotoIcon className="h-4 w-4 inline mr-2" />
                            Upload Proof
                          </label>
                        </div>
                      </div>
                    )}

                    {/* Proof Files */}
                    {milestone.proofFiles && milestone.proofFiles.length > 0 && (
                      <div className="border-t border-gray-200 pt-4">
                        <h4 className="font-medium text-gray-900 mb-2">Proof Files</h4>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                          {milestone.proofFiles.map((file, fileIndex) => (
                            <img
                              key={fileIndex}
                              src={file}
                              alt={`Proof ${fileIndex + 1}`}
                              className="w-full h-20 object-cover rounded border"
                            />
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <ChartBarIcon className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600">No milestones defined</p>
              </div>
            )}
          </div>
        )}

        {activeTab === 'settings' && (
          <div className="card">
            <h2 className="text-xl font-semibold text-gray-900 mb-6">Campaign Settings</h2>
            
            <div className="space-y-6">
              <div>
                <h3 className="font-medium text-gray-900 mb-3">Campaign Status</h3>
                <div className="flex space-x-2">
                  {['active', 'paused', 'completed', 'cancelled'].map((status) => (
                    <button
                      key={status}
                      onClick={() => handleStatusChange(status)}
                      className={`px-3 py-1 rounded-full text-sm font-medium ${
                        campaign.status === status
                          ? getStatusColor(status)
                          : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                      }`}
                    >
                      {status.charAt(0).toUpperCase() + status.slice(1)}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="font-medium text-gray-900 mb-3">Danger Zone</h3>
                <div className="border border-red-200 rounded-lg p-4">
                  <h4 className="font-medium text-red-900 mb-2">Delete Campaign</h4>
                  <p className="text-sm text-red-600 mb-3">
                    Once you delete a campaign, there is no going back. Please be certain.
                  </p>
                  <button className="bg-red-600 text-white px-3 py-1 rounded text-sm hover:bg-red-700">
                    Delete Campaign
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default CampaignManagement;
