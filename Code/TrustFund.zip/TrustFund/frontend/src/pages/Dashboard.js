import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { 
  PlusIcon, 
  HeartIcon, 
  ChartBarIcon,
  UserGroupIcon,
  CurrencyDollarIcon,
  ShieldCheckIcon
} from '@heroicons/react/24/outline';

const Dashboard = () => {
  const { user } = useAuth();

  const ngoQuickActions = [
    {
      title: 'Create Campaign',
      description: 'Start a new fundraising campaign',
      icon: PlusIcon,
      link: '/ngo/create-campaign',
      color: 'bg-primary-500'
    },
    {
      title: 'My Campaigns',
      description: 'Manage your existing campaigns',
      icon: ChartBarIcon,
      link: '/ngo/campaigns',
      color: 'bg-secondary-500'
    },
    {
      title: 'Upload Proofs',
      description: 'Add milestone proofs and updates',
      icon: ShieldCheckIcon,
      link: '/ngo/campaigns',
      color: 'bg-green-500'
    }
  ];

  const donorQuickActions = [
    {
      title: 'Browse Campaigns',
      description: 'Discover campaigns to support',
      icon: HeartIcon,
      link: '/campaigns',
      color: 'bg-primary-500'
    },
    {
      title: 'My Donations',
      description: 'View your donation history',
      icon: CurrencyDollarIcon,
      link: '/donor/donations',
      color: 'bg-secondary-500'
    },
    {
      title: 'My NFTs',
      description: 'View your impact NFT collection',
      icon: ShieldCheckIcon,
      link: '/donor/nfts',
      color: 'bg-purple-500'
    }
  ];

  const quickActions = user?.role === 'ngo' ? ngoQuickActions : donorQuickActions;

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">
            Welcome back, {user?.name}!
          </h1>
          <p className="text-gray-600 mt-2">
            {user?.role === 'ngo' 
              ? 'Manage your campaigns and track your impact'
              : 'Discover campaigns and track your donations'
            }
          </p>
        </div>

        {/* Quick Actions */}
        <div className="mb-8">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Quick Actions</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {quickActions.map((action, index) => (
              <Link
                key={index}
                to={action.link}
                className="card hover:shadow-lg transition-shadow duration-200 group"
              >
                <div className="flex items-center mb-4">
                  <div className={`p-3 ${action.color} rounded-lg group-hover:scale-110 transition-transform duration-200`}>
                    <action.icon className="h-6 w-6 text-white" />
                  </div>
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  {action.title}
                </h3>
                <p className="text-gray-600">
                  {action.description}
                </p>
              </Link>
            ))}
          </div>
        </div>

        {/* Stats Overview */}
        <div className="mb-8">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Overview</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {user?.role === 'ngo' ? (
              <>
                <div className="card text-center">
                  <div className="text-2xl font-bold text-primary-600 mb-1">
                    {user.totalCampaigns || 0}
                  </div>
                  <div className="text-sm text-gray-600">Total Campaigns</div>
                </div>
                <div className="card text-center">
                  <div className="text-2xl font-bold text-secondary-600 mb-1">
                    ₹{user.totalDonations?.toLocaleString() || 0}
                  </div>
                  <div className="text-sm text-gray-600">Total Raised</div>
                </div>
                <div className="card text-center">
                  <div className="text-2xl font-bold text-green-600 mb-1">
                    {user.totalCampaigns || 0}
                  </div>
                  <div className="text-sm text-gray-600">Active Campaigns</div>
                </div>
                <div className="card text-center">
                  <div className="text-2xl font-bold text-purple-600 mb-1">
                    95%
                  </div>
                  <div className="text-sm text-gray-600">Transparency Score</div>
                </div>
              </>
            ) : (
              <>
                <div className="card text-center">
                  <div className="text-2xl font-bold text-primary-600 mb-1">
                    {user.totalDonations || 0}
                  </div>
                  <div className="text-sm text-gray-600">Total Donations</div>
                </div>
                <div className="card text-center">
                  <div className="text-2xl font-bold text-secondary-600 mb-1">
                    ₹{user.totalDonations?.toLocaleString() || 0}
                  </div>
                  <div className="text-sm text-gray-600">Total Amount</div>
                </div>
                <div className="card text-center">
                  <div className="text-2xl font-bold text-green-600 mb-1">
                    5
                  </div>
                  <div className="text-sm text-gray-600">Impact NFTs</div>
                </div>
                <div className="card text-center">
                  <div className="text-2xl font-bold text-purple-600 mb-1">
                    3
                  </div>
                  <div className="text-sm text-gray-600">Campaigns Supported</div>
                </div>
              </>
            )}
          </div>
        </div>

        {/* Recent Activity */}
        <div className="mb-8">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Recent Activity</h2>
          <div className="card">
            <div className="text-center py-8">
              <UserGroupIcon className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500">
                {user?.role === 'ngo' 
                  ? 'No recent activity. Create your first campaign to get started!'
                  : 'No recent donations. Browse campaigns to make your first donation!'
                }
              </p>
              <Link
                to={user?.role === 'ngo' ? '/ngo/create-campaign' : '/campaigns'}
                className="btn-primary mt-4 inline-block"
              >
                {user?.role === 'ngo' ? 'Create Campaign' : 'Browse Campaigns'}
              </Link>
            </div>
          </div>
        </div>

        {/* Transparency Section */}
        <div className="mb-8">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Transparency & Impact</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="card">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Blockchain Verification</h3>
              <p className="text-gray-600 mb-4">
                All transactions are recorded on the Polygon blockchain for complete transparency.
              </p>
              <Link
                to="/transparency"
                className="btn-outline"
              >
                View Transparency Dashboard
              </Link>
            </div>
            <div className="card">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Impact Tracking</h3>
              <p className="text-gray-600 mb-4">
                Track the real-world impact of your contributions with verified proof and milestones.
              </p>
              <Link
                to={user?.role === 'ngo' ? '/ngo/campaigns' : '/donor/donations'}
                className="btn-outline"
              >
                View Impact Details
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
