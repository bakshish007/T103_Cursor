import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { milestoneAPI, blockchainAPI } from '../services/api';
import { 
  ShieldCheckIcon, 
  MapPinIcon,
  EyeIcon,
  ChartBarIcon,
  GlobeAltIcon,
  CurrencyDollarIcon
} from '@heroicons/react/24/outline';
import LoadingSpinner from '../components/UI/LoadingSpinner';
import toast from 'react-hot-toast';

const TransparencyDashboard = () => {
  const [proofs, setProofs] = useState([]);
  const [blockchainStats, setBlockchainStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [mapCenter, setMapCenter] = useState([20.5937, 78.9629]); // India center
  const [mapZoom, setMapZoom] = useState(5);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      setLoading(true);
      const [proofsResponse, statsResponse] = await Promise.all([
        milestoneAPI.getAllProofs(),
        blockchainAPI.getBlockchainStats()
      ]);
      
      setProofs(proofsResponse.data.proofs);
      setBlockchainStats(statsResponse.data);
    } catch (error) {
      console.error('Error fetching transparency data:', error);
      toast.error('Failed to load transparency data');
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(amount);
  };

  const getProofType = (files) => {
    if (!files || files.length === 0) return 'No files';
    const extensions = files.map(file => file.split('.').pop().toLowerCase());
    if (extensions.some(ext => ['jpg', 'jpeg', 'png', 'gif'].includes(ext))) {
      return 'Images';
    }
    if (extensions.some(ext => ['mp4', 'mov', 'avi'].includes(ext))) {
      return 'Videos';
    }
    return 'Documents';
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <LoadingSpinner size="xl" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">
            Transparency Dashboard
          </h1>
          <p className="text-gray-600">
            Complete transparency in charitable giving through blockchain technology
          </p>
        </div>

        {/* Blockchain Stats */}
        {blockchainStats && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div className="card text-center">
              <div className="text-3xl font-bold text-primary-600 mb-2">
                {blockchainStats.totalCampaigns || 0}
              </div>
              <div className="text-sm text-gray-600">Campaigns on Blockchain</div>
            </div>
            <div className="card text-center">
              <div className="text-3xl font-bold text-secondary-600 mb-2">
                {blockchainStats.totalDonations || 0}
              </div>
              <div className="text-sm text-gray-600">Donations Recorded</div>
            </div>
            <div className="card text-center">
              <div className="text-3xl font-bold text-green-600 mb-2">
                {blockchainStats.totalProofs || 0}
              </div>
              <div className="text-sm text-gray-600">Proofs Uploaded</div>
            </div>
            <div className="card text-center">
              <div className="text-3xl font-bold text-purple-600 mb-2">
                {blockchainStats.totalNFTs || 0}
              </div>
              <div className="text-sm text-gray-600">Impact NFTs Minted</div>
            </div>
          </div>
        )}

        {/* Map Section */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-gray-900 flex items-center">
              <MapPinIcon className="h-5 w-5 mr-2" />
              Proof Locations
            </h2>
            <div className="text-sm text-gray-600">
              {proofs.filter(p => p.geoLocation).length} locations with proof
            </div>
          </div>
          
          <div className="h-96 bg-gray-100 rounded-lg flex items-center justify-center">
            <div className="text-center">
              <GlobeAltIcon className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600 mb-2">Interactive Map</p>
              <p className="text-sm text-gray-500">
                Map integration would show proof locations here
              </p>
              <p className="text-xs text-gray-400 mt-2">
                Powered by Leaflet.js and OpenStreetMap
              </p>
            </div>
          </div>
        </div>

        {/* Proofs List */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-gray-900 flex items-center">
              <ShieldCheckIcon className="h-5 w-5 mr-2" />
              Verified Proofs of Impact
            </h2>
            <div className="text-sm text-gray-600">
              {proofs.length} total proofs
            </div>
          </div>

          {proofs.length === 0 ? (
            <div className="text-center py-12">
              <ShieldCheckIcon className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                No Proofs Available
              </h3>
              <p className="text-gray-600">
                Proofs will appear here as NGOs upload milestone verification.
              </p>
            </div>
          ) : (
            <div className="space-y-6">
              {proofs.map((proof, index) => (
                <div key={index} className="border border-gray-200 rounded-lg p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900 mb-1">
                        {proof.milestoneTitle}
                      </h3>
                      <p className="text-sm text-gray-600 mb-2">
                        Campaign: {proof.campaignTitle}
                      </p>
                      <p className="text-sm text-gray-500">
                        NGO: {proof.ngoName}
                      </p>
                    </div>
                    <div className="text-right">
                      <div className="text-sm text-gray-500 mb-1">
                        Completed
                      </div>
                      <div className="text-sm font-medium text-gray-900">
                        {new Date(proof.completionDate).toLocaleDateString()}
                      </div>
                    </div>
                  </div>

                  {/* Proof Files */}
                  {proof.proofFiles && proof.proofFiles.length > 0 && (
                    <div className="mb-4">
                      <div className="flex items-center mb-2">
                        <EyeIcon className="h-4 w-4 mr-1 text-gray-400" />
                        <span className="text-sm font-medium text-gray-700">
                          Proof Files ({getProofType(proof.proofFiles)})
                        </span>
                      </div>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                        {proof.proofFiles.slice(0, 4).map((file, fileIndex) => (
                          <div key={fileIndex} className="relative">
                            <img
                              src={file}
                              alt={`Proof ${fileIndex + 1}`}
                              className="w-full h-20 object-cover rounded border"
                              onError={(e) => {
                                e.target.style.display = 'none';
                                e.target.nextSibling.style.display = 'flex';
                              }}
                            />
                            <div 
                              className="w-full h-20 bg-gray-100 rounded border flex items-center justify-center text-xs text-gray-500"
                              style={{ display: 'none' }}
                            >
                              File
                            </div>
                          </div>
                        ))}
                        {proof.proofFiles.length > 4 && (
                          <div className="w-full h-20 bg-gray-100 rounded border flex items-center justify-center text-xs text-gray-500">
                            +{proof.proofFiles.length - 4} more
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Location */}
                  {proof.geoLocation && (
                    <div className="mb-4">
                      <div className="flex items-center text-sm text-gray-600">
                        <MapPinIcon className="h-4 w-4 mr-1" />
                        <span>
                          {proof.geoLocation.address || 
                           `${proof.geoLocation.latitude.toFixed(4)}, ${proof.geoLocation.longitude.toFixed(4)}`}
                        </span>
                      </div>
                    </div>
                  )}

                  {/* Blockchain Verification */}
                  {proof.blockchainTxHash && (
                    <div className="flex items-center justify-between pt-4 border-t border-gray-200">
                      <div className="flex items-center text-sm text-gray-600">
                        <ShieldCheckIcon className="h-4 w-4 mr-1" />
                        <span>Blockchain Verified</span>
                      </div>
                      <a
                        href={`https://polygonscan.com/tx/${proof.blockchainTxHash}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-sm text-primary-600 hover:text-primary-500"
                      >
                        View Transaction
                      </a>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* How It Works */}
        <div className="mt-8 bg-gradient-to-r from-primary-600 to-secondary-600 rounded-lg p-8 text-white">
          <h2 className="text-2xl font-bold mb-4">How Transparency Works</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="w-12 h-12 bg-white bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-3">
                <ChartBarIcon className="h-6 w-6" />
              </div>
              <h3 className="font-semibold mb-2">Campaign Creation</h3>
              <p className="text-sm opacity-90">
                NGOs create campaigns with clear milestones and goals, all recorded on blockchain.
              </p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-white bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-3">
                <CurrencyDollarIcon className="h-6 w-6" />
              </div>
              <h3 className="font-semibold mb-2">Donation Tracking</h3>
              <p className="text-sm opacity-90">
                Every donation is recorded on blockchain with instant NFT rewards for donors.
              </p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-white bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-3">
                <ShieldCheckIcon className="h-6 w-6" />
              </div>
              <h3 className="font-semibold mb-2">Proof Verification</h3>
              <p className="text-sm opacity-90">
                NGOs upload proof of impact with geo-location, stored on IPFS and blockchain.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TransparencyDashboard;
