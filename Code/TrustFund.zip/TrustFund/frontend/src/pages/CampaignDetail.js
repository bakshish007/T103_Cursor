import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { campaignAPI } from '../services/api';
import { 
  HeartIcon, 
  CurrencyDollarIcon, 
  CalendarIcon,
  MapPinIcon,
  UserGroupIcon,
  ShieldCheckIcon,
  ClockIcon,
  EyeIcon
} from '@heroicons/react/24/outline';
import LoadingSpinner from '../components/UI/LoadingSpinner';
import toast from 'react-hot-toast';

const CampaignDetail = () => {
  const { id } = useParams();
  const [campaign, setCampaign] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchCampaign();
  }, [id]);

  const fetchCampaign = async () => {
    try {
      setLoading(true);
      const response = await campaignAPI.getCampaign(id);
      setCampaign(response.data);
    } catch (error) {
      console.error('Error fetching campaign:', error);
      toast.error('Failed to load campaign details');
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(amount);
  };

  const getProgressPercentage = (raised, target) => {
    return Math.min(Math.round((raised / target) * 100), 100);
  };

  const getDaysRemaining = (endDate) => {
    const now = new Date();
    const end = new Date(endDate);
    const diffTime = end - now;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays > 0 ? diffDays : 0;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <LoadingSpinner size="xl" />
      </div>
    );
  }

  if (!campaign) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Campaign Not Found</h2>
          <Link to="/campaigns" className="btn-primary">
            Browse All Campaigns
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Campaign Header */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden mb-8">
          {/* Cover Image */}
          <div className="relative h-64 md:h-96">
            <img
              src={campaign.coverImage || 'https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?auto=format&fit=crop&w=1200&h=400&q=60'}
              alt={campaign.title}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-black bg-opacity-30"></div>
            <div className="absolute bottom-4 left-4 right-4">
              <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">
                {campaign.title}
              </h1>
              <div className="flex items-center text-white">
                <UserGroupIcon className="h-5 w-5 mr-2" />
                <span>{campaign.ngoId?.organizationName || campaign.ngoId?.name}</span>
              </div>
            </div>
          </div>

          {/* Campaign Stats */}
          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
              <div className="text-center">
                <div className="text-2xl font-bold text-primary-600 mb-1">
                  {formatCurrency(campaign.raisedAmount)}
                </div>
                <div className="text-sm text-gray-600">Raised</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-secondary-600 mb-1">
                  {formatCurrency(campaign.targetAmount)}
                </div>
                <div className="text-sm text-gray-600">Target</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600 mb-1">
                  {getProgressPercentage(campaign.raisedAmount, campaign.targetAmount)}%
                </div>
                <div className="text-sm text-gray-600">Progress</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-orange-600 mb-1">
                  {getDaysRemaining(campaign.endDate)}
                </div>
                <div className="text-sm text-gray-600">Days Left</div>
              </div>
            </div>

            {/* Progress Bar */}
            <div className="mb-6">
              <div className="progress-bar">
                <div 
                  className="progress-fill"
                  style={{ width: `${getProgressPercentage(campaign.raisedAmount, campaign.targetAmount)}%` }}
                ></div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-4">
              <Link
                to={`/donate/${campaign._id}`}
                className="btn-primary flex-1 text-center"
              >
                <HeartIcon className="h-5 w-5 inline mr-2" />
                Donate Now
              </Link>
              <button className="btn-outline flex-1">
                <EyeIcon className="h-5 w-5 inline mr-2" />
                Share Campaign
              </button>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Description */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">About This Campaign</h2>
              <div className="prose max-w-none">
                <p className="text-gray-700 leading-relaxed">
                  {campaign.description}
                </p>
              </div>
            </div>

            {/* Milestones */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Campaign Milestones</h2>
              {campaign.milestones && campaign.milestones.length > 0 ? (
                <div className="space-y-4">
                  {campaign.milestones.map((milestone, index) => (
                    <div key={milestone._id} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex items-start justify-between mb-2">
                        <h3 className="text-lg font-semibold text-gray-900">
                          {milestone.title}
                        </h3>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          milestone.isCompleted 
                            ? 'bg-green-100 text-green-800' 
                            : 'bg-yellow-100 text-yellow-800'
                        }`}>
                          {milestone.isCompleted ? 'Completed' : 'Pending'}
                        </span>
                      </div>
                      <p className="text-gray-600 mb-2">{milestone.description}</p>
                      <div className="text-sm text-gray-500">
                        Target: {formatCurrency(milestone.targetAmount)}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-gray-600">No milestones defined for this campaign.</p>
              )}
            </div>

            {/* Images */}
            {campaign.images && campaign.images.length > 0 && (
              <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Campaign Images</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {campaign.images.map((image, index) => (
                    <img
                      key={index}
                      src={image}
                      alt={`Campaign image ${index + 1}`}
                      className="w-full h-48 object-cover rounded-lg"
                    />
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Campaign Info */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Campaign Information</h3>
              <div className="space-y-3">
                <div className="flex items-center text-sm">
                  <CalendarIcon className="h-4 w-4 mr-2 text-gray-400" />
                  <span className="text-gray-600">Started:</span>
                  <span className="ml-auto font-medium">
                    {new Date(campaign.startDate).toLocaleDateString()}
                  </span>
                </div>
                <div className="flex items-center text-sm">
                  <ClockIcon className="h-4 w-4 mr-2 text-gray-400" />
                  <span className="text-gray-600">Ends:</span>
                  <span className="ml-auto font-medium">
                    {new Date(campaign.endDate).toLocaleDateString()}
                  </span>
                </div>
                {campaign.location?.city && (
                  <div className="flex items-center text-sm">
                    <MapPinIcon className="h-4 w-4 mr-2 text-gray-400" />
                    <span className="text-gray-600">Location:</span>
                    <span className="ml-auto font-medium">
                      {campaign.location.city}, {campaign.location.state}
                    </span>
                  </div>
                )}
                <div className="flex items-center text-sm">
                  <ShieldCheckIcon className="h-4 w-4 mr-2 text-gray-400" />
                  <span className="text-gray-600">Transparency:</span>
                  <span className="ml-auto font-medium">
                    {campaign.transparencyScore}%
                  </span>
                </div>
              </div>
            </div>

            {/* NGO Info */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Organized By</h3>
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-gray-200 rounded-full flex items-center justify-center mr-3">
                  <span className="text-lg font-medium text-gray-600">
                    {campaign.ngoId?.name?.charAt(0) || 'N'}
                  </span>
                </div>
                <div>
                  <div className="font-semibold text-gray-900">
                    {campaign.ngoId?.organizationName || campaign.ngoId?.name}
                  </div>
                  <div className="text-sm text-gray-600">
                    {campaign.ngoId?.organizationType}
                  </div>
                </div>
              </div>
              <div className="text-sm text-gray-600">
                <div>Total Campaigns: {campaign.ngoId?.totalCampaigns || 0}</div>
                <div>Total Raised: {formatCurrency(campaign.ngoId?.totalDonations || 0)}</div>
              </div>
            </div>

            {/* Tags */}
            {campaign.tags && campaign.tags.length > 0 && (
              <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Tags</h3>
                <div className="flex flex-wrap gap-2">
                  {campaign.tags.map((tag, index) => (
                    <span
                      key={index}
                      className="px-2 py-1 bg-gray-100 text-gray-700 rounded-full text-sm"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CampaignDetail;
