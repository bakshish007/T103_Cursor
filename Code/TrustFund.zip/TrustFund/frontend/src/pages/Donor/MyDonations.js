import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { donationAPI } from '../../services/api';
import { 
  HeartIcon, 
  CurrencyDollarIcon, 
  CalendarIcon,
  EyeIcon,
  CheckCircleIcon,
  ClockIcon,
  XCircleIcon
} from '@heroicons/react/24/outline';
import LoadingSpinner from '../../components/UI/LoadingSpinner';
import toast from 'react-hot-toast';

const MyDonations = () => {
  const [donations, setDonations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    status: '',
    page: 1,
    limit: 10
  });
  const [pagination, setPagination] = useState({
    total: 0,
    totalPages: 0,
    currentPage: 1
  });

  useEffect(() => {
    fetchDonations();
  }, [filters]);

  const fetchDonations = async () => {
    try {
      setLoading(true);
      const response = await donationAPI.getMyDonations(filters);
      setDonations(response.data.donations);
      setPagination({
        total: response.data.total,
        totalPages: response.data.totalPages,
        currentPage: response.data.currentPage
      });
    } catch (error) {
      console.error('Error fetching donations:', error);
      toast.error('Failed to load donations');
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(amount);
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'completed':
        return <CheckCircleIcon className="h-5 w-5 text-green-600" />;
      case 'pending':
        return <ClockIcon className="h-5 w-5 text-yellow-600" />;
      case 'failed':
        return <XCircleIcon className="h-5 w-5 text-red-600" />;
      default:
        return <ClockIcon className="h-5 w-5 text-gray-600" />;
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'failed':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <LoadingSpinner size="xl" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">
            My Donations
          </h1>
          <p className="text-gray-600">
            Track your donation history and impact
          </p>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-8">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <label className="label">Filter by Status</label>
              <select
                className="input-field"
                value={filters.status}
                onChange={(e) => setFilters(prev => ({ ...prev, status: e.target.value, page: 1 }))}
              >
                <option value="">All Status</option>
                <option value="completed">Completed</option>
                <option value="pending">Pending</option>
                <option value="failed">Failed</option>
              </select>
            </div>
            <div className="flex items-end">
              <button
                onClick={() => setFilters({ status: '', page: 1, limit: 10 })}
                className="btn-outline"
              >
                Clear Filters
              </button>
            </div>
          </div>
        </div>

        {/* Donations List */}
        {donations.length === 0 ? (
          <div className="text-center py-12">
            <HeartIcon className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              No donations found
            </h3>
            <p className="text-gray-600 mb-4">
              You haven't made any donations yet.
            </p>
            <Link to="/campaigns" className="btn-primary">
              Browse Campaigns
            </Link>
          </div>
        ) : (
          <div className="space-y-6">
            {donations.map((donation) => (
              <div key={donation._id} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center mb-2">
                      {getStatusIcon(donation.paymentStatus)}
                      <span className={`ml-2 px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(donation.paymentStatus)}`}>
                        {donation.paymentStatus}
                      </span>
                    </div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-1">
                      {donation.campaignId?.title}
                    </h3>
                    <p className="text-sm text-gray-600">
                      {donation.campaignId?.ngoId?.organizationName || donation.campaignId?.ngoId?.name}
                    </p>
                  </div>
                  <div className="text-right">
                    <div className="text-xl font-bold text-primary-600">
                      {formatCurrency(donation.amount)}
                    </div>
                    <div className="text-sm text-gray-500">
                      {new Date(donation.createdAt).toLocaleDateString()}
                    </div>
                  </div>
                </div>

                {/* Donation Details */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                  <div>
                    <div className="text-sm text-gray-500">Donation ID</div>
                    <div className="text-sm font-medium text-gray-900">
                      {donation._id.slice(-8)}
                    </div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-500">Transaction ID</div>
                    <div className="text-sm font-medium text-gray-900">
                      {donation.upiTransactionId || 'Pending'}
                    </div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-500">Receipt Number</div>
                    <div className="text-sm font-medium text-gray-900">
                      {donation.receiptNumber || 'Not generated'}
                    </div>
                  </div>
                </div>

                {/* Message */}
                {donation.donorMessage && (
                  <div className="mb-4 p-3 bg-gray-50 rounded-lg">
                    <div className="text-sm text-gray-500 mb-1">Your Message:</div>
                    <div className="text-sm text-gray-900">{donation.donorMessage}</div>
                  </div>
                )}

                {/* NFT Info */}
                {donation.nftId && (
                  <div className="mb-4 p-3 bg-purple-50 rounded-lg">
                    <div className="flex items-center">
                      <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center mr-3">
                        <span className="text-purple-600 text-sm font-bold">NFT</span>
                      </div>
                      <div>
                        <div className="text-sm font-medium text-purple-900">Impact NFT Received</div>
                        <div className="text-xs text-purple-600">Token ID: {donation.nftId}</div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Blockchain Info */}
                {donation.blockchainTxHash && (
                  <div className="mb-4 p-3 bg-blue-50 rounded-lg">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center mr-3">
                          <span className="text-blue-600 text-sm font-bold">⛓</span>
                        </div>
                        <div>
                          <div className="text-sm font-medium text-blue-900">Blockchain Verified</div>
                          <div className="text-xs text-blue-600">Transaction recorded on Polygon</div>
                        </div>
                      </div>
                      <a
                        href={`https://polygonscan.com/tx/${donation.blockchainTxHash}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-sm text-blue-600 hover:text-blue-500"
                      >
                        View Transaction
                      </a>
                    </div>
                  </div>
                )}

                {/* Actions */}
                <div className="flex flex-col sm:flex-row gap-2 pt-4 border-t border-gray-200">
                  <Link
                    to={`/campaigns/${donation.campaignId?._id}`}
                    className="btn-outline flex-1 text-center"
                  >
                    <EyeIcon className="h-4 w-4 inline mr-2" />
                    View Campaign
                  </Link>
                  {donation.paymentStatus === 'completed' && (
                    <Link
                      to={`/donations/${donation._id}/receipt`}
                      className="btn-outline flex-1 text-center"
                    >
                      <CalendarIcon className="h-4 w-4 inline mr-2" />
                      Download Receipt
                    </Link>
                  )}
                  {donation.nftId && (
                    <Link
                      to="/donor/nfts"
                      className="btn-primary flex-1 text-center"
                    >
                      <HeartIcon className="h-4 w-4 inline mr-2" />
                      View NFT
                    </Link>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Pagination */}
        {pagination.totalPages > 1 && (
          <div className="mt-8 flex justify-center">
            <nav className="flex items-center space-x-2">
              <button
                onClick={() => setFilters(prev => ({ ...prev, page: prev.page - 1 }))}
                disabled={pagination.currentPage === 1}
                className="px-3 py-2 text-sm font-medium text-gray-500 bg-white border border-gray-300 rounded-md hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Previous
              </button>
              
              {Array.from({ length: pagination.totalPages }, (_, i) => i + 1).map((page) => (
                <button
                  key={page}
                  onClick={() => setFilters(prev => ({ ...prev, page }))}
                  className={`px-3 py-2 text-sm font-medium rounded-md ${
                    page === pagination.currentPage
                      ? 'bg-primary-600 text-white'
                      : 'text-gray-500 bg-white border border-gray-300 hover:bg-gray-50'
                  }`}
                >
                  {page}
                </button>
              ))}
              
              <button
                onClick={() => setFilters(prev => ({ ...prev, page: prev.page + 1 }))}
                disabled={pagination.currentPage === pagination.totalPages}
                className="px-3 py-2 text-sm font-medium text-gray-500 bg-white border border-gray-300 rounded-md hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Next
              </button>
            </nav>
          </div>
        )}
      </div>
    </div>
  );
};

export default MyDonations;
