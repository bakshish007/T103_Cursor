import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { campaignAPI, donationAPI } from '../../services/api';
import api from '../../services/api';
import { 
  HeartIcon, 
  CurrencyDollarIcon, 
  QrCodeIcon,
  CheckCircleIcon,
  XCircleIcon
} from '@heroicons/react/24/outline';
import LoadingSpinner from '../../components/UI/LoadingSpinner';
import toast from 'react-hot-toast';

const Donate = () => {
  const { campaignId } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  
  const [campaign, setCampaign] = useState(null);
  const [donation, setDonation] = useState(null);
  const [loading, setLoading] = useState(true);
  const [donating, setDonating] = useState(false);
  const [confirming, setConfirming] = useState(false);
  const [formData, setFormData] = useState({
    amount: '',
    donorMessage: '',
    isAnonymous: false
  });

  useEffect(() => {
    fetchCampaign();
  }, [campaignId]);

  const fetchCampaign = async () => {
    try {
      setLoading(true);
      const response = await campaignAPI.getCampaign(campaignId);
      setCampaign(response.data);
    } catch (error) {
      console.error('Error fetching campaign:', error);
      toast.error('Failed to load campaign details');
      navigate('/campaigns');
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleCreateDonation = async (e) => {
    e.preventDefault();
    
    if (!formData.amount || parseFloat(formData.amount) <= 0) {
      toast.error('Please enter a valid donation amount');
      return;
    }

    try {
      setDonating(true);
      const response = await donationAPI.createDonation({
        campaignId,
        amount: parseFloat(formData.amount),
        donorMessage: formData.donorMessage,
        isAnonymous: formData.isAnonymous
      });
      
      setDonation(response.data.donation);
      console.log('Donation created:', response.data.donation);
      console.log('Donation ID from response:', response.data.donation.id);
      toast.success('Donation created! Please scan QR code to complete payment.');
    } catch (error) {
      console.error('Error creating donation:', error);
      toast.error('Failed to create donation');
    } finally {
      setDonating(false);
    }
  };

  const handleConfirmPayment = async () => {
    try {
      setConfirming(true);
      console.log('Confirming payment for donation:', donation);
      console.log('Donation ID:', donation?.id || donation?._id);
      console.log('Full donation object:', JSON.stringify(donation, null, 2));
      
      // Check authentication status
      console.log('Current user:', user);
      console.log('Auth token in localStorage:', localStorage.getItem('token'));
      console.log('API default headers:', api.defaults.headers);
      
      const donationId = donation?.id || donation?._id;
      if (!donationId) {
        console.error('No donation ID found');
        toast.error('Donation ID not found');
        return;
      }
      
      if (!user) {
        console.error('User not authenticated');
        toast.error('Please log in to confirm payment');
        return;
      }
      
      console.log('Making API call to confirm payment for ID:', donationId);
      console.log('API endpoint:', `/donations/${donationId}/confirm-payment`);
      
      const response = await donationAPI.confirmPayment(donationId);
      console.log('Payment confirmation response:', response);
      
      toast.success('Payment confirmed! You will receive an Impact NFT shortly.');
      navigate('/donor/donations');
    } catch (error) {
      console.error('Error confirming payment:', error);
      console.error('Error details:', {
        message: error.message,
        response: error.response?.data,
        status: error.response?.status,
        statusText: error.response?.statusText,
        config: error.config
      });
      toast.error('Failed to confirm payment');
    } finally {
      setConfirming(false);
    }
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(amount);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <LoadingSpinner size="xl" />
      </div>
    );
  }

  if (!campaign) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Campaign Not Found</h2>
          <button onClick={() => navigate('/campaigns')} className="btn-primary">
            Browse Campaigns
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Make a Donation
          </h1>
          <p className="text-gray-600">
            Support <span className="font-semibold">{campaign.title}</span> and make a real impact
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Campaign Summary */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Campaign Summary</h2>
            
            <div className="mb-4">
              <img
                src={campaign.coverImage || 'https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?auto=format&fit=crop&w=800&h=400&q=60'}
                alt={campaign.title}
                className="w-full h-32 object-cover rounded-lg mb-4"
              />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                {campaign.title}
              </h3>
              <p className="text-gray-600 text-sm line-clamp-3">
                {campaign.description}
              </p>
            </div>

            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-600">Target Amount:</span>
                <span className="font-semibold">{formatCurrency(campaign.targetAmount)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Raised Amount:</span>
                <span className="font-semibold text-green-600">
                  {formatCurrency(campaign.raisedAmount)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Progress:</span>
                <span className="font-semibold">
                  {Math.round((campaign.raisedAmount / campaign.targetAmount) * 100)}%
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Organized by:</span>
                <span className="font-semibold">
                  {campaign.ngoId?.organizationName || campaign.ngoId?.name}
                </span>
              </div>
            </div>
          </div>

          {/* Donation Form */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            {!donation ? (
              <form onSubmit={handleCreateDonation}>
                <h2 className="text-xl font-semibold text-gray-900 mb-4">Donation Details</h2>
                
                <div className="space-y-4">
                  <div>
                    <label className="label">Donation Amount (₹)</label>
                    <input
                      type="number"
                      name="amount"
                      required
                      min="1"
                      className="input-field"
                      placeholder="Enter amount"
                      value={formData.amount}
                      onChange={handleChange}
                    />
                  </div>

                  <div>
                    <label className="label">Message (Optional)</label>
                    <textarea
                      name="donorMessage"
                      rows="3"
                      className="input-field"
                      placeholder="Leave a message for the NGO..."
                      value={formData.donorMessage}
                      onChange={handleChange}
                    />
                  </div>

                  <div className="flex items-center">
                    <input
                      type="checkbox"
                      name="isAnonymous"
                      id="isAnonymous"
                      className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
                      checked={formData.isAnonymous}
                      onChange={handleChange}
                    />
                    <label htmlFor="isAnonymous" className="ml-2 block text-sm text-gray-900">
                      Make this donation anonymous
                    </label>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={donating}
                  className="w-full btn-primary mt-6"
                >
                  {donating ? (
                    <LoadingSpinner size="sm" />
                  ) : (
                    <>
                      <HeartIcon className="h-5 w-5 inline mr-2" />
                      Create Donation
                    </>
                  )}
                </button>
              </form>
            ) : (
              <div>
                <h2 className="text-xl font-semibold text-gray-900 mb-4">Complete Payment</h2>
                
                <div className="text-center mb-6">
                  <div className="text-2xl font-bold text-gray-900 mb-2">
                    {formatCurrency(donation.amount)}
                  </div>
                  <p className="text-gray-600">Scan QR code to complete payment</p>
                </div>

                {/* QR Code */}
                <div className="text-center mb-6">
                  {donation.qrCode && (
                    <div className="inline-block p-4 bg-white border rounded-lg">
                      <img
                        src={donation.qrCode}
                        alt="UPI QR Code"
                        className="w-48 h-48 mx-auto"
                      />
                    </div>
                  )}
                </div>

                {/* Payment Instructions */}
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
                  <h3 className="font-semibold text-blue-900 mb-2">Payment Instructions:</h3>
                  <ol className="text-sm text-blue-800 space-y-1">
                    <li>1. Open your UPI app (Paytm, PhonePe, Google Pay, etc.)</li>
                    <li>2. Scan the QR code above</li>
                    <li>3. Enter the amount: {formatCurrency(donation.amount)}</li>
                    <li>4. Complete the payment</li>
                    <li>5. Click "Mark as Paid" below</li>
                  </ol>
                </div>

                {/* Action Buttons */}
                <div className="space-y-3">
                  <button
                    onClick={handleConfirmPayment}
                    disabled={confirming}
                    className="w-full btn-primary"
                  >
                    {confirming ? (
                      <LoadingSpinner size="sm" />
                    ) : (
                      <>
                        <CheckCircleIcon className="h-5 w-5 inline mr-2" />
                        Mark as Paid
                      </>
                    )}
                  </button>
                  
                  <button
                    onClick={() => {
                      setDonation(null);
                      setFormData({ amount: '', donorMessage: '', isAnonymous: false });
                    }}
                    className="w-full btn-outline"
                  >
                    <XCircleIcon className="h-5 w-5 inline mr-2" />
                    Cancel Donation
                  </button>
                </div>

                {/* Donation Info */}
                <div className="mt-6 pt-4 border-t border-gray-200">
                  <div className="text-sm text-gray-600 space-y-1">
                    <div>Donation ID: {donation.id}</div>
                    <div>Status: <span className="text-yellow-600 font-medium">Pending Payment</span></div>
                    <div>Created: {new Date(donation.createdAt).toLocaleString()}</div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Benefits Section */}
        <div className="mt-8 bg-gradient-to-r from-primary-600 to-secondary-600 rounded-lg p-6 text-white">
          <h2 className="text-xl font-semibold mb-4">Your Donation Benefits</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center">
              <div className="w-8 h-8 bg-white bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-2">
                <QrCodeIcon className="h-4 w-4" />
              </div>
              <div className="text-sm font-medium">Instant Confirmation</div>
              <div className="text-xs opacity-90">Immediate payment verification</div>
            </div>
            <div className="text-center">
              <div className="w-8 h-8 bg-white bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-2">
                <CurrencyDollarIcon className="h-4 w-4" />
              </div>
              <div className="text-sm font-medium">Impact NFT</div>
              <div className="text-xs opacity-90">Receive a unique NFT reward</div>
            </div>
            <div className="text-center">
              <div className="w-8 h-8 bg-white bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-2">
                <HeartIcon className="h-4 w-4" />
              </div>
              <div className="text-sm font-medium">Track Impact</div>
              <div className="text-xs opacity-90">See how your donation helps</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Donate;
