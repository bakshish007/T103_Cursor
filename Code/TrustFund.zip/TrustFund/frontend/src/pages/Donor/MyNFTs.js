import React, { useState, useEffect } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { blockchainAPI } from '../../services/api';
import { 
  HeartIcon, 
  CurrencyDollarIcon, 
  CalendarIcon,
  EyeIcon,
  ShieldCheckIcon,
  SparklesIcon
} from '@heroicons/react/24/outline';
import LoadingSpinner from '../../components/UI/LoadingSpinner';
import toast from 'react-hot-toast';

const MyNFTs = () => {
  const { user } = useAuth();
  const [nfts, setNfts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user?.walletAddress) {
      fetchNFTs();
    } else {
      setLoading(false);
    }
  }, [user]);

  const fetchNFTs = async () => {
    try {
      setLoading(true);
      const response = await blockchainAPI.getDonorNFTs(user.walletAddress);
      setNfts(response.data);
    } catch (error) {
      console.error('Error fetching NFTs:', error);
      toast.error('Failed to load NFTs');
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(amount);
  };

  const getImpactLevel = (amount) => {
    if (amount >= 10000) return { level: 'High Impact', color: 'bg-red-100 text-red-800' };
    if (amount >= 5000) return { level: 'Medium Impact', color: 'bg-yellow-100 text-yellow-800' };
    if (amount >= 1000) return { level: 'Standard Impact', color: 'bg-blue-100 text-blue-800' };
    return { level: 'Small Impact', color: 'bg-green-100 text-green-800' };
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <LoadingSpinner size="xl" />
      </div>
    );
  }

  if (!user?.walletAddress) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <ShieldCheckIcon className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Wallet Not Connected</h2>
          <p className="text-gray-600 mb-4">
            Connect your wallet to view your Impact NFTs
          </p>
          <button className="btn-primary">
            Connect Wallet
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">
            My Impact NFTs
          </h1>
          <p className="text-gray-600">
            Your collection of Impact NFTs representing your charitable contributions
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="card text-center">
            <div className="text-2xl font-bold text-primary-600 mb-1">
              {nfts.length}
            </div>
            <div className="text-sm text-gray-600">Total NFTs</div>
          </div>
          <div className="card text-center">
            <div className="text-2xl font-bold text-secondary-600 mb-1">
              {formatCurrency(nfts.reduce((sum, nft) => sum + parseFloat(nft.impactData.amount), 0))}
            </div>
            <div className="text-sm text-gray-600">Total Donated</div>
          </div>
          <div className="card text-center">
            <div className="text-2xl font-bold text-green-600 mb-1">
              {new Set(nfts.map(nft => nft.impactData.campaignId)).size}
            </div>
            <div className="text-sm text-gray-600">Campaigns Supported</div>
          </div>
          <div className="card text-center">
            <div className="text-2xl font-bold text-purple-600 mb-1">
              {nfts.filter(nft => parseFloat(nft.impactData.amount) >= 10000).length}
            </div>
            <div className="text-sm text-gray-600">High Impact NFTs</div>
          </div>
        </div>

        {/* NFTs Grid */}
        {nfts.length === 0 ? (
          <div className="text-center py-12">
            <SparklesIcon className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              No NFTs Yet
            </h3>
            <p className="text-gray-600 mb-4">
              Make your first donation to receive an Impact NFT!
            </p>
            <a href="/campaigns" className="btn-primary">
              Browse Campaigns
            </a>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {nfts.map((nft) => {
              const impactLevel = getImpactLevel(parseFloat(nft.impactData.amount));
              return (
                <div key={nft.tokenId} className="nft-card">
                  {/* NFT Image */}
                  <div className="relative mb-4">
                    <img
                      src={nft.tokenURI || 'https://images.unsplash.com/photo-1616712134411-6b6ae89bc9f1?auto=format&fit=crop&w=600&h=600&q=60'}
                      alt={`Impact NFT ${nft.tokenId}`}
                      className="w-full h-48 object-cover rounded-lg"
                    />
                    <div className="absolute top-2 right-2">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${impactLevel.color}`}>
                        {impactLevel.level}
                      </span>
                    </div>
                    <div className="absolute bottom-2 left-2">
                      <span className="bg-black bg-opacity-50 text-white px-2 py-1 rounded text-xs">
                        #{nft.tokenId}
                      </span>
                    </div>
                  </div>

                  {/* NFT Details */}
                  <div className="mb-4">
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">
                      {nft.impactData.campaignTitle}
                    </h3>
                    <p className="text-sm text-gray-600 mb-3">
                      {nft.impactData.impactMessage}
                    </p>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-500">Donation Amount:</span>
                        <span className="font-semibold text-gray-900">
                          {formatCurrency(nft.impactData.amount)}
                        </span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-500">Donation Date:</span>
                        <span className="font-semibold text-gray-900">
                          {new Date(nft.impactData.timestamp * 1000).toLocaleDateString()}
                        </span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-500">Donor:</span>
                        <span className="font-semibold text-gray-900">
                          {nft.impactData.donorName}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex space-x-2">
                    <button className="flex-1 btn-outline text-sm">
                      <EyeIcon className="h-4 w-4 inline mr-1" />
                      View Details
                    </button>
                    <button className="flex-1 btn-primary text-sm">
                      <ShieldCheckIcon className="h-4 w-4 inline mr-1" />
                      Verify
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* How NFTs Work */}
        <div className="mt-12 bg-gradient-to-r from-purple-600 to-pink-600 rounded-lg p-8 text-white">
          <h2 className="text-2xl font-bold mb-4">How Impact NFTs Work</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="w-12 h-12 bg-white bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-3">
                <HeartIcon className="h-6 w-6" />
              </div>
              <h3 className="font-semibold mb-2">Make a Donation</h3>
              <p className="text-sm opacity-90">
                Donate to any campaign and complete the payment process.
              </p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-white bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-3">
                <SparklesIcon className="h-6 w-6" />
              </div>
              <h3 className="font-semibold mb-2">Receive NFT</h3>
              <p className="text-sm opacity-90">
                Get a unique Impact NFT representing your contribution.
              </p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-white bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-3">
                <ShieldCheckIcon className="h-6 w-6" />
              </div>
              <h3 className="font-semibold mb-2">Track Impact</h3>
              <p className="text-sm opacity-90">
                Use your NFT to track the real-world impact of your donation.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MyNFTs;
