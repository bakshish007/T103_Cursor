import React from 'react';
import { Link } from 'react-router-dom';
import { 
  HeartIcon, 
  ShieldCheckIcon, 
  GlobeAltIcon,
  ChartBarIcon,
  UserGroupIcon,
  CurrencyDollarIcon
} from '@heroicons/react/24/outline';

const Home = () => {
  const features = [
    {
      icon: ShieldCheckIcon,
      title: 'Blockchain Transparency',
      description: 'Every donation and milestone is recorded on the blockchain for complete transparency and accountability.'
    },
    {
      icon: HeartIcon,
      title: 'Real Impact',
      description: 'See exactly how your donations are being used with verified proof of impact and milestone tracking.'
    },
    {
      icon: GlobeAltIcon,
      title: 'Global Reach',
      description: 'Support causes across India with our comprehensive network of verified NGOs and campaigns.'
    },
    {
      icon: ChartBarIcon,
      title: 'Transparency Score',
      description: 'Each campaign has a transparency score based on proof uploads and milestone completion.'
    },
    {
      icon: UserGroupIcon,
      title: 'Community Driven',
      description: 'Join a community of donors and NGOs working together to create positive change.'
    },
    {
      icon: CurrencyDollarIcon,
      title: 'UPI Integration',
      description: 'Easy donations through UPI with instant confirmation and NFT rewards for your impact.'
    }
  ];

  const stats = [
    { label: 'Campaigns', value: '500+', description: 'Active campaigns' },
    { label: 'Donations', value: '₹50L+', description: 'Total raised' },
    { label: 'NGOs', value: '100+', description: 'Verified organizations' },
    { label: 'Impact NFTs', value: '10K+', description: 'Minted tokens' }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-primary-600 via-primary-700 to-secondary-600 text-white">
        <div className="absolute inset-0 bg-black opacity-20"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              TrustFund
              <span className="block text-secondary-300">Transparent Donations - Real Impact</span>
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-gray-200 max-w-3xl mx-auto">
              Donate with confidence knowing every rupee is tracked on the blockchain. 
              See your impact in real-time with verified proof and NFT rewards.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                to="/campaigns"
                className="btn-secondary text-lg px-8 py-3"
              >
                Browse Campaigns
              </Link>
              <Link
                to="/register"
                className="btn-outline text-lg px-8 py-3 bg-white text-primary-600 hover:bg-gray-50"
              >
                Start Donating
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-3xl md:text-4xl font-bold text-primary-600 mb-2">
                  {stat.value}
                </div>
                <div className="text-lg font-semibold text-gray-900 mb-1">
                  {stat.label}
                </div>
                <div className="text-sm text-gray-600">
                  {stat.description}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Why Choose TrustFund?
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              We're revolutionizing charitable giving with blockchain technology, 
              ensuring complete transparency and accountability in every donation.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <div key={index} className="card hover:shadow-lg transition-shadow duration-300">
                <div className="flex items-center mb-4">
                  <div className="p-3 bg-primary-100 rounded-lg">
                    <feature.icon className="h-6 w-6 text-primary-600" />
                  </div>
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">
                  {feature.title}
                </h3>
                <p className="text-gray-600">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              How It Works
            </h2>
            <p className="text-xl text-gray-600">
              Simple steps to make a transparent impact
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-primary-600 text-white rounded-full flex items-center justify-center text-2xl font-bold mx-auto mb-4">
                1
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">
                Browse Campaigns
              </h3>
              <p className="text-gray-600">
                Explore verified campaigns from trusted NGOs with transparent goals and milestones.
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-primary-600 text-white rounded-full flex items-center justify-center text-2xl font-bold mx-auto mb-4">
                2
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">
                Donate Securely
              </h3>
              <p className="text-gray-600">
                Make donations through UPI with instant confirmation and blockchain recording.
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-primary-600 text-white rounded-full flex items-center justify-center text-2xl font-bold mx-auto mb-4">
                3
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">
                Track Impact
              </h3>
              <p className="text-gray-600">
                Receive NFT rewards and track your impact through verified proof and milestones.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-primary-600 to-secondary-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Ready to Make a Transparent Impact?
          </h2>
          <p className="text-xl mb-8 text-gray-200 max-w-2xl mx-auto">
            Join thousands of donors and NGOs creating real change with complete transparency.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/register"
              className="btn-secondary text-lg px-8 py-3"
            >
              Get Started Today
            </Link>
            <Link
              to="/transparency"
              className="btn-outline text-lg px-8 py-3 bg-white text-primary-600 hover:bg-gray-50"
            >
              View Transparency Dashboard
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
