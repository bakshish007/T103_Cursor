const express = require('express');
const multer = require('multer');
const path = require('path');
const Campaign = require('../models/Campaign');
const { auth, requireNGO } = require('../middleware/auth');
const blockchainService = require('../services/blockchain');
const ipfsService = require('../services/ipfs');

const router = express.Router();

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({ 
  storage: storage,
  limits: { fileSize: 50 * 1024 * 1024 }, // 50MB limit for videos
  fileFilter: (req, file, cb) => {
    const allowedTypes = /jpeg|jpg|png|gif|webp|mp4|mov|avi|pdf|doc|docx/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);
    
    if (mimetype && extname) {
      return cb(null, true);
    } else {
      cb(new Error('Only images, videos, and documents are allowed'));
    }
  }
});

// Upload milestone proof
router.post('/:campaignId/proof', auth, requireNGO, upload.array('proofFiles', 10), async (req, res) => {
  try {
    const { campaignId } = req.params;
    const { milestoneId, description, latitude, longitude, address } = req.body;

    // Verify campaign exists and belongs to NGO
    const campaign = await Campaign.findById(campaignId);
    if (!campaign) {
      return res.status(404).json({ message: 'Campaign not found' });
    }

    if (campaign.ngoId.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Not authorized to upload proof for this campaign' });
    }

    // Find milestone
    const milestone = campaign.milestones.id(milestoneId);
    if (!milestone) {
      return res.status(404).json({ message: 'Milestone not found' });
    }

    // Upload proof files to IPFS
    const proofFileHashes = [];
    if (req.files && req.files.length > 0) {
      for (const file of req.files) {
        try {
          const ipfsUrl = await ipfsService.uploadFile(file.path, file.originalname);
          proofFileHashes.push(ipfsUrl);
        } catch (error) {
          console.error('Error uploading proof file to IPFS:', error);
          // Fallback to local storage
          const localUrl = await ipfsService.storeLocally(file.path, file.originalname);
          proofFileHashes.push(localUrl);
        }
      }
    }

    // Update milestone with proof
    milestone.proofHash = proofFileHashes.join(',');
    milestone.proofFiles = proofFileHashes;
    milestone.isCompleted = true;
    milestone.completionDate = new Date();
    milestone.description = description || milestone.description;

    // Add geo-location if provided
    if (latitude && longitude) {
      milestone.geoLocation = {
        latitude: parseFloat(latitude),
        longitude: parseFloat(longitude),
        address: address || ''
      };
    }

    // Log to blockchain
    try {
      const txHash = await blockchainService.logProof(
        milestoneId,
        campaignId,
        milestone.proofHash,
        milestone.geoLocation?.latitude || 0,
        milestone.geoLocation?.longitude || 0
      );
      milestone.blockchainTxHash = txHash;
    } catch (error) {
      console.error('Error logging proof to blockchain:', error);
    }

    await campaign.save();

    // Recalculate transparency score
    campaign.calculateTransparencyScore();
    await campaign.save();

    res.json({
      message: 'Proof uploaded successfully',
      milestone: {
        id: milestone._id,
        title: milestone.title,
        isCompleted: milestone.isCompleted,
        proofFiles: milestone.proofFiles,
        geoLocation: milestone.geoLocation,
        blockchainTxHash: milestone.blockchainTxHash,
        completionDate: milestone.completionDate
      },
      transparencyScore: campaign.transparencyScore
    });
  } catch (error) {
    console.error('Error uploading proof:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get milestone proofs (public)
router.get('/:campaignId/proofs', async (req, res) => {
  try {
    const campaign = await Campaign.findById(req.params.campaignId)
      .select('milestones ngoId title');

    if (!campaign) {
      return res.status(404).json({ message: 'Campaign not found' });
    }

    const proofs = campaign.milestones
      .filter(milestone => milestone.isCompleted && milestone.proofFiles.length > 0)
      .map(milestone => ({
        id: milestone._id,
        title: milestone.title,
        description: milestone.description,
        proofFiles: milestone.proofFiles,
        geoLocation: milestone.geoLocation,
        completionDate: milestone.completionDate,
        blockchainTxHash: milestone.blockchainTxHash
      }));

    res.json({
      campaignId: campaign._id,
      campaignTitle: campaign.title,
      proofs
    });
  } catch (error) {
    console.error('Error fetching proofs:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Update milestone
router.put('/:campaignId/:milestoneId', auth, requireNGO, async (req, res) => {
  try {
    const { campaignId, milestoneId } = req.params;
    const { title, description, targetAmount } = req.body;

    const campaign = await Campaign.findById(campaignId);
    if (!campaign) {
      return res.status(404).json({ message: 'Campaign not found' });
    }

    if (campaign.ngoId.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Not authorized to update this milestone' });
    }

    const milestone = campaign.milestones.id(milestoneId);
    if (!milestone) {
      return res.status(404).json({ message: 'Milestone not found' });
    }

    if (milestone.isCompleted) {
      return res.status(400).json({ message: 'Cannot update completed milestone' });
    }

    // Update milestone fields
    if (title) milestone.title = title;
    if (description) milestone.description = description;
    if (targetAmount) milestone.targetAmount = parseFloat(targetAmount);

    await campaign.save();

    res.json({
      message: 'Milestone updated successfully',
      milestone
    });
  } catch (error) {
    console.error('Error updating milestone:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Mark milestone as completed (without proof)
router.patch('/:campaignId/:milestoneId/complete', auth, requireNGO, async (req, res) => {
  try {
    const { campaignId, milestoneId } = req.params;

    const campaign = await Campaign.findById(campaignId);
    if (!campaign) {
      return res.status(404).json({ message: 'Campaign not found' });
    }

    if (campaign.ngoId.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Not authorized to complete this milestone' });
    }

    const milestone = campaign.milestones.id(milestoneId);
    if (!milestone) {
      return res.status(404).json({ message: 'Milestone not found' });
    }

    milestone.isCompleted = true;
    milestone.completionDate = new Date();

    await campaign.save();

    res.json({
      message: 'Milestone marked as completed',
      milestone
    });
  } catch (error) {
    console.error('Error completing milestone:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get all proofs for transparency dashboard
router.get('/proofs/all', async (req, res) => {
  try {
    const { page = 1, limit = 20, campaignId } = req.query;
    const query = { status: 'active' };
    
    if (campaignId) query._id = campaignId;

    const campaigns = await Campaign.find(query)
      .populate('ngoId', 'name organizationName')
      .select('title ngoId milestones')
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const allProofs = [];
    campaigns.forEach(campaign => {
      campaign.milestones.forEach(milestone => {
        if (milestone.isCompleted && milestone.proofFiles.length > 0) {
          allProofs.push({
            campaignId: campaign._id,
            campaignTitle: campaign.title,
            ngoName: campaign.ngoId.name,
            milestoneId: milestone._id,
            milestoneTitle: milestone.title,
            proofFiles: milestone.proofFiles,
            geoLocation: milestone.geoLocation,
            completionDate: milestone.completionDate,
            blockchainTxHash: milestone.blockchainTxHash
          });
        }
      });
    });

    res.json({
      proofs: allProofs,
      total: allProofs.length
    });
  } catch (error) {
    console.error('Error fetching all proofs:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
