const express = require('express');
const mongoose = require('mongoose');
const QRCode = require('qrcode');
const Donation = require('../models/Donation');
const Campaign = require('../models/Campaign');
const User = require('../models/User');
const { auth, requireDonor } = require('../middleware/auth');
const blockchainService = require('../services/blockchain');
const ipfsService = require('../services/ipfs');
const paymentService = require('../services/payment');

const router = express.Router();

// Test endpoint to verify donation ID format
router.get('/test/:id', (req, res) => {
  const isValid = mongoose.Types.ObjectId.isValid(req.params.id);
  res.json({
    id: req.params.id,
    isValid,
    length: req.params.id.length
  });
});

// Get payment configuration (public endpoint)
router.get('/payment-config', async (req, res) => {
  try {
    const { campaignId } = req.query;
    let ngoUser = null;
    
    // If campaignId is provided, get NGO-specific payment details
    if (campaignId) {
      const campaign = await Campaign.findById(campaignId);
      if (campaign) {
        ngoUser = await User.findById(campaign.ngoId);
      }
    }
    
    const config = paymentService.getPaymentConfig(ngoUser);
    res.json({
      success: true,
      config,
      ngoInfo: ngoUser ? {
        organizationName: ngoUser.organizationName,
        hasBankDetails: !!(ngoUser.bankAccount?.accountNumber),
        hasUPIDetails: !!(ngoUser.upiDetails?.vpa)
      } : null
    });
  } catch (error) {
    console.error('Error getting payment config:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Create donation with UPI QR
router.post('/', auth, requireDonor, async (req, res) => {
  try {
    const { campaignId, amount, donorMessage, isAnonymous } = req.body;

    // Verify campaign exists and is active
    const campaign = await Campaign.findById(campaignId);
    if (!campaign) {
      return res.status(404).json({ message: 'Campaign not found' });
    }

    if (campaign.status !== 'active') {
      return res.status(400).json({ message: 'Campaign is not active' });
    }

    // Create donation record
    const donation = new Donation({
      donorId: req.user._id,
      campaignId,
      amount: parseFloat(amount),
      donorMessage,
      isAnonymous: isAnonymous || false,
      paymentStatus: 'pending'
    });

    await donation.save();

    // Get NGO user details for payment configuration
    const ngoUser = await User.findById(campaign.ngoId);
    
    // Generate UPI QR code data using payment service with NGO details
    const upiData = paymentService.getUPIData(campaign, donation, amount, ngoUser);
    const qrDataString = paymentService.generateUPIURL(upiData);
    
    // Generate QR code using payment service configuration
    const qrCodeConfig = paymentService.getQRCodeConfig();
    const qrCodeDataURL = await QRCode.toDataURL(qrDataString, qrCodeConfig);

    donation.qrCodeData = qrCodeDataURL;
    await donation.save();

    res.json({
      message: 'Donation created successfully. Please scan QR code to complete payment.',
      donation: {
        id: donation._id,
        amount: donation.amount,
        qrCode: qrCodeDataURL,
        upiData: qrDataString,
        status: donation.paymentStatus
      }
    });
  } catch (error) {
    console.error('Error creating donation:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Confirm payment (simulate UPI payment)
router.post('/:id/confirm-payment', auth, requireDonor, async (req, res) => {
  try {
    console.log('Confirming payment for donation ID:', req.params.id);
    console.log('User ID:', req.user._id);
    
    // Validate ObjectId format
    if (!mongoose.Types.ObjectId.isValid(req.params.id)) {
      console.log('Invalid ObjectId format:', req.params.id);
      return res.status(400).json({ message: 'Invalid donation ID format' });
    }
    
    const donation = await Donation.findById(req.params.id);
    
    if (!donation) {
      return res.status(404).json({ message: 'Donation not found' });
    }

    console.log('Donation donor ID:', donation.donorId.toString());
    console.log('Request user ID:', req.user._id.toString());
    console.log('Payment status:', donation.paymentStatus);
    
    if (donation.donorId.toString() !== req.user._id.toString()) {
      console.log('Authorization failed: User not authorized to confirm this payment');
      return res.status(403).json({ message: 'Not authorized to confirm this payment' });
    }

    if (donation.paymentStatus !== 'pending') {
      console.log('Payment already processed with status:', donation.paymentStatus);
      return res.status(400).json({ message: 'Payment already processed' });
    }

    // Update payment status
    donation.paymentStatus = 'completed';
    donation.upiTransactionId = `UPI${Date.now()}${Math.random().toString(36).substr(2, 9)}`;
    await donation.save();

    // Update campaign raised amount
    const campaign = await Campaign.findById(donation.campaignId);
    campaign.raisedAmount += donation.amount;
    await campaign.save();

    // Update donor's total donations
    const donor = await User.findById(donation.donorId);
    donor.totalDonations += donation.amount;
    await donor.save();

    // Log to blockchain with timeout
    let blockchainTxHash = '';
    try {
      const blockchainPromise = blockchainService.logDonation(
        donation._id.toString(),
        donor.walletAddress || '0x0000000000000000000000000000000000000000',
        donation.campaignId.toString(),
        donation.amount
      );
      
      // Add timeout to blockchain call
      const timeoutPromise = new Promise((_, reject) => 
        setTimeout(() => reject(new Error('Blockchain timeout')), 5000)
      );
      
      blockchainTxHash = await Promise.race([blockchainPromise, timeoutPromise]);
      donation.blockchainTxHash = blockchainTxHash;
      await donation.save();
    } catch (error) {
      console.error('Error logging donation to blockchain:', error);
      // Continue without blockchain logging
    }

    // Mint Impact NFT with timeout
    let nftId = '';
    let nftMetadataUri = '';
    try {
      const nftMetadata = {
        name: `Impact NFT - ${campaign.title}`,
        description: `A token representing your donation of ₹${donation.amount} to ${campaign.title}`,
        image: campaign.coverImage || 'https://via.placeholder.com/300x300?text=Impact+NFT',
        amount: donation.amount,
        campaignTitle: campaign.title,
        timestamp: donation.createdAt,
        externalUrl: `${process.env.FRONTEND_URL || 'http://localhost:3000'}/campaigns/${campaign._id}`
      };

      // Upload metadata with timeout and fallback
      try {
        const metadataPromise = ipfsService.uploadNFTMetadata(nftMetadata);
        const metadataTimeoutPromise = new Promise((_, reject) => 
          setTimeout(() => reject(new Error('IPFS timeout')), 5000)
        );
        
        nftMetadataUri = await Promise.race([metadataPromise, metadataTimeoutPromise]);
      } catch (error) {
        console.error('IPFS upload failed, using fallback:', error);
        // Use a fallback metadata URI if IPFS fails
        nftMetadataUri = `https://via.placeholder.com/300x300?text=Impact+NFT+${donation._id}`;
      }

      const impactData = {
        donationId: donation._id.toString(),
        campaignId: donation.campaignId.toString(),
        amount: donation.amount.toString(),
        donorName: donation.isAnonymous ? 'Anonymous' : donor.name,
        campaignTitle: campaign.title,
        timestamp: Math.floor(donation.createdAt.getTime() / 1000),
        impactMessage: donation.donorMessage || `Thank you for your generous donation!`
      };

      // Mint NFT with timeout
      const mintPromise = blockchainService.mintImpactNFT(
        donor.walletAddress || '0x0000000000000000000000000000000000000000',
        nftMetadataUri,
        impactData
      );
      const mintTimeoutPromise = new Promise((_, reject) => 
        setTimeout(() => reject(new Error('NFT minting timeout')), 5000)
      );

      const nftResult = await Promise.race([mintPromise, mintTimeoutPromise]);

      nftId = nftResult.tokenId;
      donation.nftId = nftId;
      donation.nftMetadataUri = nftMetadataUri;
      await donation.save();
    } catch (error) {
      console.error('Error minting Impact NFT:', error);
      // Continue without NFT minting
    }

    res.json({
      message: 'Payment confirmed successfully!',
      donation: {
        id: donation._id,
        amount: donation.amount,
        status: donation.paymentStatus,
        transactionId: donation.upiTransactionId,
        blockchainTxHash,
        nftId,
        nftMetadataUri,
        receiptNumber: donation.receiptNumber
      }
    });
  } catch (error) {
    console.error('Error confirming payment:', error);
    console.error('Error details:', {
      message: error.message,
      stack: error.stack,
      donationId: req.params.id,
      userId: req.user?._id
    });
    res.status(500).json({ message: 'Server error' });
  }
});

// Get donor's donations
router.get('/my-donations', auth, requireDonor, async (req, res) => {
  try {
    const { page = 1, limit = 10, status } = req.query;
    const query = { donorId: req.user._id };
    
    if (status) query.paymentStatus = status;

    const donations = await Donation.find(query)
      .populate('campaignId', 'title coverImage ngoId')
      .populate('campaignId.ngoId', 'name organizationName')
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await Donation.countDocuments(query);

    res.json({
      donations,
      totalPages: Math.ceil(total / limit),
      currentPage: page,
      total
    });
  } catch (error) {
    console.error('Error fetching donations:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get donation by ID
router.get('/:id', auth, async (req, res) => {
  try {
    const donation = await Donation.findById(req.params.id)
      .populate('donorId', 'name email')
      .populate('campaignId', 'title ngoId')
      .populate('campaignId.ngoId', 'name organizationName');

    if (!donation) {
      return res.status(404).json({ message: 'Donation not found' });
    }

    // Check if user is authorized to view this donation
    if (donation.donorId._id.toString() !== req.user._id.toString() && 
        donation.campaignId.ngoId._id.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Not authorized to view this donation' });
    }

    res.json(donation);
  } catch (error) {
    console.error('Error fetching donation:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get campaign donations (NGO only)
router.get('/campaign/:campaignId', auth, async (req, res) => {
  try {
    const { page = 1, limit = 10 } = req.query;
    
    // Verify campaign belongs to NGO
    const campaign = await Campaign.findById(req.params.campaignId);
    if (!campaign) {
      return res.status(404).json({ message: 'Campaign not found' });
    }

    if (campaign.ngoId.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Not authorized to view these donations' });
    }

    const donations = await Donation.find({ campaignId: req.params.campaignId })
      .populate('donorId', 'name email')
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await Donation.countDocuments({ campaignId: req.params.campaignId });

    res.json({
      donations,
      totalPages: Math.ceil(total / limit),
      currentPage: page,
      total
    });
  } catch (error) {
    console.error('Error fetching campaign donations:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Generate donation receipt
router.get('/:id/receipt', auth, async (req, res) => {
  try {
    const donation = await Donation.findById(req.params.id)
      .populate('donorId', 'name email address')
      .populate('campaignId', 'title ngoId')
      .populate('campaignId.ngoId', 'name organizationName address');

    if (!donation) {
      return res.status(404).json({ message: 'Donation not found' });
    }

    if (donation.donorId._id.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Not authorized to view this receipt' });
    }

    if (donation.paymentStatus !== 'completed') {
      return res.status(400).json({ message: 'Payment not completed' });
    }

    const receipt = {
      receiptNumber: donation.receiptNumber,
      donationId: donation._id,
      donor: {
        name: donation.isAnonymous ? 'Anonymous' : donation.donorId.name,
        email: donation.isAnonymous ? 'N/A' : donation.donorId.email
      },
      campaign: {
        title: donation.campaignId.title,
        ngo: donation.campaignId.ngoId.name
      },
      amount: donation.amount,
      currency: donation.currency,
      donationDate: donation.createdAt,
      paymentDate: donation.updatedAt,
      transactionId: donation.upiTransactionId,
      blockchainTxHash: donation.blockchainTxHash,
      nftId: donation.nftId,
      taxDeductible: donation.taxDeductible
    };

    res.json(receipt);
  } catch (error) {
    console.error('Error generating receipt:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
