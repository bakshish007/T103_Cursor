const express = require('express');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const { auth } = require('../middleware/auth');

const router = express.Router();

// Generate JWT token
const generateToken = (userId) => {
  return jwt.sign({ userId }, process.env.JWT_SECRET, { expiresIn: '7d' });
};

// Register
router.post('/register', async (req, res) => {
  try {
    const { name, email, password, role, organizationName, organizationType, registrationNumber, phone, address } = req.body;

    // Check if user already exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: 'User already exists with this email' });
    }

    // Create new user
    const user = new User({
      name,
      email,
      password,
      role,
      organizationName,
      organizationType,
      registrationNumber,
      phone,
      address
    });

    await user.save();

    // Generate token
    const token = generateToken(user._id);

    res.status(201).json({
      message: 'User registered successfully',
      token,
      user: user.toJSON()
    });
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ message: 'Server error during registration' });
  }
});

// Login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    // Find user by email
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }

    // Check password
    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }

    // Generate token
    const token = generateToken(user._id);

    res.json({
      message: 'Login successful',
      token,
      user: user.toJSON()
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ message: 'Server error during login' });
  }
});

// Get current user
router.get('/me', auth, async (req, res) => {
  try {
    res.json({ user: req.user });
  } catch (error) {
    console.error('Get user error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Update profile
router.put('/profile', auth, async (req, res) => {
  try {
    const updates = req.body || {};

    // Whitelist top-level fields and nested NGO payment fields
    const allowedTopLevel = ['name', 'phone', 'address', 'organizationName', 'organizationType', 'profileImage'];
    const allowedBankFields = ['accountNumber', 'ifscCode', 'bankName', 'branch', 'accountHolderName', 'isVerified'];
    const allowedUPIFields = ['vpa', 'merchantName', 'isVerified'];

    // Build $set object using dot-notation for nested fields
    const setUpdates = {};

    // Top-level fields
    for (const key of allowedTopLevel) {
      if (Object.prototype.hasOwnProperty.call(updates, key)) {
        setUpdates[key] = updates[key];
      }
    }

    // Nested bankAccount
    if (updates.bankAccount && typeof updates.bankAccount === 'object') {
      for (const k of allowedBankFields) {
        if (Object.prototype.hasOwnProperty.call(updates.bankAccount, k)) {
          setUpdates[`bankAccount.${k}`] = updates.bankAccount[k];
        }
      }
    }

    // Nested upiDetails
    if (updates.upiDetails && typeof updates.upiDetails === 'object') {
      for (const k of allowedUPIFields) {
        if (Object.prototype.hasOwnProperty.call(updates.upiDetails, k)) {
          setUpdates[`upiDetails.${k}`] = updates.upiDetails[k];
        }
      }
    }

    const user = await User.findByIdAndUpdate(
      req.user._id,
      { $set: setUpdates },
      { new: true, runValidators: true }
    );

    res.json({
      message: 'Profile updated successfully',
      user: user.toJSON()
    });
  } catch (error) {
    console.error('Profile update error:', error);
    res.status(500).json({ message: 'Server error during profile update' });
  }
});

// Change password
router.put('/change-password', auth, async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;

    const user = await User.findById(req.user._id);
    const isMatch = await user.comparePassword(currentPassword);
    
    if (!isMatch) {
      return res.status(400).json({ message: 'Current password is incorrect' });
    }

    user.password = newPassword;
    await user.save();

    res.json({ message: 'Password changed successfully' });
  } catch (error) {
    console.error('Password change error:', error);
    res.status(500).json({ message: 'Server error during password change' });
  }
});

module.exports = router;
