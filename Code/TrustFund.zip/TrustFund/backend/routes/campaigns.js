const express = require('express');
const multer = require('multer');
const path = require('path');
const Campaign = require('../models/Campaign');
const { auth, requireNGO } = require('../middleware/auth');
const blockchainService = require('../services/blockchain');
const ipfsService = require('../services/ipfs');

const router = express.Router();

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({ 
  storage: storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
  fileFilter: (req, file, cb) => {
    const allowedTypes = /jpeg|jpg|png|gif|webp|mp4|mov|avi|pdf/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);
    
    if (mimetype && extname) {
      return cb(null, true);
    } else {
      cb(new Error('Only images, videos, and PDFs are allowed'));
    }
  }
});

// Get all campaigns (public)
router.get('/', async (req, res) => {
  try {
    const { page = 1, limit = 10, category, status = 'active', search } = req.query;
    const query = { status };

    if (category) query.category = category;
    if (search) {
      query.$or = [
        { title: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } }
      ];
    }

    const campaigns = await Campaign.find(query)
      .populate('ngoId', 'name organizationName profileImage')
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await Campaign.countDocuments(query);

    res.json({
      campaigns,
      totalPages: Math.ceil(total / limit),
      currentPage: page,
      total
    });
  } catch (error) {
    console.error('Error fetching campaigns:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get campaign by ID (public)
router.get('/:id', async (req, res) => {
  try {
    const campaign = await Campaign.findById(req.params.id)
      .populate('ngoId', 'name organizationName organizationType profileImage totalCampaigns')
      .populate('milestones');

    if (!campaign) {
      return res.status(404).json({ message: 'Campaign not found' });
    }

    // Calculate transparency score
    campaign.calculateTransparencyScore();
    await campaign.save();

    res.json(campaign);
  } catch (error) {
    console.error('Error fetching campaign:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Create campaign (NGO only)
router.post('/', auth, requireNGO, upload.array('images', 5), async (req, res) => {
  try {
    const {
      title,
      description,
      category,
      targetAmount,
      endDate,
      milestones,
      tags,
      location
    } = req.body;

    // Upload images to IPFS
    const imageHashes = [];
    if (req.files && req.files.length > 0) {
      for (const file of req.files) {
        try {
          const ipfsUrl = await ipfsService.uploadFile(file.path, file.originalname);
          imageHashes.push(ipfsUrl);
        } catch (error) {
          console.error('Error uploading image to IPFS:', error);
          // Fallback to local storage
          const localUrl = await ipfsService.storeLocally(file.path, file.originalname);
          imageHashes.push(localUrl);
        }
      }
    }

    // Parse milestones
    const parsedMilestones = milestones ? JSON.parse(milestones) : [];

    const campaign = new Campaign({
      ngoId: req.user._id,
      title,
      description,
      category,
      targetAmount: parseFloat(targetAmount),
      endDate: new Date(endDate),
      milestones: parsedMilestones,
      images: imageHashes,
      coverImage: imageHashes[0] || '',
      tags: tags ? tags.split(',').map(tag => tag.trim()) : [],
      location: location ? JSON.parse(location) : {}
    });

    await campaign.save();

    // Log to blockchain
    try {
      const txHash = await blockchainService.logCampaign(
        campaign._id.toString(),
        req.user.walletAddress || '0x0000000000000000000000000000000000000000',
        campaign.targetAmount
      );
      campaign.blockchainTxHash = txHash;
      await campaign.save();
    } catch (error) {
      console.error('Error logging campaign to blockchain:', error);
    }

    res.status(201).json({
      message: 'Campaign created successfully',
      campaign
    });
  } catch (error) {
    console.error('Error creating campaign:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Update campaign (NGO only)
router.put('/:id', auth, requireNGO, async (req, res) => {
  try {
    const campaign = await Campaign.findById(req.params.id);
    
    if (!campaign) {
      return res.status(404).json({ message: 'Campaign not found' });
    }

    if (campaign.ngoId.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Not authorized to update this campaign' });
    }

    const updates = req.body;
    const allowedUpdates = ['title', 'description', 'category', 'targetAmount', 'endDate', 'tags', 'location'];
    
    allowedUpdates.forEach(update => {
      if (updates[update] !== undefined) {
        if (update === 'endDate') {
          campaign[update] = new Date(updates[update]);
        } else if (update === 'tags') {
          campaign[update] = updates[update].split(',').map(tag => tag.trim());
        } else if (update === 'location') {
          campaign[update] = JSON.parse(updates[update]);
        } else {
          campaign[update] = updates[update];
        }
      }
    });

    await campaign.save();

    res.json({
      message: 'Campaign updated successfully',
      campaign
    });
  } catch (error) {
    console.error('Error updating campaign:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get NGO's campaigns
router.get('/ngo/my-campaigns', auth, requireNGO, async (req, res) => {
  try {
    const { page = 1, limit = 10, status } = req.query;
    const query = { ngoId: req.user._id };
    
    if (status) query.status = status;

    const campaigns = await Campaign.find(query)
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await Campaign.countDocuments(query);

    res.json({
      campaigns,
      totalPages: Math.ceil(total / limit),
      currentPage: page,
      total
    });
  } catch (error) {
    console.error('Error fetching NGO campaigns:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Update campaign status
router.patch('/:id/status', auth, requireNGO, async (req, res) => {
  try {
    const { status } = req.body;
    const campaign = await Campaign.findById(req.params.id);
    
    if (!campaign) {
      return res.status(404).json({ message: 'Campaign not found' });
    }

    if (campaign.ngoId.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Not authorized to update this campaign' });
    }

    campaign.status = status;
    await campaign.save();

    res.json({
      message: 'Campaign status updated successfully',
      campaign
    });
  } catch (error) {
    console.error('Error updating campaign status:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get campaign statistics
router.get('/:id/stats', async (req, res) => {
  try {
    const campaign = await Campaign.findById(req.params.id);
    
    if (!campaign) {
      return res.status(404).json({ message: 'Campaign not found' });
    }

    const stats = {
      totalRaised: campaign.raisedAmount,
      targetAmount: campaign.targetAmount,
      progressPercentage: Math.round((campaign.raisedAmount / campaign.targetAmount) * 100),
      totalDonations: campaign.donations?.length || 0,
      milestonesCompleted: campaign.milestones.filter(m => m.isCompleted).length,
      totalMilestones: campaign.milestones.length,
      transparencyScore: campaign.transparencyScore,
      daysRemaining: campaign.daysRemaining
    };

    res.json(stats);
  } catch (error) {
    console.error('Error fetching campaign stats:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
