const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { auth } = require('../middleware/auth');
const ipfsService = require('../services/ipfs');

const router = express.Router();

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = 'uploads/';
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({ 
  storage: storage,
  limits: { 
    fileSize: 50 * 1024 * 1024 // 50MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = /jpeg|jpg|png|gif|webp|mp4|mov|avi|pdf|doc|docx|txt/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);
    
    if (mimetype && extname) {
      return cb(null, true);
    } else {
      cb(new Error('File type not allowed'));
    }
  }
});

// Upload single file
router.post('/single', auth, upload.single('file'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ message: 'No file uploaded' });
    }

    let fileUrl = '';
    
    // Try to upload to IPFS first
    try {
      fileUrl = await ipfsService.uploadFile(req.file.path, req.file.originalname);
    } catch (error) {
      console.error('Error uploading to IPFS:', error);
      // Fallback to local storage
      fileUrl = await ipfsService.storeLocally(req.file.path, req.file.originalname);
    }

    // Clean up temporary file
    fs.unlinkSync(req.file.path);

    res.json({
      message: 'File uploaded successfully',
      file: {
        originalName: req.file.originalname,
        size: req.file.size,
        url: fileUrl,
        type: req.file.mimetype
      }
    });
  } catch (error) {
    console.error('Error uploading file:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Upload multiple files
router.post('/multiple', auth, upload.array('files', 10), async (req, res) => {
  try {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({ message: 'No files uploaded' });
    }

    const uploadedFiles = [];

    for (const file of req.files) {
      let fileUrl = '';
      
      try {
        fileUrl = await ipfsService.uploadFile(file.path, file.originalname);
      } catch (error) {
        console.error('Error uploading to IPFS:', error);
        fileUrl = await ipfsService.storeLocally(file.path, file.originalname);
      }

      uploadedFiles.push({
        originalName: file.originalname,
        size: file.size,
        url: fileUrl,
        type: file.mimetype
      });

      // Clean up temporary file
      fs.unlinkSync(file.path);
    }

    res.json({
      message: 'Files uploaded successfully',
      files: uploadedFiles
    });
  } catch (error) {
    console.error('Error uploading files:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Upload profile image
router.post('/profile', auth, upload.single('profileImage'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ message: 'No image uploaded' });
    }

    // Validate image type
    const allowedImageTypes = /jpeg|jpg|png|gif|webp/;
    const extname = allowedImageTypes.test(path.extname(req.file.originalname).toLowerCase());
    const mimetype = allowedImageTypes.test(req.file.mimetype);
    
    if (!mimetype || !extname) {
      fs.unlinkSync(req.file.path);
      return res.status(400).json({ message: 'Only images are allowed for profile pictures' });
    }

    let imageUrl = '';
    
    try {
      imageUrl = await ipfsService.uploadFile(req.file.path, req.file.originalname);
    } catch (error) {
      console.error('Error uploading to IPFS:', error);
      imageUrl = await ipfsService.storeLocally(req.file.path, req.file.originalname);
    }

    // Clean up temporary file
    fs.unlinkSync(req.file.path);

    res.json({
      message: 'Profile image uploaded successfully',
      imageUrl
    });
  } catch (error) {
    console.error('Error uploading profile image:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get file info
router.get('/info/:filename', (req, res) => {
  try {
    const filename = req.params.filename;
    const filePath = path.join(__dirname, '../uploads', filename);
    
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ message: 'File not found' });
    }

    const stats = fs.statSync(filePath);
    res.json({
      filename,
      size: stats.size,
      created: stats.birthtime,
      modified: stats.mtime
    });
  } catch (error) {
    console.error('Error getting file info:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Delete file
router.delete('/:filename', auth, (req, res) => {
  try {
    const filename = req.params.filename;
    const filePath = path.join(__dirname, '../uploads', filename);
    
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ message: 'File not found' });
    }

    fs.unlinkSync(filePath);
    res.json({ message: 'File deleted successfully' });
  } catch (error) {
    console.error('Error deleting file:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
