const express = require('express');
const blockchainService = require('../services/blockchain');
const { auth } = require('../middleware/auth');

const router = express.Router();

// Get transaction status
router.get('/transaction/:txHash', async (req, res) => {
  try {
    const { txHash } = req.params;
    const status = await blockchainService.getTransactionStatus(txHash);
    res.json(status);
  } catch (error) {
    console.error('Error getting transaction status:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get campaign data from blockchain
router.get('/campaign/:campaignId', async (req, res) => {
  try {
    const { campaignId } = req.params;
    const campaignData = await blockchainService.getCampaignData(campaignId);
    res.json(campaignData);
  } catch (error) {
    console.error('Error getting campaign data:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get donation data from blockchain
router.get('/donation/:donationId', async (req, res) => {
  try {
    const { donationId } = req.params;
    const donationData = await blockchainService.getDonationData(donationId);
    res.json(donationData);
  } catch (error) {
    console.error('Error getting donation data:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get donor's NFTs
router.get('/nfts/:donorAddress', auth, async (req, res) => {
  try {
    const { donorAddress } = req.params;
    const nfts = await blockchainService.getDonorNFTs(donorAddress);
    res.json(nfts);
  } catch (error) {
    console.error('Error getting donor NFTs:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get blockchain statistics
router.get('/stats', async (req, res) => {
  try {
    const stats = {
      totalCampaigns: 0,
      totalDonations: 0,
      totalProofs: 0,
      totalNFTs: 0
    };

    // Try to get stats from contracts if available
    try {
      if (blockchainService.campaignContract) {
        stats.totalCampaigns = await blockchainService.campaignContract.getCampaignCount();
        stats.totalDonations = await blockchainService.campaignContract.getDonationCount();
        stats.totalProofs = await blockchainService.campaignContract.getProofCount();
      }
      
      if (blockchainService.impactNFT) {
        stats.totalNFTs = await blockchainService.impactNFT.totalSupply();
      }
    } catch (error) {
      console.error('Error getting blockchain stats:', error);
    }

    res.json(stats);
  } catch (error) {
    console.error('Error getting blockchain stats:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Verify blockchain data
router.post('/verify', async (req, res) => {
  try {
    const { type, id, expectedData } = req.body;
    let verification = { verified: false, data: null };

    switch (type) {
      case 'campaign':
        verification.data = await blockchainService.getCampaignData(id);
        break;
      case 'donation':
        verification.data = await blockchainService.getDonationData(id);
        break;
      default:
        return res.status(400).json({ message: 'Invalid verification type' });
    }

    // Basic verification logic
    if (verification.data && expectedData) {
      verification.verified = JSON.stringify(verification.data) === JSON.stringify(expectedData);
    }

    res.json(verification);
  } catch (error) {
    console.error('Error verifying blockchain data:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
