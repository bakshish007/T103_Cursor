const mongoose = require('mongoose');

const donationSchema = new mongoose.Schema({
  donorId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  campaignId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Campaign',
    required: true
  },
  amount: {
    type: Number,
    required: true,
    min: 1
  },
  currency: {
    type: String,
    default: 'INR'
  },
  paymentMethod: {
    type: String,
    enum: ['upi', 'card', 'netbanking', 'wallet'],
    default: 'upi'
  },
  paymentStatus: {
    type: String,
    enum: ['pending', 'completed', 'failed', 'refunded'],
    default: 'pending'
  },
  upiTransactionId: {
    type: String,
    default: ''
  },
  qrCodeData: {
    type: String,
    default: ''
  },
  blockchainTxHash: {
    type: String,
    default: ''
  },
  nftId: {
    type: String,
    default: ''
  },
  nftMetadataUri: {
    type: String,
    default: ''
  },
  impactMessage: {
    type: String,
    default: ''
  },
  isAnonymous: {
    type: Boolean,
    default: false
  },
  donorMessage: {
    type: String,
    default: ''
  },
  receiptNumber: {
    type: String,
    unique: true,
    sparse: true
  },
  taxDeductible: {
    type: Boolean,
    default: true
  },
  receiptGenerated: {
    type: Boolean,
    default: false
  },
  receiptGeneratedAt: {
    type: Date
  }
}, {
  timestamps: true
});

// Generate receipt number before saving
donationSchema.pre('save', async function(next) {
  if (this.isNew && this.paymentStatus === 'completed') {
    const count = await this.constructor.countDocuments();
    this.receiptNumber = `DON-${Date.now()}-${String(count + 1).padStart(4, '0')}`;
  }
  next();
});

// Virtual for donation impact
donationSchema.virtual('impactDescription').get(function() {
  if (this.amount >= 10000) return 'High Impact Donation';
  if (this.amount >= 5000) return 'Medium Impact Donation';
  if (this.amount >= 1000) return 'Standard Donation';
  return 'Small Donation';
});

// Index for better query performance
donationSchema.index({ donorId: 1, createdAt: -1 });
donationSchema.index({ campaignId: 1, createdAt: -1 });
donationSchema.index({ paymentStatus: 1 });
donationSchema.index({ blockchainTxHash: 1 });

module.exports = mongoose.model('Donation', donationSchema);
