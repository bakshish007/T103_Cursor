const mongoose = require('mongoose');

const milestoneSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true
  },
  description: {
    type: String,
    required: true
  },
  targetAmount: {
    type: Number,
    required: true
  },
  completedAmount: {
    type: Number,
    default: 0
  },
  isCompleted: {
    type: Boolean,
    default: false
  },
  completionDate: {
    type: Date
  },
  proofHash: {
    type: String,
    default: ''
  },
  proofFiles: [{
    type: String // IPFS hashes
  }],
  geoLocation: {
    latitude: Number,
    longitude: Number,
    address: String
  },
  blockchainTxHash: {
    type: String,
    default: ''
  }
}, {
  timestamps: true
});

const campaignSchema = new mongoose.Schema({
  ngoId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  title: {
    type: String,
    required: true,
    trim: true
  },
  description: {
    type: String,
    required: true
  },
  category: {
    type: String,
    required: true,
    enum: ['education', 'healthcare', 'environment', 'poverty', 'disaster-relief', 'women-empowerment', 'child-welfare', 'other']
  },
  targetAmount: {
    type: Number,
    required: true,
    min: 1000
  },
  raisedAmount: {
    type: Number,
    default: 0
  },
  currency: {
    type: String,
    default: 'INR'
  },
  startDate: {
    type: Date,
    default: Date.now
  },
  endDate: {
    type: Date,
    required: true
  },
  status: {
    type: String,
    enum: ['active', 'completed', 'cancelled', 'paused'],
    default: 'active'
  },
  milestones: [milestoneSchema],
  images: [{
    type: String // IPFS hashes
  }],
  coverImage: {
    type: String,
    default: ''
  },
  tags: [{
    type: String
  }],
  location: {
    city: String,
    state: String,
    country: { type: String, default: 'India' }
  },
  transparencyScore: {
    type: Number,
    default: 0,
    min: 0,
    max: 100
  },
  blockchainTxHash: {
    type: String,
    default: ''
  },
  isVerified: {
    type: Boolean,
    default: false
  },
  verificationNotes: {
    type: String,
    default: ''
  }
}, {
  timestamps: true
});

// Calculate transparency score
campaignSchema.methods.calculateTransparencyScore = function() {
  let score = 0;
  const totalMilestones = this.milestones.length;
  
  if (totalMilestones === 0) return 0;
  
  // Base score for having milestones
  score += 20;
  
  // Score for completed milestones with proofs
  const completedWithProofs = this.milestones.filter(m => 
    m.isCompleted && m.proofHash && m.proofFiles.length > 0
  ).length;
  
  score += (completedWithProofs / totalMilestones) * 60;
  
  // Score for having images
  if (this.images.length > 0) score += 10;
  
  // Score for having cover image
  if (this.coverImage) score += 10;
  
  this.transparencyScore = Math.round(score);
  return this.transparencyScore;
};

// Virtual for progress percentage
campaignSchema.virtual('progressPercentage').get(function() {
  return Math.round((this.raisedAmount / this.targetAmount) * 100);
});

// Virtual for days remaining
campaignSchema.virtual('daysRemaining').get(function() {
  const now = new Date();
  const end = new Date(this.endDate);
  const diffTime = end - now;
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  return diffDays > 0 ? diffDays : 0;
});

// Index for better query performance
campaignSchema.index({ ngoId: 1, status: 1 });
campaignSchema.index({ category: 1, status: 1 });
campaignSchema.index({ createdAt: -1 });

module.exports = mongoose.model('Campaign', campaignSchema);
