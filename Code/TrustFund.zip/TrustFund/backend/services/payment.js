/**
 * Payment Configuration Service
 * Manages UPI, bank account, and payment gateway settings
 */

class PaymentService {
  constructor() {
    this.config = {
      // UPI Configuration
      upi: {
        vpa: process.env.UPI_VPA || 'donation@paytm',
        merchantName: process.env.MERCHANT_NAME || 'Transparent Donation System',
        merchantCode: process.env.MERCHANT_CODE || 'DONATION',
        currency: 'INR'
      },
      
      // Bank Account Configuration
      bank: {
        accountNumber: process.env.BANK_ACCOUNT_NUMBER || '1234567890',
        ifscCode: process.env.BANK_IFSC_CODE || 'SBIN0001234',
        bankName: process.env.BANK_NAME || 'State Bank of India',
        branch: process.env.BANK_BRANCH || 'Mumbai Main Branch',
        accountHolderName: process.env.ACCOUNT_HOLDER_NAME || 'Transparent Donation System'
      },
      
      // Payment Gateway Configuration (for future integration)
      gateway: {
        razorpayKeyId: process.env.RAZORPAY_KEY_ID || '',
        razorpayKeySecret: process.env.RAZORPAY_KEY_SECRET || '',
        payuMerchantKey: process.env.PAYU_MERCHANT_KEY || '',
        payuMerchantSalt: process.env.PAYU_MERCHANT_SALT || ''
      },
      
      // QR Code Configuration
      qrCode: {
        width: 300,
        margin: 2,
        color: {
          dark: '#000000',
          light: '#FFFFFF'
        }
      }
    };
  }

  /**
   * Get UPI payment data for QR code generation
   */
  getUPIData(campaign, donation, amount, ngoUser = null) {
    // Use NGO-specific UPI details if available, otherwise fall back to default
    const vpa = ngoUser?.upiDetails?.vpa || this.config.upi.vpa;
    const merchantName = ngoUser?.upiDetails?.merchantName || ngoUser?.organizationName || this.config.upi.merchantName;
    
    return {
      vpa: vpa,
      merchantName: merchantName,
      merchantCode: this.config.upi.merchantCode,
      amount: amount,
      transactionId: donation._id.toString(),
      transactionNote: `Donation for ${campaign.title}`,
      currency: this.config.upi.currency
    };
  }

  /**
   * Generate UPI payment URL
   */
  generateUPIURL(upiData) {
    const params = new URLSearchParams({
      pa: upiData.vpa,
      pn: upiData.merchantName,
      am: upiData.amount.toString(),
      cu: upiData.currency,
      tn: upiData.transactionNote,
      tr: upiData.transactionId
    });
    
    return `upi://pay?${params.toString()}`;
  }

  /**
   * Get bank account details for manual transfers
   */
  getBankDetails(ngoUser = null) {
    // Use NGO-specific bank details if available, otherwise fall back to default
    if (ngoUser?.bankAccount?.accountNumber) {
      return {
        accountNumber: ngoUser.bankAccount.accountNumber,
        ifscCode: ngoUser.bankAccount.ifscCode,
        bankName: ngoUser.bankAccount.bankName,
        branch: ngoUser.bankAccount.branch,
        accountHolderName: ngoUser.bankAccount.accountHolderName
      };
    }
    
    return {
      accountNumber: this.config.bank.accountNumber,
      ifscCode: this.config.bank.ifscCode,
      bankName: this.config.bank.bankName,
      branch: this.config.bank.branch,
      accountHolderName: this.config.bank.accountHolderName
    };
  }

  /**
   * Get payment configuration for frontend
   */
  getPaymentConfig(ngoUser = null) {
    return {
      upi: {
        vpa: ngoUser?.upiDetails?.vpa || this.config.upi.vpa,
        merchantName: ngoUser?.upiDetails?.merchantName || ngoUser?.organizationName || this.config.upi.merchantName
      },
      bank: this.getBankDetails(ngoUser),
      supportedMethods: ['upi', 'netbanking', 'card', 'wallet']
    };
  }

  /**
   * Update payment configuration (for admin panel)
   */
  updateConfig(newConfig) {
    if (newConfig.upi) {
      this.config.upi = { ...this.config.upi, ...newConfig.upi };
    }
    if (newConfig.bank) {
      this.config.bank = { ...this.config.bank, ...newConfig.bank };
    }
    if (newConfig.gateway) {
      this.config.gateway = { ...this.config.gateway, ...newConfig.gateway };
    }
  }

  /**
   * Validate UPI VPA format
   */
  validateUPIVPA(vpa) {
    const upiRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+$/;
    return upiRegex.test(vpa);
  }

  /**
   * Validate IFSC code format
   */
  validateIFSC(ifsc) {
    const ifscRegex = /^[A-Z]{4}0[A-Z0-9]{6}$/;
    return ifscRegex.test(ifsc);
  }

  /**
   * Get QR code configuration
   */
  getQRCodeConfig() {
    return this.config.qrCode;
  }
}

module.exports = new PaymentService();
