const { NFTStorage, File } = require('nft.storage');
const fs = require('fs');
const path = require('path');

class IPFSService {
  constructor() {
    this.client = null;
    this.initialize();
  }

  initialize() {
    try {
      if (process.env.NFT_STORAGE_API_KEY) {
        this.client = new NFTStorage({ token: process.env.NFT_STORAGE_API_KEY });
        console.log('IPFS service initialized successfully');
      } else {
        console.log('NFT Storage API key not found. IPFS functionality will be limited.');
      }
    } catch (error) {
      console.error('Error initializing IPFS service:', error);
    }
  }

  async uploadFile(filePath, fileName) {
    try {
      if (!this.client) {
        throw new Error('IPFS client not initialized');
      }

      const fileData = fs.readFileSync(filePath);
      const file = new File([fileData], fileName, { type: this.getMimeType(fileName) });
      
      const cid = await this.client.storeBlob(file);
      return `https://${cid}.ipfs.nftstorage.link`;
    } catch (error) {
      console.error('Error uploading file to IPFS:', error);
      throw error;
    }
  }

  async uploadBuffer(buffer, fileName, mimeType) {
    try {
      if (!this.client) {
        throw new Error('IPFS client not initialized');
      }

      const file = new File([buffer], fileName, { type: mimeType });
      const cid = await this.client.storeBlob(file);
      return `https://${cid}.ipfs.nftstorage.link`;
    } catch (error) {
      console.error('Error uploading buffer to IPFS:', error);
      throw error;
    }
  }

  async uploadMetadata(metadata) {
    try {
      if (!this.client) {
        throw new Error('IPFS client not initialized');
      }

      const metadataFile = new File([JSON.stringify(metadata, null, 2)], 'metadata.json', {
        type: 'application/json'
      });
      
      const cid = await this.client.storeBlob(metadataFile);
      return `https://${cid}.ipfs.nftstorage.link`;
    } catch (error) {
      console.error('Error uploading metadata to IPFS:', error);
      throw error;
    }
  }

  async uploadNFTMetadata(nftData) {
    try {
      const metadata = {
        name: nftData.name || "Impact NFT",
        description: nftData.description || "A token representing your charitable impact",
        image: nftData.image,
        attributes: [
          {
            trait_type: "Donation Amount",
            value: nftData.amount
          },
          {
            trait_type: "Campaign",
            value: nftData.campaignTitle
          },
          {
            trait_type: "Donation Date",
            value: new Date(nftData.timestamp).toISOString()
          },
          {
            trait_type: "Impact Level",
            value: this.getImpactLevel(nftData.amount)
          }
        ],
        external_url: nftData.externalUrl || "",
        background_color: "ffffff"
      };

      return await this.uploadMetadata(metadata);
    } catch (error) {
      console.error('Error uploading NFT metadata:', error);
      throw error;
    }
  }

  getImpactLevel(amount) {
    if (amount >= 10000) return "High Impact";
    if (amount >= 5000) return "Medium Impact";
    if (amount >= 1000) return "Standard Impact";
    return "Small Impact";
  }

  getMimeType(fileName) {
    const ext = path.extname(fileName).toLowerCase();
    const mimeTypes = {
      '.jpg': 'image/jpeg',
      '.jpeg': 'image/jpeg',
      '.png': 'image/png',
      '.gif': 'image/gif',
      '.webp': 'image/webp',
      '.mp4': 'video/mp4',
      '.mov': 'video/quicktime',
      '.avi': 'video/x-msvideo',
      '.pdf': 'application/pdf',
      '.doc': 'application/msword',
      '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      '.txt': 'text/plain',
      '.json': 'application/json'
    };
    return mimeTypes[ext] || 'application/octet-stream';
  }

  // Fallback method for when IPFS is not available
  async storeLocally(filePath, fileName) {
    try {
      const uploadsDir = path.join(__dirname, '../uploads');
      if (!fs.existsSync(uploadsDir)) {
        fs.mkdirSync(uploadsDir, { recursive: true });
      }

      const timestamp = Date.now();
      const newFileName = `${timestamp}-${fileName}`;
      const newFilePath = path.join(uploadsDir, newFileName);

      fs.copyFileSync(filePath, newFilePath);
      return `/uploads/${newFileName}`;
    } catch (error) {
      console.error('Error storing file locally:', error);
      throw error;
    }
  }

  // Generate a mock IPFS URL for development
  generateMockUrl(fileName) {
    const timestamp = Date.now();
    return `https://mock-ipfs.com/${timestamp}-${fileName}`;
  }
}

module.exports = new IPFSService();
