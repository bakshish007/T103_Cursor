const { ethers } = require('ethers');
const fs = require('fs');
const path = require('path');

class BlockchainService {
  constructor() {
    this.provider = null;
    this.campaignContract = null;
    this.impactNFT = null;
    this.wallet = null;
    this.initialize();
  }

  async initialize() {
    try {
      // Initialize provider
      this.provider = new ethers.JsonRpcProvider(process.env.POLYGON_RPC_URL);
      
      // Initialize wallet
      this.wallet = new ethers.Wallet(process.env.PRIVATE_KEY, this.provider);
      
      // Load contract addresses
      const contractAddressesPath = path.join(__dirname, '../contract-addresses.json');
      if (fs.existsSync(contractAddressesPath)) {
        const contractAddresses = JSON.parse(fs.readFileSync(contractAddressesPath, 'utf8'));
        
        // Initialize contracts
        const campaignABI = this.getCampaignABI();
        const nftABI = this.getNFTABI();
        
        this.campaignContract = new ethers.Contract(
          contractAddresses.campaignContract,
          campaignABI,
          this.wallet
        );
        
        this.impactNFT = new ethers.Contract(
          contractAddresses.impactNFT,
          nftABI,
          this.wallet
        );
        
        console.log('Blockchain service initialized successfully');
      } else {
        console.log('Contract addresses not found. Please deploy contracts first.');
      }
    } catch (error) {
      console.error('Error initializing blockchain service:', error);
    }
  }

  getCampaignABI() {
    return [
      "function logCampaign(string memory _campaignId, address _ngo, uint256 _targetAmount) external",
      "function logDonation(string memory _donationId, address _donor, string memory _campaignId, uint256 _amount) external",
      "function logProof(string memory _milestoneId, string memory _campaignId, string memory _proofHash, uint256 _latitude, uint256 _longitude) external",
      "function getCampaign(string memory _campaignId) external view returns (tuple(string campaignId, address ngo, uint256 targetAmount, uint256 raisedAmount, bool isActive, uint256 createdAt))",
      "function getDonation(string memory _donationId) external view returns (tuple(string donationId, address donor, string campaignId, uint256 amount, uint256 timestamp))",
      "function getProof(string memory _milestoneId) external view returns (tuple(string milestoneId, string campaignId, string proofHash, uint256 latitude, uint256 longitude, uint256 timestamp))",
      "event CampaignCreated(string indexed campaignId, address indexed ngo, uint256 targetAmount)",
      "event DonationMade(string indexed donationId, address indexed donor, string indexed campaignId, uint256 amount)",
      "event ProofUploaded(string indexed milestoneId, string indexed campaignId, string proofHash)"
    ];
  }

  getNFTABI() {
    return [
      "function mintImpactNFT(address to, string memory tokenURI, tuple(string donationId, string campaignId, uint256 amount, string donorName, string campaignTitle, uint256 timestamp, string impactMessage) data) external returns (uint256)",
      "function getDonorTokens(address donor) external view returns (uint256[] memory)",
      "function getTokenByDonation(string memory donationId) external view returns (uint256)",
      "function getImpactData(uint256 tokenId) external view returns (tuple(string donationId, string campaignId, uint256 amount, string donorName, string campaignTitle, uint256 timestamp, string impactMessage))",
      "function totalSupply() external view returns (uint256)",
      "function ownerOf(uint256 tokenId) external view returns (address)",
      "function tokenURI(uint256 tokenId) external view returns (string memory)",
      "event ImpactNFTMinted(uint256 indexed tokenId, address indexed donor, string donationId, string campaignId, uint256 amount)"
    ];
  }

  async logCampaign(campaignId, ngoAddress, targetAmount) {
    try {
      if (!this.campaignContract) {
        throw new Error('Campaign contract not initialized');
      }

      const tx = await this.campaignContract.logCampaign(
        campaignId,
        ngoAddress,
        ethers.parseEther(targetAmount.toString())
      );
      
      // Return transaction hash immediately without waiting for confirmation
      return tx.hash;
    } catch (error) {
      console.error('Error logging campaign to blockchain:', error);
      throw error;
    }
  }

  async logDonation(donationId, donorAddress, campaignId, amount) {
    try {
      if (!this.campaignContract) {
        throw new Error('Campaign contract not initialized');
      }

      const tx = await this.campaignContract.logDonation(
        donationId,
        donorAddress,
        campaignId,
        ethers.parseEther(amount.toString())
      );
      
      // Return transaction hash immediately without waiting for confirmation
      // This prevents timeout issues while still logging the transaction
      return tx.hash;
    } catch (error) {
      console.error('Error logging donation to blockchain:', error);
      throw error;
    }
  }

  async logProof(milestoneId, campaignId, proofHash, latitude, longitude) {
    try {
      if (!this.campaignContract) {
        throw new Error('Campaign contract not initialized');
      }

      const tx = await this.campaignContract.logProof(
        milestoneId,
        campaignId,
        proofHash,
        Math.floor(latitude * 1000000), // Convert to integer (6 decimal places)
        Math.floor(longitude * 1000000)
      );
      
      // Return transaction hash immediately without waiting for confirmation
      return tx.hash;
    } catch (error) {
      console.error('Error logging proof to blockchain:', error);
      throw error;
    }
  }

  async mintImpactNFT(donorAddress, tokenURI, impactData) {
    try {
      if (!this.impactNFT) {
        throw new Error('Impact NFT contract not initialized');
      }

      const tx = await this.impactNFT.mintImpactNFT(
        donorAddress,
        tokenURI,
        impactData
      );
      
      // Return transaction hash immediately without waiting for confirmation
      // This prevents timeout issues while still minting the NFT
      // The NFT will be minted asynchronously on the blockchain
      return { 
        txHash: tx.hash, 
        tokenId: 'pending' // Will be updated when transaction is confirmed
      };
    } catch (error) {
      console.error('Error minting Impact NFT:', error);
      throw error;
    }
  }

  async getCampaignData(campaignId) {
    try {
      if (!this.campaignContract) {
        throw new Error('Campaign contract not initialized');
      }

      return await this.campaignContract.getCampaign(campaignId);
    } catch (error) {
      console.error('Error getting campaign data:', error);
      throw error;
    }
  }

  async getDonationData(donationId) {
    try {
      if (!this.campaignContract) {
        throw new Error('Campaign contract not initialized');
      }

      return await this.campaignContract.getDonation(donationId);
    } catch (error) {
      console.error('Error getting donation data:', error);
      throw error;
    }
  }

  async getDonorNFTs(donorAddress) {
    try {
      if (!this.impactNFT) {
        throw new Error('Impact NFT contract not initialized');
      }

      const tokenIds = await this.impactNFT.getDonorTokens(donorAddress);
      const nfts = [];

      for (const tokenId of tokenIds) {
        const impactData = await this.impactNFT.getImpactData(tokenId);
        const tokenURI = await this.impactNFT.tokenURI(tokenId);
        
        nfts.push({
          tokenId: tokenId.toString(),
          impactData,
          tokenURI
        });
      }

      return nfts;
    } catch (error) {
      console.error('Error getting donor NFTs:', error);
      throw error;
    }
  }

  async getTransactionStatus(txHash) {
    try {
      const receipt = await this.provider.getTransactionReceipt(txHash);
      return {
        status: receipt ? (receipt.status === 1 ? 'success' : 'failed') : 'pending',
        blockNumber: receipt?.blockNumber,
        gasUsed: receipt?.gasUsed?.toString()
      };
    } catch (error) {
      console.error('Error getting transaction status:', error);
      return { status: 'error', error: error.message };
    }
  }
}

module.exports = new BlockchainService();
