const { ethers } = require("hardhat");

async function main() {
  console.log("🔑 Generating new wallet...");
  
  // Generate a new random wallet
  const wallet = ethers.Wallet.createRandom();
  
  console.log("\n📋 Wallet Details:");
  console.log("==================");
  console.log("Address:", wallet.address);
  console.log("Private Key:", wallet.privateKey);
  console.log("Mnemonic:", wallet.mnemonic.phrase);
  
  console.log("\n⚠️  IMPORTANT SECURITY NOTES:");
  console.log("=============================");
  console.log("1. NEVER share your private key with anyone");
  console.log("2. Store it securely (password manager recommended)");
  console.log("3. Add it to your .env file:");
  console.log(`   PRIVATE_KEY=${wallet.privateKey}`);
  console.log("4. Fund this wallet with MATIC for transactions");
  console.log("5. Test with small amounts first");
  
  console.log("\n💰 To fund this wallet:");
  console.log("=======================");
  console.log("1. Buy MATIC on exchanges (Binance, Coinbase, etc.)");
  console.log("2. Send MATIC to:", wallet.address);
  console.log("3. For testnet: Use Mumbai faucet");
  console.log("4. For mainnet: Transfer from exchange");
  
  console.log("\n🔗 View on Explorer:");
  console.log("====================");
  console.log("Mumbai Testnet: https://mumbai.polygonscan.com/address/" + wallet.address);
  console.log("Polygon Mainnet: https://polygonscan.com/address/" + wallet.address);
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error("❌ Error generating wallet:", error);
    process.exit(1);
  });
