const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
require('dotenv').config();

const User = require('../models/User');
const Campaign = require('../models/Campaign');
const Donation = require('../models/Donation');

// Enhanced sample data with more users
const sampleUsers = [
  // NGO Users
  {
    name: 'Demo NGO',
    email: 'ngo@demo.com',
    password: 'password123',
    role: 'ngo',
    organizationName: 'Help India Foundation',
    organizationType: 'trust',
    registrationNumber: 'TRUST123456',
    phone: '9876543210',
    address: {
      street: '123 Charity Street',
      city: 'Mumbai',
      state: 'Maharashtra',
      pincode: '400001',
      country: 'India'
    },
    bankAccount: {
      accountNumber: '1234567890',
      ifscCode: 'SBIN0001234',
      bankName: 'State Bank of India',
      branch: 'Mumbai Main Branch',
      accountHolderName: 'Help India Foundation',
      isVerified: true
    },
    upiDetails: {
      vpa: 'helpindia@paytm',
      merchantName: 'Help India Foundation',
      isVerified: true
    },
    isVerified: true
  },
  {
    name: 'Education First NGO',
    email: 'education@demo.com',
    password: 'password123',
    role: 'ngo',
    organizationName: 'Education First Foundation',
    organizationType: 'foundation',
    registrationNumber: 'FOUND123456',
    phone: '9876543212',
    address: {
      street: '456 Education Lane',
      city: 'Delhi',
      state: 'Delhi',
      pincode: '110001',
      country: 'India'
    },
    bankAccount: {
      accountNumber: '2345678901',
      ifscCode: 'HDFC0001234',
      bankName: 'HDFC Bank',
      branch: 'Delhi Main Branch',
      accountHolderName: 'Education First Foundation',
      isVerified: true
    },
    upiDetails: {
      vpa: 'educationfirst@paytm',
      merchantName: 'Education First Foundation',
      isVerified: true
    },
    isVerified: true
  },
  {
    name: 'Rural Development Trust',
    email: 'rural@demo.com',
    password: 'password123',
    role: 'ngo',
    organizationName: 'Rural Development Trust',
    organizationType: 'trust',
    registrationNumber: 'RURAL123456',
    phone: '9876543213',
    address: {
      street: '789 Rural Road',
      city: 'Bangalore',
      state: 'Karnataka',
      pincode: '560001',
      country: 'India'
    },
    bankAccount: {
      accountNumber: '3456789012',
      ifscCode: 'ICIC0001234',
      bankName: 'ICICI Bank',
      branch: 'Bangalore Main Branch',
      accountHolderName: 'Rural Development Trust',
      isVerified: true
    },
    upiDetails: {
      vpa: 'ruraldev@paytm',
      merchantName: 'Rural Development Trust',
      isVerified: true
    },
    isVerified: true
  },
  {
    name: 'Health Care Society',
    email: 'health@demo.com',
    password: 'password123',
    role: 'ngo',
    organizationName: 'Health Care Society',
    organizationType: 'society',
    registrationNumber: 'HEALTH123456',
    phone: '9876543214',
    address: {
      street: '321 Health Street',
      city: 'Chennai',
      state: 'Tamil Nadu',
      pincode: '600001',
      country: 'India'
    },
    bankAccount: {
      accountNumber: '4567890123',
      ifscCode: 'AXIS0001234',
      bankName: 'Axis Bank',
      branch: 'Chennai Main Branch',
      accountHolderName: 'Health Care Society',
      isVerified: true
    },
    upiDetails: {
      vpa: 'healthcare@paytm',
      merchantName: 'Health Care Society',
      isVerified: true
    },
    isVerified: true
  },
  {
    name: 'Women Empowerment Foundation',
    email: 'women@demo.com',
    password: 'password123',
    role: 'ngo',
    organizationName: 'Women Empowerment Foundation',
    organizationType: 'foundation',
    registrationNumber: 'WOMEN123456',
    phone: '9876543215',
    address: {
      street: '654 Empowerment Avenue',
      city: 'Kolkata',
      state: 'West Bengal',
      pincode: '700001',
      country: 'India'
    },
    bankAccount: {
      accountNumber: '5678901234',
      ifscCode: 'PNB0001234',
      bankName: 'Punjab National Bank',
      branch: 'Kolkata Main Branch',
      accountHolderName: 'Women Empowerment Foundation',
      isVerified: true
    },
    upiDetails: {
      vpa: 'womenempower@paytm',
      merchantName: 'Women Empowerment Foundation',
      isVerified: true
    },
    isVerified: true
  },
  // Donor Users
  {
    name: 'Demo Donor',
    email: 'donor@demo.com',
    password: 'password123',
    role: 'donor',
    phone: '9876543211',
    address: {
      street: '456 Donor Avenue',
      city: 'Delhi',
      state: 'Delhi',
      pincode: '110001',
      country: 'India'
    },
    isVerified: true
  },
  {
    name: 'Rajesh Kumar',
    email: 'rajesh@demo.com',
    password: 'password123',
    role: 'donor',
    phone: '9876543216',
    address: {
      street: '789 Donor Street',
      city: 'Mumbai',
      state: 'Maharashtra',
      pincode: '400001',
      country: 'India'
    },
    isVerified: true
  },
  {
    name: 'Priya Sharma',
    email: 'priya@demo.com',
    password: 'password123',
    role: 'donor',
    phone: '9876543217',
    address: {
      street: '321 Charity Lane',
      city: 'Bangalore',
      state: 'Karnataka',
      pincode: '560001',
      country: 'India'
    },
    isVerified: true
  },
  {
    name: 'Amit Singh',
    email: 'amit@demo.com',
    password: 'password123',
    role: 'donor',
    phone: '9876543218',
    address: {
      street: '654 Giving Road',
      city: 'Chennai',
      state: 'Tamil Nadu',
      pincode: '600001',
      country: 'India'
    },
    isVerified: true
  },
  {
    name: 'Sunita Patel',
    email: 'sunita@demo.com',
    password: 'password123',
    role: 'donor',
    phone: '9876543219',
    address: {
      street: '987 Helping Avenue',
      city: 'Kolkata',
      state: 'West Bengal',
      pincode: '700001',
      country: 'India'
    },
    isVerified: true
  }
];

// Enhanced campaigns with more variety and all using the same education image
const sampleCampaigns = [
  {
    title: 'Education for Underprivileged Children',
    description: 'Help us provide quality education to children from low-income families in urban slums.',
    category: 'education',
    targetAmount: 500000,
    raisedAmount: 125000,
    currency: 'INR',
    endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
    status: 'active',
    milestones: [
      {
        title: 'Set up learning center',
        description: 'Establish a learning center with basic infrastructure',
        targetAmount: 200000,
        isCompleted: true,
        completionDate: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000)
      },
      {
        title: 'Hire qualified teachers',
        description: 'Recruit and train qualified teachers for the center',
        targetAmount: 150000,
        isCompleted: false
      },
      {
        title: 'Provide educational materials',
        description: 'Purchase books, stationery, and learning aids',
        targetAmount: 150000,
        isCompleted: false
      }
    ],
    images: [
      'https://images.unsplash.com/photo-1454165205744-3b78555e5572?auto=format&fit=crop&w=800&q=60',
      'https://images.unsplash.com/photo-1496307042754-b4aa456c4a2d?auto=format&fit=crop&w=800&q=60'
    ],
    coverImage: 'https://images.unsplash.com/photo-1454165205744-3b78555e5572?auto=format&fit=crop&w=1200&h=400&q=60',
    tags: ['education', 'children', 'rural'],
    location: {
      city: 'Mumbai',
      state: 'Maharashtra',
      country: 'India'
    },
    transparencyScore: 75,
    isVerified: true
  },
  {
    title: 'Digital Learning for Rural Schools',
    description: 'Bring digital education to remote villages through tablets and internet connectivity.',
    category: 'education',
    targetAmount: 750000,
    raisedAmount: 200000,
    currency: 'INR',
    endDate: new Date(Date.now() + 45 * 24 * 60 * 60 * 1000),
    status: 'active',
    milestones: [
      {
        title: 'Purchase tablets and devices',
        description: 'Buy tablets and educational devices for students',
        targetAmount: 300000,
        isCompleted: true,
        completionDate: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000)
      },
      {
        title: 'Install internet connectivity',
        description: 'Set up internet infrastructure in schools',
        targetAmount: 250000,
        isCompleted: false
      },
      {
        title: 'Teacher training program',
        description: 'Train teachers on digital education tools',
        targetAmount: 200000,
        isCompleted: false
      }
    ],
    images: [
      'https://images.unsplash.com/photo-1454165205744-3b78555e5572?auto=format&fit=crop&w=800&q=60',
      'https://images.unsplash.com/photo-1496307042754-b4aa456c4a2d?auto=format&fit=crop&w=800&q=60'
    ],
    coverImage: 'https://images.unsplash.com/photo-1454165205744-3b78555e5572?auto=format&fit=crop&w=1200&h=400&q=60',
    tags: ['education', 'technology', 'rural'],
    location: {
      city: 'Delhi',
      state: 'Delhi',
      country: 'India'
    },
    transparencyScore: 80,
    isVerified: true
  },
  {
    title: 'Girl Child Education Initiative',
    description: 'Empower girls through education and skill development programs.',
    category: 'education',
    targetAmount: 400000,
    raisedAmount: 150000,
    currency: 'INR',
    endDate: new Date(Date.now() + 60 * 24 * 60 * 60 * 1000),
    status: 'active',
    milestones: [
      {
        title: 'Scholarship program setup',
        description: 'Establish scholarship program for girl students',
        targetAmount: 150000,
        isCompleted: true,
        completionDate: new Date(Date.now() - 20 * 24 * 60 * 60 * 1000)
      },
      {
        title: 'Skill development workshops',
        description: 'Conduct workshops for vocational training',
        targetAmount: 125000,
        isCompleted: false
      },
      {
        title: 'Parent awareness programs',
        description: 'Educate parents about importance of girl education',
        targetAmount: 125000,
        isCompleted: false
      }
    ],
    images: [
      'https://images.unsplash.com/photo-1454165205744-3b78555e5572?auto=format&fit=crop&w=800&q=60',
      'https://images.unsplash.com/photo-1496307042754-b4aa456c4a2d?auto=format&fit=crop&w=800&q=60'
    ],
    coverImage: 'https://images.unsplash.com/photo-1454165205744-3b78555e5572?auto=format&fit=crop&w=1200&h=400&q=60',
    tags: ['education', 'girls', 'empowerment'],
    location: {
      city: 'Bangalore',
      state: 'Karnataka',
      country: 'India'
    },
    transparencyScore: 85,
    isVerified: true
  },
  {
    title: 'Special Needs Education Support',
    description: 'Provide specialized education and therapy for children with disabilities.',
    category: 'education',
    targetAmount: 600000,
    raisedAmount: 180000,
    currency: 'INR',
    endDate: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000),
    status: 'active',
    milestones: [
      {
        title: 'Therapy equipment purchase',
        description: 'Buy specialized equipment for therapy sessions',
        targetAmount: 200000,
        isCompleted: true,
        completionDate: new Date(Date.now() - 25 * 24 * 60 * 60 * 1000)
      },
      {
        title: 'Special educator training',
        description: 'Train educators in special needs teaching methods',
        targetAmount: 200000,
        isCompleted: false
      },
      {
        title: 'Accessibility infrastructure',
        description: 'Make schools accessible for disabled children',
        targetAmount: 200000,
        isCompleted: false
      }
    ],
    images: [
      'https://images.unsplash.com/photo-1454165205744-3b78555e5572?auto=format&fit=crop&w=800&q=60',
      'https://images.unsplash.com/photo-1496307042754-b4aa456c4a2d?auto=format&fit=crop&w=800&q=60'
    ],
    coverImage: 'https://images.unsplash.com/photo-1454165205744-3b78555e5572?auto=format&fit=crop&w=1200&h=400&q=60',
    tags: ['education', 'special-needs', 'therapy'],
    location: {
      city: 'Chennai',
      state: 'Tamil Nadu',
      country: 'India'
    },
    transparencyScore: 70,
    isVerified: true
  },
  {
    title: 'Adult Literacy Program',
    description: 'Teach basic reading, writing, and arithmetic to adults who missed out on education.',
    category: 'education',
    targetAmount: 300000,
    raisedAmount: 75000,
    currency: 'INR',
    endDate: new Date(Date.now() + 45 * 24 * 60 * 60 * 1000),
    status: 'active',
    milestones: [
      {
        title: 'Community center setup',
        description: 'Establish community learning centers',
        targetAmount: 100000,
        isCompleted: true,
        completionDate: new Date(Date.now() - 12 * 24 * 60 * 60 * 1000)
      },
      {
        title: 'Volunteer teacher recruitment',
        description: 'Recruit and train volunteer teachers',
        targetAmount: 100000,
        isCompleted: false
      },
      {
        title: 'Learning materials distribution',
        description: 'Provide books and learning materials to students',
        targetAmount: 100000,
        isCompleted: false
      }
    ],
    images: [
      'https://images.unsplash.com/photo-1454165205744-3b78555e5572?auto=format&fit=crop&w=800&q=60',
      'https://images.unsplash.com/photo-1496307042754-b4aa456c4a2d?auto=format&fit=crop&w=800&q=60'
    ],
    coverImage: 'https://images.unsplash.com/photo-1454165205744-3b78555e5572?auto=format&fit=crop&w=1200&h=400&q=60',
    tags: ['education', 'adult-literacy', 'community'],
    location: {
      city: 'Kolkata',
      state: 'West Bengal',
      country: 'India'
    },
    transparencyScore: 65,
    isVerified: true
  },
  {
    title: 'STEM Education for Rural Youth',
    description: 'Introduce Science, Technology, Engineering, and Mathematics education in rural schools.',
    category: 'education',
    targetAmount: 800000,
    raisedAmount: 250000,
    currency: 'INR',
    endDate: new Date(Date.now() + 75 * 24 * 60 * 60 * 1000),
    status: 'active',
    milestones: [
      {
        title: 'Science lab setup',
        description: 'Establish well-equipped science laboratories',
        targetAmount: 300000,
        isCompleted: true,
        completionDate: new Date(Date.now() - 18 * 24 * 60 * 60 * 1000)
      },
      {
        title: 'Computer lab installation',
        description: 'Set up computer labs with internet connectivity',
        targetAmount: 250000,
        isCompleted: false
      },
      {
        title: 'Teacher training program',
        description: 'Train teachers in STEM subjects and methodologies',
        targetAmount: 250000,
        isCompleted: false
      }
    ],
    images: [
      'https://images.unsplash.com/photo-1454165205744-3b78555e5572?auto=format&fit=crop&w=800&q=60',
      'https://images.unsplash.com/photo-1496307042754-b4aa456c4a2d?auto=format&fit=crop&w=800&q=60'
    ],
    coverImage: 'https://images.unsplash.com/photo-1454165205744-3b78555e5572?auto=format&fit=crop&w=1200&h=400&q=60',
    tags: ['education', 'STEM', 'science', 'technology'],
    location: {
      city: 'Pune',
      state: 'Maharashtra',
      country: 'India'
    },
    transparencyScore: 90,
    isVerified: true
  },
  {
    title: 'Early Childhood Education Program',
    description: 'Provide quality early childhood education and care for children aged 3-6 years.',
    category: 'education',
    targetAmount: 350000,
    raisedAmount: 100000,
    currency: 'INR',
    endDate: new Date(Date.now() + 50 * 24 * 60 * 60 * 1000),
    status: 'active',
    milestones: [
      {
        title: 'Playground and equipment setup',
        description: 'Create safe play areas with educational toys',
        targetAmount: 150000,
        isCompleted: true,
        completionDate: new Date(Date.now() - 8 * 24 * 60 * 60 * 1000)
      },
      {
        title: 'Trained caregiver recruitment',
        description: 'Hire and train early childhood educators',
        targetAmount: 100000,
        isCompleted: false
      },
      {
        title: 'Nutrition program',
        description: 'Provide nutritious meals for children',
        targetAmount: 100000,
        isCompleted: false
      }
    ],
    images: [
      'https://images.unsplash.com/photo-1454165205744-3b78555e5572?auto=format&fit=crop&w=800&q=60',
      'https://images.unsplash.com/photo-1496307042754-b4aa456c4a2d?auto=format&fit=crop&w=800&q=60'
    ],
    coverImage: 'https://images.unsplash.com/photo-1454165205744-3b78555e5572?auto=format&fit=crop&w=1200&h=400&q=60',
    tags: ['education', 'early-childhood', 'development'],
    location: {
      city: 'Hyderabad',
      state: 'Telangana',
      country: 'India'
    },
    transparencyScore: 75,
    isVerified: true
  },
  {
    title: 'Vocational Training for Youth',
    description: 'Provide skill-based training to help youth find employment opportunities.',
    category: 'education',
    targetAmount: 450000,
    raisedAmount: 120000,
    currency: 'INR',
    endDate: new Date(Date.now() + 40 * 24 * 60 * 60 * 1000),
    status: 'active',
    milestones: [
      {
        title: 'Training center establishment',
        description: 'Set up vocational training centers',
        targetAmount: 200000,
        isCompleted: true,
        completionDate: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000)
      },
      {
        title: 'Equipment and tools purchase',
        description: 'Buy tools and equipment for various trades',
        targetAmount: 125000,
        isCompleted: false
      },
      {
        title: 'Industry partnership program',
        description: 'Partner with industries for job placements',
        targetAmount: 125000,
        isCompleted: false
      }
    ],
    images: [
      'https://images.unsplash.com/photo-1454165205744-3b78555e5572?auto=format&fit=crop&w=800&q=60',
      'https://images.unsplash.com/photo-1496307042754-b4aa456c4a2d?auto=format&fit=crop&w=800&q=60'
    ],
    coverImage: 'https://images.unsplash.com/photo-1454165205744-3b78555e5572?auto=format&fit=crop&w=1200&h=400&q=60',
    tags: ['education', 'vocational', 'employment', 'skills'],
    location: {
      city: 'Ahmedabad',
      state: 'Gujarat',
      country: 'India'
    },
    transparencyScore: 80,
    isVerified: true
  },
  {
    title: 'Library and Reading Program',
    description: 'Establish libraries and promote reading culture among children and adults.',
    category: 'education',
    targetAmount: 250000,
    raisedAmount: 60000,
    currency: 'INR',
    endDate: new Date(Date.now() + 35 * 24 * 60 * 60 * 1000),
    status: 'active',
    milestones: [
      {
        title: 'Library setup',
        description: 'Establish community libraries with books',
        targetAmount: 100000,
        isCompleted: true,
        completionDate: new Date(Date.now() - 6 * 24 * 60 * 60 * 1000)
      },
      {
        title: 'Book collection drive',
        description: 'Collect and organize books for the library',
        targetAmount: 75000,
        isCompleted: false
      },
      {
        title: 'Reading programs',
        description: 'Conduct reading sessions and book clubs',
        targetAmount: 75000,
        isCompleted: false
      }
    ],
    images: [
      'https://images.unsplash.com/photo-1454165205744-3b78555e5572?auto=format&fit=crop&w=800&q=60',
      'https://images.unsplash.com/photo-1496307042754-b4aa456c4a2d?auto=format&fit=crop&w=800&q=60'
    ],
    coverImage: 'https://images.unsplash.com/photo-1454165205744-3b78555e5572?auto=format&fit=crop&w=1200&h=400&q=60',
    tags: ['education', 'library', 'reading', 'books'],
    location: {
      city: 'Jaipur',
      state: 'Rajasthan',
      country: 'India'
    },
    transparencyScore: 70,
    isVerified: true
  },
  {
    title: 'Teacher Training and Development',
    description: 'Enhance teaching quality through comprehensive teacher training programs.',
    category: 'education',
    targetAmount: 500000,
    raisedAmount: 175000,
    currency: 'INR',
    endDate: new Date(Date.now() + 55 * 24 * 60 * 60 * 1000),
    status: 'active',
    milestones: [
      {
        title: 'Training curriculum development',
        description: 'Develop comprehensive teacher training curriculum',
        targetAmount: 150000,
        isCompleted: true,
        completionDate: new Date(Date.now() - 22 * 24 * 60 * 60 * 1000)
      },
      {
        title: 'Trainer recruitment',
        description: 'Recruit experienced trainers and education experts',
        targetAmount: 175000,
        isCompleted: false
      },
      {
        title: 'Training workshops',
        description: 'Conduct training workshops for teachers',
        targetAmount: 175000,
        isCompleted: false
      }
    ],
    images: [
      'https://images.unsplash.com/photo-1454165205744-3b78555e5572?auto=format&fit=crop&w=800&q=60',
      'https://images.unsplash.com/photo-1496307042754-b4aa456c4a2d?auto=format&fit=crop&w=800&q=60'
    ],
    coverImage: 'https://images.unsplash.com/photo-1454165205744-3b78555e5572?auto=format&fit=crop&w=1200&h=400&q=60',
    tags: ['education', 'teacher-training', 'professional-development'],
    location: {
      city: 'Lucknow',
      state: 'Uttar Pradesh',
      country: 'India'
    },
    transparencyScore: 85,
    isVerified: true
  }
];

// Enhanced donations with more variety
const sampleDonations = [
  {
    amount: 5000,
    currency: 'INR',
    paymentMethod: 'upi',
    paymentStatus: 'completed',
    upiTransactionId: 'UPI123456789',
    donorMessage: 'Happy to support this cause!',
    isAnonymous: false,
    taxDeductible: true,
    receiptGenerated: true,
    receiptNumber: 'DON-20241201-0001'
  },
  {
    amount: 10000,
    currency: 'INR',
    paymentMethod: 'upi',
    paymentStatus: 'completed',
    upiTransactionId: 'UPI123456790',
    donorMessage: 'Great initiative for education!',
    isAnonymous: false,
    taxDeductible: true,
    receiptGenerated: true,
    receiptNumber: 'DON-20241201-0002'
  },
  {
    amount: 2500,
    currency: 'INR',
    paymentMethod: 'upi',
    paymentStatus: 'completed',
    upiTransactionId: 'UPI123456791',
    donorMessage: 'Every child deserves education',
    isAnonymous: true,
    taxDeductible: true,
    receiptGenerated: true,
    receiptNumber: 'DON-20241201-0003'
  },
  {
    amount: 15000,
    currency: 'INR',
    paymentMethod: 'upi',
    paymentStatus: 'completed',
    upiTransactionId: 'UPI123456792',
    donorMessage: 'Supporting digital education for rural children',
    isAnonymous: false,
    taxDeductible: true,
    receiptGenerated: true,
    receiptNumber: 'DON-20241201-0004'
  },
  {
    amount: 7500,
    currency: 'INR',
    paymentMethod: 'upi',
    paymentStatus: 'completed',
    upiTransactionId: 'UPI123456793',
    donorMessage: 'Empowering girls through education',
    isAnonymous: false,
    taxDeductible: true,
    receiptGenerated: true,
    receiptNumber: 'DON-20241201-0005'
  },
  {
    amount: 20000,
    currency: 'INR',
    paymentMethod: 'upi',
    paymentStatus: 'completed',
    upiTransactionId: 'UPI123456794',
    donorMessage: 'Supporting special needs education',
    isAnonymous: false,
    taxDeductible: true,
    receiptGenerated: true,
    receiptNumber: 'DON-20241201-0006'
  },
  {
    amount: 3000,
    currency: 'INR',
    paymentMethod: 'upi',
    paymentStatus: 'completed',
    upiTransactionId: 'UPI123456795',
    donorMessage: 'Adult literacy is important',
    isAnonymous: true,
    taxDeductible: true,
    receiptGenerated: true,
    receiptNumber: 'DON-20241201-0007'
  },
  {
    amount: 12000,
    currency: 'INR',
    paymentMethod: 'upi',
    paymentStatus: 'completed',
    upiTransactionId: 'UPI123456796',
    donorMessage: 'STEM education for the future',
    isAnonymous: false,
    taxDeductible: true,
    receiptGenerated: true,
    receiptNumber: 'DON-20241201-0008'
  },
  {
    amount: 8000,
    currency: 'INR',
    paymentMethod: 'upi',
    paymentStatus: 'completed',
    upiTransactionId: 'UPI123456797',
    donorMessage: 'Early childhood development matters',
    isAnonymous: false,
    taxDeductible: true,
    receiptGenerated: true,
    receiptNumber: 'DON-20241201-0009'
  },
  {
    amount: 18000,
    currency: 'INR',
    paymentMethod: 'upi',
    paymentStatus: 'completed',
    upiTransactionId: 'UPI123456798',
    donorMessage: 'Vocational training for employment',
    isAnonymous: false,
    taxDeductible: true,
    receiptGenerated: true,
    receiptNumber: 'DON-20241201-0010'
  },
  {
    amount: 4000,
    currency: 'INR',
    paymentMethod: 'upi',
    paymentStatus: 'completed',
    upiTransactionId: 'UPI123456799',
    donorMessage: 'Promoting reading culture',
    isAnonymous: true,
    taxDeductible: true,
    receiptGenerated: true,
    receiptNumber: 'DON-20241201-0011'
  },
  {
    amount: 25000,
    currency: 'INR',
    paymentMethod: 'upi',
    paymentStatus: 'completed',
    upiTransactionId: 'UPI123456800',
    donorMessage: 'Teacher training is crucial for quality education',
    isAnonymous: false,
    taxDeductible: true,
    receiptGenerated: true,
    receiptNumber: 'DON-20241201-0012'
  },
  {
    amount: 6000,
    currency: 'INR',
    paymentMethod: 'upi',
    paymentStatus: 'pending',
    upiTransactionId: 'UPI123456801',
    donorMessage: 'Supporting education initiatives',
    isAnonymous: false,
    taxDeductible: true,
    receiptGenerated: false,
    receiptNumber: 'DON-20241201-0013'
  },
  {
    amount: 14000,
    currency: 'INR',
    paymentMethod: 'upi',
    paymentStatus: 'completed',
    upiTransactionId: 'UPI123456802',
    donorMessage: 'Digital learning for all children',
    isAnonymous: false,
    taxDeductible: true,
    receiptGenerated: true,
    receiptNumber: 'DON-20241201-0014'
  },
  {
    amount: 9000,
    currency: 'INR',
    paymentMethod: 'upi',
    paymentStatus: 'completed',
    upiTransactionId: 'UPI123456803',
    donorMessage: 'Girl child education empowerment',
    isAnonymous: false,
    taxDeductible: true,
    receiptGenerated: true,
    receiptNumber: 'DON-20241201-0015'
  }
];

async function seedDatabase() {
  try {
    console.log('🌱 Starting database seeding...');
    
    // Connect to MongoDB
    await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/donation-system');
    console.log('✅ Connected to MongoDB');
    
    // Clear existing data
    await User.deleteMany({});
    await Campaign.deleteMany({});
    await Donation.deleteMany({});
    console.log('🧹 Cleared existing data');
    
    // Create users
    const users = [];
    for (const userData of sampleUsers) {
      const user = new User(userData);
      await user.save();
      users.push(user);
      console.log(`✅ Created user: ${user.email}`);
    }
    
    // Create campaigns - distribute among NGO users
    const campaigns = [];
    const ngoUsers = users.filter(user => user.role === 'ngo');
    const donorUsers = users.filter(user => user.role === 'donor');
    
    for (let i = 0; i < sampleCampaigns.length; i++) {
      const campaignData = { ...sampleCampaigns[i] };
      campaignData.ngoId = ngoUsers[i % ngoUsers.length]._id; // Distribute among NGO users
      const campaign = new Campaign(campaignData);
      await campaign.save();
      campaigns.push(campaign);
      console.log(`✅ Created campaign: ${campaign.title}`);
    }
    
    // Create donations - distribute among donor users and campaigns
    for (let i = 0; i < sampleDonations.length; i++) {
      const donationData = {
        ...sampleDonations[i],
        donorId: donorUsers[i % donorUsers.length]._id, // Distribute among donor users
        campaignId: campaigns[i % campaigns.length]._id // Distribute among campaigns
      };
      const donation = new Donation(donationData);
      await donation.save();
      console.log(`✅ Created donation: ₹${donation.amount}`);
    }
    
    // Update user statistics for all users
    for (const user of users) {
      if (user.role === 'ngo') {
        // Count campaigns for this NGO
        const userCampaigns = campaigns.filter(c => c.ngoId.toString() === user._id.toString());
        user.totalCampaigns = userCampaigns.length;
        
        // Calculate total donations received by this NGO's campaigns
        const campaignIds = userCampaigns.map(c => c._id);
        const donations = await Donation.find({ campaignId: { $in: campaignIds } });
        user.totalDonations = donations.reduce((sum, d) => sum + d.amount, 0);
      } else if (user.role === 'donor') {
        // Count donations made by this donor
        const userDonations = await Donation.find({ donorId: user._id });
        user.totalDonations = userDonations.reduce((sum, d) => sum + d.amount, 0);
      }
      await user.save();
    }
    
    console.log('✅ Updated user statistics');
    
    console.log('🎉 Database seeding completed successfully!');
    console.log('');
    console.log('📋 Sample data created:');
    console.log(`   - ${users.length} users (${ngoUsers.length} NGOs, ${donorUsers.length} Donors)`);
    console.log(`   - ${campaigns.length} campaigns`);
    console.log(`   - ${sampleDonations.length} donations`);
    console.log('');
    console.log('🔑 Demo accounts:');
    console.log('   NGO Accounts:');
    console.log('     - ngo@demo.com / password123');
    console.log('     - education@demo.com / password123');
    console.log('     - rural@demo.com / password123');
    console.log('     - health@demo.com / password123');
    console.log('     - women@demo.com / password123');
    console.log('   Donor Accounts:');
    console.log('     - donor@demo.com / password123');
    console.log('     - rajesh@demo.com / password123');
    console.log('     - priya@demo.com / password123');
    console.log('     - amit@demo.com / password123');
    console.log('     - sunita@demo.com / password123');
    
  } catch (error) {
    console.error('❌ Error seeding database:', error);
  } finally {
    await mongoose.disconnect();
    console.log('🔌 Disconnected from MongoDB');
  }
}

// Run seeding if this file is executed directly
if (require.main === module) {
  seedDatabase();
}

module.exports = seedDatabase;
