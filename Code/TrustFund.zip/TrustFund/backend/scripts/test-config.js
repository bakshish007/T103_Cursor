const { ethers } = require("ethers");
const { NFTStorage, File } = require('nft.storage');
require('dotenv').config();

async function testConfiguration() {
  console.log("🧪 Testing Configuration...");
  console.log("==========================\n");

  // Test 1: Environment Variables
  console.log("1️⃣ Testing Environment Variables:");
  const requiredVars = ['POLYGON_RPC_URL', 'PRIVATE_KEY', 'NFT_STORAGE_API_KEY'];
  let allVarsPresent = true;

  requiredVars.forEach(varName => {
    if (process.env[varName]) {
      console.log(`   ✅ ${varName}: Configured`);
    } else {
      console.log(`   ❌ ${varName}: Missing`);
      allVarsPresent = false;
    }
  });

  if (!allVarsPresent) {
    console.log("\n❌ Some environment variables are missing. Please check your .env file.");
    return;
  }

  // Test 2: Blockchain Connection
  console.log("\n2️⃣ Testing Blockchain Connection:");
  try {
    const provider = new ethers.JsonRpcProvider(process.env.POLYGON_RPC_URL);
    const network = await provider.getNetwork();
    console.log(`   ✅ Connected to network: ${network.name} (Chain ID: ${network.chainId})`);
    
    // Test wallet
    const wallet = new ethers.Wallet(process.env.PRIVATE_KEY, provider);
    const balance = await provider.getBalance(wallet.address);
    console.log(`   ✅ Wallet address: ${wallet.address}`);
    console.log(`   ✅ Balance: ${ethers.formatEther(balance)} MATIC`);
    
    if (balance === 0n) {
      console.log(`   ⚠️  Warning: Wallet has no MATIC. You may need to fund it.`);
    }
  } catch (error) {
    console.log(`   ❌ Blockchain connection failed: ${error.message}`);
  }

  // Test 3: IPFS Storage
  console.log("\n3️⃣ Testing IPFS Storage:");
  try {
    const client = new NFTStorage({ token: process.env.NFT_STORAGE_API_KEY });
    
    // Test with a simple file
    const testContent = 'Hello, NFT.Storage!';
    const testFile = new File([testContent], 'test.txt', { type: 'text/plain' });
    
    const cid = await client.storeBlob(testFile);
    console.log(`   ✅ IPFS upload successful`);
    console.log(`   ✅ Test file CID: ${cid}`);
    console.log(`   ✅ Test URL: https://${cid}.ipfs.nftstorage.link`);
  } catch (error) {
    console.log(`   ❌ IPFS storage failed: ${error.message}`);
  }

  // Test 4: Database Connection (if MongoDB URI is provided)
  console.log("\n4️⃣ Testing Database Connection:");
  if (process.env.MONGODB_URI) {
    try {
      const mongoose = require('mongoose');
      await mongoose.connect(process.env.MONGODB_URI);
      console.log(`   ✅ MongoDB connection successful`);
      await mongoose.disconnect();
    } catch (error) {
      console.log(`   ❌ MongoDB connection failed: ${error.message}`);
    }
  } else {
    console.log(`   ⚠️  MONGODB_URI not configured`);
  }

  console.log("\n🎉 Configuration Test Complete!");
  console.log("===============================");
  console.log("If all tests passed, your configuration is ready!");
  console.log("You can now run: npm run dev");
}

testConfiguration().catch(console.error);
