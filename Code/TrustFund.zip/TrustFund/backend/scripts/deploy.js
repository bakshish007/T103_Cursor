const { ethers } = require("hardhat");

async function main() {
  console.log("Deploying contracts...");

  // Deploy CampaignContract
  const CampaignContract = await ethers.getContractFactory("CampaignContract");
  const campaignContract = await CampaignContract.deploy();
  await campaignContract.waitForDeployment();
  
  const campaignAddress = await campaignContract.getAddress();
  console.log("CampaignContract deployed to:", campaignAddress);

  // Deploy ImpactNFT
  const ImpactNFT = await ethers.getContractFactory("ImpactNFT");
  const impactNFT = await ImpactNFT.deploy();
  await impactNFT.waitForDeployment();
  
  const nftAddress = await impactNFT.getAddress();
  console.log("ImpactNFT deployed to:", nftAddress);

  // Save contract addresses
  const fs = require('fs');
  const contractAddresses = {
    campaignContract: campaignAddress,
    impactNFT: nftAddress,
    network: "mumbai"
  };
  
  fs.writeFileSync(
    './contract-addresses.json',
    JSON.stringify(contractAddresses, null, 2)
  );
  
  console.log("Contract addresses saved to contract-addresses.json");
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
