#!/bin/bash

# Transparent Donation System Deployment Script

echo "🚀 Starting deployment of Transparent Donation System..."

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js first."
    exit 1
fi

# Check if npm is installed
if ! command -v npm &> /dev/null; then
    echo "❌ npm is not installed. Please install npm first."
    exit 1
fi

echo "✅ Node.js and npm are installed"

# Install dependencies
echo "📦 Installing dependencies..."

# Install root dependencies
echo "Installing root dependencies..."
npm install

# Install backend dependencies
echo "Installing backend dependencies..."
cd backend
npm install

# Install frontend dependencies
echo "Installing frontend dependencies..."
cd ../frontend
npm install

# Go back to root
cd ..

echo "✅ Dependencies installed successfully"

# Check for environment files
echo "🔧 Checking environment configuration..."

if [ ! -f "backend/.env" ]; then
    echo "⚠️  backend/.env file not found. Please copy backend/env.example to backend/.env and configure it."
    echo "   cp backend/env.example backend/.env"
fi

if [ ! -f "frontend/.env" ]; then
    echo "⚠️  frontend/.env file not found. Please copy frontend/env.example to frontend/.env and configure it."
    echo "   cp frontend/env.example frontend/.env"
fi

# Create uploads directory
echo "📁 Creating uploads directory..."
mkdir -p backend/uploads

# Build frontend
echo "🏗️  Building frontend..."
cd frontend
npm run build
cd ..

echo "✅ Frontend built successfully"

# Check if MongoDB is configured
echo "🗄️  Checking MongoDB configuration..."
if [ -f "backend/.env" ]; then
    if grep -q "MONGODB_URI" backend/.env; then
        echo "✅ MongoDB URI found in environment file"
    else
        echo "⚠️  MongoDB URI not found in environment file"
    fi
else
    echo "⚠️  backend/.env file not found"
fi

# Check if blockchain configuration is set
echo "⛓️  Checking blockchain configuration..."
if [ -f "backend/.env" ]; then
    if grep -q "POLYGON_RPC_URL" backend/.env; then
        echo "✅ Polygon RPC URL found in environment file"
    else
        echo "⚠️  Polygon RPC URL not found in environment file"
    fi
    
    if grep -q "PRIVATE_KEY" backend/.env; then
        echo "✅ Private key found in environment file"
    else
        echo "⚠️  Private key not found in environment file"
    fi
else
    echo "⚠️  backend/.env file not found"
fi

echo ""
echo "🎉 Deployment preparation completed!"
echo ""
echo "📋 Next steps:"
echo "1. Configure your environment files:"
echo "   - Copy backend/env.example to backend/.env"
echo "   - Copy frontend/env.example to frontend/.env"
echo "   - Update the configuration values"
echo ""
echo "2. Set up your database:"
echo "   - Create a MongoDB Atlas cluster"
echo "   - Update MONGODB_URI in backend/.env"
echo ""
echo "3. Configure blockchain:"
echo "   - Get Polygon testnet RPC URL"
echo "   - Add your private key for contract deployment"
echo "   - Update POLYGON_RPC_URL and PRIVATE_KEY in backend/.env"
echo ""
echo "4. Deploy smart contracts:"
echo "   cd backend && npx hardhat run scripts/deploy.js --network mumbai"
echo ""
echo "5. Start the application:"
echo "   npm run dev"
echo ""
echo "🔗 Demo accounts:"
echo "   NGO: ngo@demo.com / password123"
echo "   Donor: donor@demo.com / password123"
echo ""
echo "📚 For more information, check the README.md file"
