# Testing Guide - Transparent Donation System

This guide provides comprehensive testing instructions for the Transparent Donation System.

## 🧪 Testing Overview

The application includes demo accounts and sample data for testing all features without requiring real blockchain transactions or payments.

## 🔑 Demo Accounts

### NGO Account
- **Email**: `ngo@demo.com`
- **Password**: `password123`
- **Role**: NGO (Non-Governmental Organization)

### Donor Account
- **Email**: `donor@demo.com`
- **Password**: `password123`
- **Role**: Donor

## 📊 Sample Data

The system includes pre-loaded sample data:
- 2 demo users (1 NGO, 1 Donor)
- 2 sample campaigns with milestones
- 2 sample donations
- Complete user profiles and statistics

## 🚀 Quick Start Testing

### 1. Start the Application
```bash
npm run dev
```

### 2. Access the Application
- Frontend: http://localhost:3000
- Backend API: http://localhost:5000

### 3. Login with Demo Accounts
Use the demo accounts above to test different user roles.

## 🧩 Feature Testing Scenarios

### NGO Testing Scenarios

#### 1. Campaign Management
1. **Login as NGO** (`ngo@demo.com`)
2. **Navigate to Dashboard**
   - Verify NGO-specific dashboard
   - Check campaign statistics
3. **Create New Campaign**
   - Go to "Create Campaign"
   - Fill in campaign details
   - Add milestones
   - Upload images
   - Submit campaign
4. **Manage Existing Campaigns**
   - View campaign list
   - Edit campaign details
   - Update campaign status
   - Upload milestone proofs

#### 2. Proof Upload Testing
1. **Navigate to Campaign Management**
2. **Select a Campaign**
3. **Upload Proof Files**
   - Images, videos, documents
   - Add geo-location data
   - Submit proof
4. **Verify Blockchain Recording**
   - Check transaction hash
   - Verify transparency score update

### Donor Testing Scenarios

#### 1. Donation Flow
1. **Login as Donor** (`donor@demo.com`)
2. **Browse Campaigns**
   - View campaign listings
   - Filter by category
   - Search campaigns
3. **Make Donation**
   - Select campaign
   - Enter donation amount
   - Add donor message
   - Generate UPI QR code
   - Simulate payment confirmation
4. **Verify NFT Minting**
   - Check NFT collection
   - View impact data
   - Verify blockchain transaction

#### 2. Donation History
1. **View My Donations**
   - Check donation history
   - Download receipts
   - View transaction details
2. **NFT Collection**
   - Browse Impact NFTs
   - View NFT metadata
   - Check blockchain verification

### Public User Testing

#### 1. Transparency Dashboard
1. **Access without Login**
2. **Browse Campaigns**
   - View all active campaigns
   - Check campaign details
   - See transparency scores
3. **View Proofs**
   - Check milestone proofs
   - View geo-locations
   - Verify blockchain transactions

## 🔍 API Testing

### Authentication Endpoints
```bash
# Register new user
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"Test User","email":"test@example.com","password":"password123","role":"donor"}'

# Login
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"ngo@demo.com","password":"password123"}'
```

### Campaign Endpoints
```bash
# Get all campaigns
curl http://localhost:5000/api/campaigns

# Get campaign by ID
curl http://localhost:5000/api/campaigns/{campaignId}
```

### Donation Endpoints
```bash
# Create donation (requires auth token)
curl -X POST http://localhost:5000/api/donations \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer {token}" \
  -d '{"campaignId":"{campaignId}","amount":1000}'
```

## 🧪 Test Cases

### 1. User Registration
- [ ] Register as NGO with all required fields
- [ ] Register as Donor with all required fields
- [ ] Validate email format
- [ ] Validate password strength
- [ ] Handle duplicate email registration

### 2. User Authentication
- [ ] Login with valid credentials
- [ ] Login with invalid credentials
- [ ] JWT token validation
- [ ] Role-based access control
- [ ] Session management

### 3. Campaign Management
- [ ] Create campaign with all fields
- [ ] Create campaign with milestones
- [ ] Upload campaign images
- [ ] Update campaign details
- [ ] Change campaign status
- [ ] Delete campaign

### 4. Donation Flow
- [ ] Create donation request
- [ ] Generate UPI QR code
- [ ] Simulate payment confirmation
- [ ] Verify blockchain recording
- [ ] Mint Impact NFT
- [ ] Update campaign raised amount

### 5. Proof Upload
- [ ] Upload proof files
- [ ] Add geo-location data
- [ ] Verify IPFS storage
- [ ] Record blockchain transaction
- [ ] Update transparency score

### 6. Transparency Features
- [ ] View public campaign list
- [ ] Check transparency scores
- [ ] Verify blockchain transactions
- [ ] View proof locations
- [ ] Download receipts

## 🐛 Common Issues & Solutions

### 1. Database Connection Issues
**Problem**: MongoDB connection failed
**Solution**: 
- Check MongoDB URI in backend/.env
- Ensure MongoDB Atlas cluster is running
- Verify network access settings

### 2. Blockchain Integration Issues
**Problem**: Smart contract calls failing
**Solution**:
- Check Polygon RPC URL
- Verify private key configuration
- Ensure testnet MATIC balance
- Check contract deployment

### 3. File Upload Issues
**Problem**: File uploads failing
**Solution**:
- Check file size limits
- Verify file type restrictions
- Check IPFS configuration
- Ensure uploads directory exists

### 4. Authentication Issues
**Problem**: JWT token validation failing
**Solution**:
- Check JWT secret configuration
- Verify token expiration
- Check CORS settings
- Validate request headers

## 📱 Mobile Testing

### Responsive Design
- [ ] Test on mobile devices
- [ ] Check tablet compatibility
- [ ] Verify touch interactions
- [ ] Test form inputs on mobile

### Progressive Web App Features
- [ ] Test offline functionality
- [ ] Check push notifications
- [ ] Verify app installation
- [ ] Test background sync

## 🔒 Security Testing

### 1. Authentication Security
- [ ] Test password hashing
- [ ] Verify JWT token security
- [ ] Check session management
- [ ] Test role-based access

### 2. Input Validation
- [ ] Test SQL injection prevention
- [ ] Check XSS protection
- [ ] Verify file upload security
- [ ] Test input sanitization

### 3. API Security
- [ ] Test rate limiting
- [ ] Check CORS configuration
- [ ] Verify HTTPS enforcement
- [ ] Test authentication bypass

## 📊 Performance Testing

### 1. Load Testing
- [ ] Test concurrent users
- [ ] Check database performance
- [ ] Verify API response times
- [ ] Test file upload performance

### 2. Frontend Performance
- [ ] Check page load times
- [ ] Test image optimization
- [ ] Verify bundle size
- [ ] Check rendering performance

## 🚀 Deployment Testing

### 1. Production Build
```bash
# Build frontend
cd frontend && npm run build

# Test production build
npm start
```

### 2. Environment Configuration
- [ ] Test production environment variables
- [ ] Verify database connections
- [ ] Check blockchain network settings
- [ ] Test file storage configuration

## 📝 Test Reporting

### Manual Testing Checklist
Create a checklist for each feature and mark completion:
- [ ] Feature works as expected
- [ ] Error handling works
- [ ] UI/UX is intuitive
- [ ] Performance is acceptable
- [ ] Security requirements met

### Bug Reporting
When reporting bugs, include:
1. **Steps to reproduce**
2. **Expected behavior**
3. **Actual behavior**
4. **Environment details**
5. **Screenshots/logs**

## 🎯 Success Criteria

The application is considered ready for demo when:
- [ ] All core features work without errors
- [ ] Demo accounts function properly
- [ ] Blockchain integration works (if configured)
- [ ] File uploads work correctly
- [ ] Responsive design works on all devices
- [ ] Performance is acceptable
- [ ] Security measures are in place

## 📞 Support

For testing support:
1. Check the README.md for setup instructions
2. Review error logs in browser console
3. Check backend logs for API errors
4. Verify environment configuration
5. Test with demo accounts first

---

**Note**: This testing guide covers the core functionality. For production deployment, additional security and performance testing would be required.
